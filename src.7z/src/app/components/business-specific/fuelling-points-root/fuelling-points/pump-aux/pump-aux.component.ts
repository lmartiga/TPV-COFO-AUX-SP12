import { Component, OnInit, Input, SimpleChanges, OnChanges, Output, EventEmitter } from '@angular/core';
import { FuellingPointInfo } from 'app/shared/fuelling-point/fuelling-point-info';
import { FuellingLimitType } from 'app/shared/fuelling-point/fuelling-limit-type.enum';
import { IDictionaryStringKey } from 'app/shared/idictionary';
import { FuellingPointFormatConfiguration } from 'app/shared/fuelling-point/fuelling-point-format-configuration';
import { FuellingPointsInternalService } from 'app/services/fuelling-points/fuelling-points-internal.service';
import { SignalRPSSService } from 'app/services/signalr/signalr-pss.service';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';

@Component({
  selector: 'tpv-pump-aux',
  templateUrl: './pump-aux.component.html',
  styleUrls: ['./pump-aux.component.scss']
})
export class PumpAuxComponent implements OnInit, OnChanges {
  @Input()
  fuellingPointInfo: FuellingPointInfo;
  @Output() cerrar: EventEmitter<boolean>;
  formatConfig: FuellingPointFormatConfiguration;

  // usado para mostrar el producto en uso
  fuellingProductData: {
    unitaryPrice?: number;
    gradeId?: number;
  };

  // usado para indicar que simbolo se usa de limite (segun el tipo: volumen o moneda)
  limitSymbol: string;
  // uado para indicar el formato del limite segun el tipo
  limitFormatter: string;

  constructor(
    private _internalSvc: FuellingPointsInternalService,
    private _signalr: SignalRPSSService,
    private _statusBarService: StatusBarService,
  ) {
    this.formatConfig = this._internalSvc.formatConfiguration;
    this.cerrar = new EventEmitter();
   }

  ngOnInit() {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.fuellingPointInfo != undefined) {
      this.setData();
    }
  }

  private setData() {
    try {
      switch (this.fuellingPointInfo.limitType) {
        case FuellingLimitType.Monetary:
          this.limitFormatter = this.formatConfig.moneyPipeFormat;
          this.limitSymbol = this.formatConfig.currency.symbol;
          break;
        case FuellingLimitType.Volume:
          this.limitFormatter = this.formatConfig.volumePipeFormat;
          this.limitSymbol = this.formatConfig.volume.symbol;
          break;
        default: break;
      }

      this.fuellingProductData = {
        gradeId: this.fuellingPointInfo.limitGradeId,
        unitaryPrice: this.fuellingPointInfo.limitProductUnitaryPrice
      };
    } catch (error) {
      console.log('Error en Pump-aux', error);
    }
  }
  btnFuellingPointClick() {
    try {
      this._signalr.ChangeSalePrepayOtherFuellingPoint(this.fuellingPointInfo.idfpTransferOrigen, this.fuellingPointInfo.id)
      .first()
      .subscribe( response => {
        if (response.status == 1) {
          this._statusBarService.publishMessage('Se realizó la transferencia');
        } else {
          let sMessage = response.message.split('-');
          this._statusBarService.publishMessage(sMessage[0]);
        }
      },
      error => {
        console.log('Error en ChangeSalePrepayOtherFuellingPoint');
      });
      this.cerrar.emit(true);
      } catch (error) {
      console.log('Error en servicio de transferencia de venta prepago.');
      }
  }

  setClassButton(): IDictionaryStringKey<boolean> {
    return this._internalSvc.getNgClassBackGroundColor(this.fuellingPointInfo);
  }
  setClassIcon(): IDictionaryStringKey<boolean> {
    return this._internalSvc.getNgClassIcon(this.fuellingPointInfo);
  }
  setClassTransactionIcon(): IDictionaryStringKey<boolean> {
    return this._internalSvc.getNgClassTransactionIcon(this.fuellingPointInfo);
  }
  srcGrade(): string {
    return this._internalSvc.getImgFromGrade(this.fuellingProductData.gradeId);
  }
}
