import { Component, OnInit, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { FuellingPointInfo } from 'app/shared/fuelling-point/fuelling-point-info';
import { FuellingPointMainStates } from 'app/shared/fuelling-point/fuelling-point-main-states.enum';
import { FuellingLimitType } from 'app/shared/fuelling-point/fuelling-limit-type.enum';
import { OnChanges } from '@angular/core/src/metadata/lifecycle_hooks';
import { IDictionaryStringKey } from 'app/shared/idictionary';
import { FuellingPointFormatConfiguration } from 'app/shared/fuelling-point/fuelling-point-format-configuration';
import { FuellingPointsInternalService } from 'app/services/fuelling-points/fuelling-points-internal.service';

@Component({
  selector: 'tpv-pump',
  templateUrl: './pump.component.html',
  styleUrls: ['./pump.component.scss'],
})
export class PumpComponent implements OnInit, OnChanges {
  @Output() fpSelectedEvent = new EventEmitter<FuellingPointInfo>();
  @Input()
  fuellingPointInfo: FuellingPointInfo;

  @Input()
  formatConfig: FuellingPointFormatConfiguration;
  // usado para mostrar el suministro actual (live)
  fuellingData: {
    vol?: number;
    amount?: number;
  };
  // usado para mostrar el producto en uso
  fuellingProductData: {
    unitaryPrice?: number;
    gradeId?: number;
  };

  // usado para indicar que simbolo se usa de limite (segun el tipo: volumen o moneda)
  limitSymbol: string;
  // uado para indicar el formato del limite segun el tipo
  limitFormatter: string;
  constructor(
    private _internalSvc: FuellingPointsInternalService
  ) {
  }

  ngOnInit() {
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.fuellingPointInfo != undefined) {
      this.setData();
    }
  }

  private setData() {
    const hasLimit = this.fuellingPointInfo.hasSupplyLimit
      && this.fuellingPointInfo.limitValue != undefined
      && this.fuellingPointInfo.limitType != undefined;
    if (hasLimit) {
      switch (this.fuellingPointInfo.limitType) {
        case FuellingLimitType.Monetary:
          this.limitFormatter = this.formatConfig.moneyPipeFormat;
          this.limitSymbol = this.formatConfig.currency.symbol;
          break;
        case FuellingLimitType.Volume:
          this.limitFormatter = this.formatConfig.volumePipeFormat;
          this.limitSymbol = this.formatConfig.volume.symbol;
          break;
      }
    }

    if (this.fuellingPointInfo.mainState != FuellingPointMainStates.Fuelling
      || (this.fuellingPointInfo.fuellingDataVolume == undefined && this.fuellingPointInfo.fuellingDataMonetary == undefined)) {
      // solo pintara datos si esta en fuelling
      this.fuellingData = undefined;
    } else {
      if (this.fuellingPointInfo.fuellingDataMonetary != undefined && this.fuellingPointInfo.fuellingDataMonetary > 0) {
        if (this.fuellingData == undefined) {
          this.fuellingData = {};
        }
        this.fuellingData.amount = this.fuellingPointInfo.fuellingDataMonetary;
      }
      if (this.fuellingPointInfo.fuellingDataVolume != undefined && this.fuellingPointInfo.fuellingDataVolume > 0) {
        if (this.fuellingData == undefined) {
          this.fuellingData = {};
        }
        this.fuellingData.vol = this.fuellingPointInfo.fuellingDataVolume;
      }
    }
    if (this.fuellingPointInfo.hasSupplyLimit) {
      this.fuellingProductData = {
        gradeId: this.fuellingPointInfo.limitGradeId,
        unitaryPrice: this.fuellingPointInfo.limitProductUnitaryPrice
      };
    } else {
      if (this.fuellingPointInfo.currentGradeId == undefined || this.fuellingPointInfo.currentProductUnitaryPrice == undefined) {
        this.fuellingProductData = undefined;
      } else {
        this.fuellingProductData = {};
        if (this.fuellingPointInfo.currentGradeId != undefined) {
          this.fuellingProductData.gradeId = this.fuellingPointInfo.currentGradeId;
        }
        if (this.fuellingPointInfo.currentProductUnitaryPrice != undefined) {
          this.fuellingProductData.unitaryPrice = this.fuellingPointInfo.currentProductUnitaryPrice;
        }
      }
    }

  }

  btnFuellingPointClick() {
    this.fpSelectedEvent.emit(this.fuellingPointInfo);
  }
  setClassButton(): IDictionaryStringKey<boolean> {
    return this._internalSvc.getNgClassBackGroundColor(this.fuellingPointInfo);
  }
  setClassIcon(): IDictionaryStringKey<boolean> {
    return this._internalSvc.getNgClassIcon(this.fuellingPointInfo);
  }
  setClassTransactionIcon(): IDictionaryStringKey<boolean> {
    return this._internalSvc.getNgClassTransactionIcon(this.fuellingPointInfo);
  }
  srcGrade(): string {
    return this._internalSvc.getImgFromGrade(this.fuellingProductData.gradeId);
  }
}
