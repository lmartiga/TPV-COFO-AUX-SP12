import { Component, OnInit, OnDestroy } from '@angular/core';
import { FuellingPointsService } from 'app/services/fuelling-points/fuelling-points.service';
import { FuellingPointInfo } from 'app/shared/fuelling-point/fuelling-point-info';
import { FuellingPointsInternalService } from 'app/services/fuelling-points/fuelling-points-internal.service';
import { FuellingPointsSignalrUpdatesService } from 'app/services/fuelling-points/fuelling-points-signalr-updates.service';
import { AuxiliarActionsManagerService } from 'app/services/auxiliar-actions/auxiliar-actions-manager.service';
import {
  FuellingPointTransactionCountChangedArgs
} from 'app/shared/fuelling-point/signalR-Response/fuelling-point-transaction-count-changed-args';
import { FuellingPointFormatConfiguration } from 'app/shared/fuelling-point/fuelling-point-format-configuration';
import { Subscription } from 'rxjs/Subscription';
import { PetrolStationMode } from 'app/shared/fuelling-point/petrol-station-mode.enum';
import { SignalRPSSService } from 'app/services/signalr/signalr-pss.service';
import { DocumentService } from 'app/services/document/document.service';
import { RoundPipe } from 'app/pipes/round.pipe';
import { DocumentLinePromotion } from 'app/shared/document/document-line-promotion';
import { DocumentLine } from 'app/shared/document/document-line';
import { Customer } from 'app/shared/customer/customer';
import { FuellingPointSupplyLineData } from 'app/shared/fuelling-point/fuelling-point-supply-line-data';
import { FuellingPointSupplyLine } from 'app/shared/fuelling-point/fuelling-point-supply-line';
import { CustomerService } from 'app/services/customer/customer.service';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { CashPaymentService } from 'app/services/payments/cash-payment.service';
import { Operator } from 'app/shared/operator/operator';
import { OperatorInternalService } from 'app/services/operator/operator-internal.service';
import { ServiceModeType } from 'app/shared/fuelling-point/service-mode-type.enum'; 

@Component({
  selector: 'tpv-fuelling-points',
  templateUrl: './fuelling-points.component.html',
  styleUrls: ['./fuelling-points.component.scss']
})
export class FuellingPointsComponent implements OnInit, OnDestroy {
  // stores the information about fuelling points on the service station
  fpInformation: Array<FuellingPointInfo>;
private _subscriptions: Subscription[] = [];
valor: number = 0;
btnStopCheckStatus: boolean;
btnNightCheckStatus: boolean;
fpFormatConfig: FuellingPointFormatConfiguration;
currentDocument: any = {
currencyId : this._appDataConfig.baseCurrency.id,
customer : undefined,
emissionLocalDateTime : undefined,
isatend : '',
lines : undefined,
operator : undefined,
plate: undefined,
series : undefined,
showAlertInsertCustomer : false,
showAlertInsertOperator : false,
totalAmountWithTax: 0,
usedDefaultOperator: false

};

  constructor(
    private _fuellingPointsSvc: FuellingPointsService,
    private _internalSvc: FuellingPointsInternalService,
    private _fpSignalR: FuellingPointsSignalrUpdatesService,
    private _auxActionMngr: AuxiliarActionsManagerService,
    private _signalr: SignalRPSSService,
    private _documentService: DocumentService,
    private _roundPipe: RoundPipe,
    private _cashPaymentService: CashPaymentService,
    private _customerService: CustomerService,
    private _appDataConfig: AppDataConfiguration,
    private _operador: OperatorInternalService 
  ) {
  }

  ngOnInit() {
    this.fpFormatConfig = this._internalSvc.formatConfiguration;
    // retrieving fp info
    this._subscriptions.push(this._fpSignalR.onAllFuellingPoints()
      .subscribe(data => {
        this.fpInformation = data;
      }));
    this._subscriptions.push(this._fpSignalR.onFuellingPointUpdate()
      .subscribe(fp => {
        this.onFuellingPointUpdate(fp);
      }));
    this._subscriptions.push(this._fpSignalR.onFuellingPointTransactionCountChange()
      .subscribe(eventParam => {
        this.onFuellingPointTransactionCountChange(eventParam);
      }));

  }
  TransformPostPaidWithTransactionToPreAuthorized(id: number): void {
    const displayPreAut = this._appDataConfig.getConfigurationParameterByName('DISPLAY_MODE_PRE-AUTHORIZED', 'GENERAL');
    let displayValuePreAut: boolean;
    if (displayPreAut == undefined ) {
      displayValuePreAut = true;
    }
    else {
      displayValuePreAut = displayPreAut.meaningfulStringValue.toUpperCase.toString() == 'TRUE' ? true : false;
    }
    if (displayValuePreAut) {
    if (this.fpInformation != undefined) {
      this.fpInformation.forEach(e => {
        if (e.id == id) {
          if (e.hasTransactions && e.serviceModeType == ServiceModeType.PostPaid && !e.hasPostPaidTransaction && !e.isAttend){

            this._signalr.requestChangeServiceMode(ServiceModeType.PreAuthorized, e.id, '')
            .first().subscribe(response => { });
            e.hasPostPaidTransaction = true;
          } else if (!e.hasTransactions && e.hasPostPaidTransaction) {
            this._signalr.requestChangeServiceMode(ServiceModeType.PostPaid, e.id, '')
            .first().subscribe(response => { });
            e.hasPostPaidTransaction = false;
          }
        }
      });
    }
  }
  }
  ngOnDestroy(): void {
    this._subscriptions.forEach(s => s.unsubscribe());
  }

  fuellingPointSelected(fp: FuellingPointInfo) {
    this._auxActionMngr.requestFuellingPointOperations(fp, this.fpInformation);
  }

  btnStopClick(isStop: boolean) {
    this._fuellingPointsSvc.manageRequestEmergencyStop(isStop)
      .first().subscribe();
  }

  btnNigthClick(isNight: boolean) {
    this._fuellingPointsSvc.requestChangePetrolStationMode(
      isNight ? PetrolStationMode.Night : PetrolStationMode.Default)
      .first().subscribe(response => {
        // si el cambio es ok, cambiamos el estado del boton.
        if (response) {
          this.btnNightCheckStatus = !this.btnNightCheckStatus;
        }
      });
  }

  btnTransactionsClick() {
    this._auxActionMngr.requestWaitingOperations();
  }

  createRange(index: number, positionNumber: number): Array<boolean> {
    let elements: number = 0;
    if (index == 0) {
      elements = positionNumber;
    } else {
      elements = positionNumber - this.fpInformation[index - 1].positionNumber;
    }

    const ret = new Array<boolean>(elements - 1);
    return ret;
  }

  private onFuellingPointUpdate(fp: FuellingPointInfo) {
    console.log(`Fuelling Point Component ----> UPDATE fuellignPoint. Hora: ${(new Date().toLocaleTimeString())}`);
    console.log(fp);
    if (this.fpInformation == undefined) {
      console.log('No se ha inicializado la lista de fuelling Points');
      return;
    }
    for (let index = 0; index < this.fpInformation.length; index++) {
      const pump = this.fpInformation[index];
      if (pump.id != fp.id) {
        continue;
      }
      fp.hasTransactions = pump.hasTransactions; // salvamos estado anterior, se modifica por otra parte
      // angular change detection will trigger and update the pump bounded
      this.fpInformation[index] = this.updateReference(fp);
      this.checkStates();
      break;
    }
  }

  /*
  private onFuellingPointTransactionCountChange(param: FuellingPointTransactionCountChangedArgs) {
    if (param == undefined) {
      return;
    }
    console.log(`Fuelling Point Component ----> Transaction Count Cange. Hora: ${(new Date().toLocaleTimeString())}`);
    console.log(param);
    if (this.fpInformation == undefined) {
      console.log('No se ha inicializado la lista de fuelling Points');
      return;
    }
    for (let index = 0; index < this.fpInformation.length; index++) {
      const pump = this.fpInformation[index];
      if (pump.id != param.fuellingPointId) {
        continue;
      }
      pump.hasTransactions = param.transactionCount > 0;
      // angular change detection will trigger and update the pump bounded
      this.fpInformation[index] = this.updateReference(pump);
      break;
    }
  }
  */
/*
  // should be called after a update in the fpInformation
  private checkStates() {
    let allStoped = true;
    for (let i = 0; i < this.fpInformation.length; i++) {
      const pivote = this.fpInformation[i];
      allStoped = allStoped && pivote.isStopped;
    }
    this.btnStopCheckStatus = allStoped;
  }

  // angular change detection for arrays only check reference to fire onChange
  private updateReference<T>(object: T): T {
    return JSON.parse(JSON.stringify(object));
  }*/

  private ObtenerCombustible(id: number) {
    this._fuellingPointsSvc.requestSuplyTransactions(id)
      .first().subscribe(response => {
        const transaccion = response[0];
        const operator: Operator = this._operador.currentOperator  == undefined ? undefined : this._operador.currentOperator;
        this.currentDocument.operator = operator;

         this.currentDocument.emissionLocalDateTime = new Date();
          // const customer: Customer = this._customer.currentCustomer  == undefined ? undefined : this._customer.currentCustomer
            this._customerService.getCustomerById(this._appDataConfig.unknownCustomerId)
          .subscribe((customer: Customer) => {
              this.currentDocument.customer = customer;
            try {
            this._signalr.lockSupplyTransaction(operator.id,
              customer.id, transaccion.id, transaccion.fuellingPointId).subscribe((respn) => {
                  const supplyLineData: FuellingPointSupplyLineData = {
                    fpSvc: this._fuellingPointsSvc,
                    supplyTransaction: transaccion,
                    lineNumberInDocument: 1
                  };
                  const specificLine: FuellingPointSupplyLine = new FuellingPointSupplyLine(supplyLineData);
                const line: DocumentLine [] = [{
                   businessSpecificLineInfo: specificLine,
                  description: respn.productName,
                  discountAmountWithTax: respn.discountedAmount,
                  discountPercentage: respn.discountPercentage,
                  priceWithTax: respn.unitaryPricePreDiscount,
                  productId:  respn.productReference,
                  quantity: respn.correspondingVolume,
                  taxAmount: 0,
                  taxPercentage: respn.taxPercentage,
                  totalAmountWithTax: respn.finalAmount,
                  typeArticle: respn.typeArticle,
                  appliedPromotionList: [],
                  priceWithoutTax : this._roundPipe.transformInBaseCurrency(respn.unitaryPricePreDiscount / (1 + (respn.taxPercentage / 100)))
                }];
                this.currentDocument.lines = line;
                 this.GenerarTicket();
            }
            );
          } catch (error) {
            console.log('Error en la función lockSupplyTransaction', error);
            this.valor = 0;
          }
          },error => {
            console.log('Error en la función getCustomerById', error);
            this.valor = 0;
          });       
      },error => {
        console.log('Error en la función requestSuplyTransactions', error);
        this.valor = 0;
      });
  }

 
  private onFuellingPointTransactionCountChange(param: FuellingPointTransactionCountChangedArgs) {
    if (param == undefined) {
      return;
    }
    console.log(`Fuelling Point Component ----> Transaction Count Cange. Hora: ${(new Date().toLocaleTimeString())}`);
    console.log(param);
    if (this.fpInformation == undefined) {
      console.log('No se ha inicializado la lista de fuelling Points');
      return;
    }
    
    const fuel = this.fpInformation.find(x => x.id == param.fuellingPointId)

    if( fuel.isAttend && fuel.hasFreeBuffer==false) {
      this.valor++;
    }
    
    if(this.valor==1){
      this.ObtenerCombustible(param.fuellingPointId);
    }

    for (let index = 0; index < this.fpInformation.length; index++) {
      const pump = this.fpInformation[index];
      if (pump.id != param.fuellingPointId) {
        continue;
      }
      pump.hasTransactions = param.transactionCount > 0;
      // angular change detection will trigger and update the pump bounded
      this.fpInformation[index] = this.updateReference(pump);
      break;
    }
  }

  // should be called after a update in the fpInformation
  private checkStates() {
    let allStoped = true;
    for (let i = 0; i < this.fpInformation.length; i++) {
      const pivote = this.fpInformation[i];
      allStoped = allStoped && pivote.isStopped;
    }
    this.btnStopCheckStatus = allStoped;
  }

  // angular change detection for arrays only check reference to fire onChange
  private updateReference<T>(object: T): T {
    return JSON.parse(JSON.stringify(object));
  }


  GenerarTicket() {
    this._documentService.calculatePromotions(this.currentDocument)
    .subscribe(
      calculatePromotionsResponse => {
        if (calculatePromotionsResponse.success === true) {
          const receivedPromotionsList = calculatePromotionsResponse.object;
          this._setPromotions(receivedPromotionsList);
        }
         this._cashPaymentService.sendSaleAutomatic(this.currentDocument).subscribe(
           respon => {
             if(respon)this.valor=0;
            }
           ,error => {
             console.log("Error en SendSaleAutomatic",error)
             this.valor = 0;
            }
         );
          return;
      },
    error =>{
      console.log('Error calcular', error)
      this.valor = 0;
    }
    );

  }
  private _setPromotions(receivedPromotionList: Array<DocumentLinePromotion>) {
    console.log(`Se aplicarán las siguientes PROMOCIONES:`);
    console.log(receivedPromotionList);
    let totalDiscountByPromotions: number = 0;
    this._clearPromotions();
    receivedPromotionList.forEach(promotion => {
      if (!this.currentDocument.lines[promotion.referredLineNumber - 1].appliedPromotionList) {
        this.currentDocument.lines[promotion.referredLineNumber - 1].appliedPromotionList = [];
      }
      this.currentDocument.lines[promotion.referredLineNumber - 1].appliedPromotionList.push(promotion);
      totalDiscountByPromotions += promotion.discountAmountWithTax;
    });
    console.log(`Total descuento aplicado al documento con las promociones: ${totalDiscountByPromotions.toString()}`);
    this.currentDocument.totalAmountWithTax = this._roundPipe.transformInBaseCurrency(
      this.currentDocument.totalAmountWithTax - totalDiscountByPromotions
    );
  }
  private _clearPromotions() {
    let calculatedTotalAmountWithTax: number = 0;
    if (this.currentDocument && this.currentDocument.lines) {
      this.currentDocument.lines.forEach((line: any) => {
        if (line.appliedPromotionList) {
          line.appliedPromotionList = [];
        }
        calculatedTotalAmountWithTax += line.totalAmountWithTax;
      });
      this.currentDocument.totalAmountWithTax = this._roundPipe.transformInBaseCurrency(calculatedTotalAmountWithTax);
    }
  }

}
