import { Component, OnInit, OnDestroy, HostBinding, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { RoundPipe } from 'app/pipes/round.pipe';
import { IActionFinalizable } from 'app/shared/iaction-finalizable';
import { Document } from 'app/shared/document/document';
import { CustomerInternalService } from 'app/services/customer/customer-internal.service';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { CurrencyPriorityType } from 'app/shared/currency/currency-priority-type.enum';
import { PaymentMethod } from 'app/shared/payments/payment-method';
import { PaymentMethodType } from 'app/shared/payments/payment-method-type.enum';
import { MixtPaymentService } from 'app/services/payments/mixt-payment.service';
import { Currency } from 'app/shared/currency/currency';
import { PaymentDetail } from 'app/shared/payments/payment-detail';
import { PaymentPurpose } from 'app/shared/payments/PaymentPurpose.enum';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';

enum CollectionButtonVisibilty {
  collection = 0,

  invoice = 1,
  both = 2
}
@Component({
  selector: 'tpv-mixt-payment',
  templateUrl: './mixt-payment.component.html',
  styleUrls: ['./mixt-payment.component.scss']
})
export class MixtPaymentComponent implements OnInit, OnDestroy, IActionFinalizable<boolean>, AfterViewInit {
  @HostBinding('class') class = 'tpv-mixt-payment';
  // para poner el foco en el input
  @ViewChild('inputPayment') inputPayment: ElementRef;

  private _onMixtPayment: Subject<boolean> = new Subject();
  private _paymentPurpose: PaymentPurpose;
  private _currentDocument: Document;
  private allowPending: boolean;
  private invoiceMandatory: boolean = false;
  private _requestingSendSale: boolean = false;
  collectionButtonVisibility: CollectionButtonVisibilty = 2;
  currencySelected: Currency;
  baseCurrency: Currency;
  secondaryCurrency: Currency;
  paymentMethodTypeWithSecondaryCurrency: PaymentMethodType;
  isUnknownCustomer: boolean = false;
  titulo: string;
  pendiente: number;
  changeDelivered: number;
  inputNumber: string;
  inputNumberInBaseCurrency: number;
  showActions: boolean;
  paymentMethodList: Array<PaymentMethod>;
  listOfPayments: Array<PaymentDetail> = [];
  changeFactorFromSecondary: number;
  selectedIndex: number;
  MsgValidateDebt: boolean = false;
  MsgValidateDebtTex: string = '';

  constructor(
    private _appDataConfig: AppDataConfiguration,
    private _mixtPaymentService: MixtPaymentService,
    private _roundPipe: RoundPipe,
    private _customerInternalService: CustomerInternalService,
    private _statusBarService: StatusBarService
  ) {
    window.addEventListener('resize', () => this._setMixtHeight());
    this.allowPending = this._appDataConfig.allowPendingPayment;
  }
  /**
   * Inicializa los valores para este componente
   * @param document contiene la informacion del pago
   * @param paymentPurpose indica el proposito del pago
   * @param invoiceMandatory indica si es obligatorio la emision de factura
   */
  setDocumentAndPaymentPurpose(document: Document, paymentPurpose: PaymentPurpose, invoiceMandatory: boolean) {
    this._currentDocument = document;
    this._paymentPurpose = paymentPurpose;
    this.invoiceMandatory = invoiceMandatory;
    this._initialize();
  }
  setInputFocus() {
    if (this.inputPayment) {
      (this.inputPayment.nativeElement as HTMLElement).focus();
      (this.inputPayment.nativeElement as HTMLElement).click();
    }
  }

  ngOnInit() {

  }

  ngOnDestroy() {
  }

  ngAfterViewInit(): void {
    this._setMixtHeight();
    // NOTA: hack timeout para ejecutar funciones estando ya renderizado el HTML
    setTimeout(() => {
      this.setInputFocus();
    });
    // al inicializarse la vista hago click en el input para que aparezca el teclado
    this.triggleClickEventOnInput();
  }


  onFinish(): Observable<boolean> {
    return this._onMixtPayment.asObservable();
  }

  forceFinish(): void {
    this._onMixtPayment.next(undefined);
  }

  setInputNumber(numero: string): void {
    const str: string = this.inputNumber.toString() + numero;
    this.inputNumber = str;
  }

  // al clicar en un método de pago le sugiere la cantidad exacta que falta por pagar
  payment(index: number) {
    if (this.pendiente > 0) {
      this.selectedIndex = index;
      this.inputNumber = this._roundPipe.transformInBaseCurrency(this.pendiente).toString();
      // si es segunda divisa se calcula la cantidad a sugerir en dicha divisa
      if (this.paymentMethodList && this.paymentMethodList[index] &&
        this.paymentMethodList[index].currencyType == CurrencyPriorityType.secondary) {
        this.currencySelected = this._appDataConfig.getCurrencyByType(this.paymentMethodList[index].currencyType);
        this.inputNumber = this.inputNumberToSecundaryCurrencySupplyingPending((Number)(this.inputNumber)).toString();
        this.setInfoAboutPaymentSecondaryCurrency();
      }
      // NOTA: hack timeout para ejecutar funciones estando ya cambiado el HTML
      setTimeout(() => {
        this.setInputFocus();
      });
    }
  }

  // si es la segunda divisa, se recomienda el pago en esa divisa
  // mientras no se supla la cantidad pendiente se suma la cantidad correspondiente
  inputNumberToSecundaryCurrencySupplyingPending(inputNumber: number): number {
    // cantidad a introducir a segunda divisa y con decimales posibles
    let inputNumberToSecundaryCurrency = this._convertBaseToSecondary((Number)(inputNumber));
    // convertimos ese valor a la moneda base para saber si al recortar decimales no se llega a la cantidad a pagar
    let inputNumberToBaseCurrency = this._convertSecondaryToBase((Number)(inputNumberToSecundaryCurrency));
    // si no se llega a la cantidad a pagar se empiezan a sumar decimales hasta llegar a la cantidad
    while (inputNumberToBaseCurrency < this.pendiente) {
      inputNumberToSecundaryCurrency += (1 / Math.pow(10, this.secondaryCurrency.decimalPositions));
      inputNumberToSecundaryCurrency = this._roundPipe.transformInSecondaryCurrency(inputNumberToSecundaryCurrency);
      inputNumberToBaseCurrency = this._convertSecondaryToBase((Number)(inputNumberToSecundaryCurrency));
    }
    return inputNumberToSecundaryCurrency;
  }

  // si el importe a introducir es modificado con segunda divisa,
  // se actualiza el valor del dinero pendiente mostrado en divisa base en la UI
  setInfoAboutPaymentSecondaryCurrency() {
    if (this.selectedIndex && this.paymentMethodList) {
      if (this.paymentMethodList[this.selectedIndex].currencyType == CurrencyPriorityType.secondary) {
        this.inputNumberInBaseCurrency =
          this._roundPipe.transformInBaseCurrency(this._convertSecondaryToBase((Number)(this.inputNumber)));
      }
    }
  }

  // se introduce una cantidad de dinero a pagar y se recalculan datos como el pendiente y el cambio
  setPayment(): void {
    if (this._validatePayment() == true) {
      if (this.paymentMethodList[this.selectedIndex].type !== PaymentMethodType.cash && Number(this.inputNumber) >= this.pendiente) {
        // si no es efectivo y se introduce más cantidad de lo que hay que pagar
        // se inserta como cantidad introducida SOLO lo que haya que pagar
        this._insertPayment(this.paymentMethodList[this.selectedIndex], this.pendiente, this.pendiente);
        this.pendiente = 0;
      } else {
        // si es efectivo o se introduce una cantidad menor que el pendiente
        // se inserta como cantidad introducida la que haya sido
        // se calcula el nuevo pendiente y el posible cambio solo si es efectivo
        this._insertPayment(this.paymentMethodList[this.selectedIndex], Number(this.inputNumber), this.pendiente);
        this.pendiente -= Number(this.inputNumber);
        this.pendiente = this._roundPipe.transformInBaseCurrency(this.pendiente);
        if (this.pendiente <= 0) {
          this.changeDelivered = -(this.pendiente);
        }
      }
    }
    // si ya se ha llegado al pendiente se mira si hay cambio y se muestran acciones
    if (this.pendiente <= 0) {
      this.pendiente = 0;
      this._changeVisibilityActions(true);
    }
    this._resetPaymentIntroduction();
  }

  // se borran todos los pagos introducidos y se resetean los valores
  deleteAllPayments() {
    this.pendiente = this._currentDocument.totalAmountWithTax;
    this.listOfPayments = [];
    this.changeDelivered = 0;

    if ( this._currentDocument.customer.id.substring(5) === '00000') {
      this._changeVisibilityActions(false);
    }
    this._changeVisibilityActions(false);
  }

  // se actualiza el cambio, el pendiente y se dejan de mostrar los botones de finalizar acción
  deleteFromlistOfPayments(item: PaymentDetail) {

    let sumGiven = 0, metallicPayment: PaymentDetail, indexPaymentDelete: number;
    // sumamos las cantidades cogidas salvo del pago a eliminar
    this.listOfPayments.forEach((payment, index) => {
      if (payment.paymentMethodId == item.paymentMethodId && payment.currencyId == item.currencyId) {
        indexPaymentDelete = index;
        // si es el metodo a eliminar, no hacemos nada
        return;
      }
      sumGiven += payment.primaryCurrencyGivenAmount;
      if (payment.method.type == PaymentMethodType.cash) {
        metallicPayment = payment;
      }
    });
    // si el el given es superior al total del documento, existira cambio, solo si existe metalico
    if (sumGiven > this._currentDocument.totalAmountWithTax && metallicPayment != undefined) {
      this.changeDelivered = this._roundPipe.transformInBaseCurrency(sumGiven - this._currentDocument.totalAmountWithTax);
      // actualizo la cantidad taken del medio de pago metalico
      metallicPayment.primaryCurrencyTakenAmount =
        this._roundPipe.transformInBaseCurrency(metallicPayment.primaryCurrencyGivenAmount - this.changeDelivered);
      if (metallicPayment.secondaryCurrencyGivenAmount != undefined) {
        metallicPayment.secondaryCurrencyTakenAmount =
          this._roundPipe.transformInSecondaryCurrency(metallicPayment.primaryCurrencyTakenAmount * metallicPayment.changeFactorFromBase);
      }
      this.pendiente = 0;
    } else {
      // given es inferior o igual al total. O no hay metalico
      this.changeDelivered = 0; // no puede haber cambio si no hay metalico
      this.pendiente = this._roundPipe.transformInBaseCurrency(this._currentDocument.totalAmountWithTax - sumGiven);
      if (metallicPayment != undefined) {
        metallicPayment.primaryCurrencyTakenAmount = metallicPayment.primaryCurrencyGivenAmount;
        if (metallicPayment.secondaryCurrencyGivenAmount != undefined) {
          metallicPayment.secondaryCurrencyTakenAmount =
            this._roundPipe.transformInSecondaryCurrency(metallicPayment.primaryCurrencyTakenAmount * metallicPayment.changeFactorFromBase);
        }
      }

    }
    this._changeVisibilityActions(this.pendiente <= 0);
    this.listOfPayments.splice(indexPaymentDelete, 1);

    // actualiza cantidad ofrecida si hay método de pago seleccionado
    if (this.selectedIndex != undefined) {
      this.payment(this.selectedIndex);
    }
    this._setDefaultSelectedPaymentMethod();
  }

  triggleClickEventOnInput() {
    // valido que el click solo se hará solo si hay dinero pendiente
    if (this.pendiente > 0) {
      // Despacho click event en el input para que se abra el teclado
      // Create the event.
      const event = document.createEvent('Event');
      // init event
      event.initEvent('click', false, true);
      // dispatch event
      this.inputPayment.nativeElement.dispatchEvent(event);
    }
  }
  /*********************
   * VIEW COLLECT ACTIONS
   * ******************/
  requestInvoiceClick() {
    this.requestEndSale(true);
  }
  requestCollectClick() {
    this.requestEndSale(false);
  }
  isButtonDisabled() {
    return this._requestingSendSale;
  }
  private _changeVisibilityActions(showActionsVisibility: boolean) {
    // muestra acciones si se permite pago pendiente a clientes identificados o si expresamente se indica
    this.showActions = (this.allowPending && !this._customerInternalService.isUnknownCustomer(this._currentDocument.customer.id))
      || showActionsVisibility;
  }

  private _validatePayment(): boolean {
    // debe de haber un método de pago seleccionado
    if (this.selectedIndex == undefined) {
      return false;
    }
    // solo se añade pago si aún queda dinero pendiente
    if (this.pendiente <= 0) {
      return false;
    }
    // no se puede introducir una cantidad 0
    const inputAmount = (Number)(this.inputNumber);
    if (isNaN(inputAmount) || inputAmount <= 0) {
      return false;
    }
    // solo cantidades con x o menos decimales según divisa
    this._validateInputNumber();
    return true;
  }

  // no se permite introducir más decimales de los que permite la divisa
  // redondeamos el número según los decimales que si están permitidos
  private _validateInputNumber(): void {
    const inputNumberString = this.inputNumber + '';
    if (inputNumberString) {
      const decimalsOfNumber = inputNumberString.split('.')[1];
      if (decimalsOfNumber && this.currencySelected && decimalsOfNumber.length > this.currencySelected.decimalPositions) {
        if (this.currencySelected.priorityType == CurrencyPriorityType.base) {
          this.inputNumber = this._roundPipe.transformInBaseCurrency((Number)(this.inputNumber)).toString();
        } else {
          this.inputNumber = this._roundPipe.transformInSecondaryCurrency((Number)(this.inputNumber)).toString();
        }
      }
    }
  }

  // resetea datos de la introducción de un pago (pendiente y medio de pago seleccionado por defecto)
  private _resetPaymentIntroduction() {
    this.inputNumber = '0';
    this._setDefaultSelectedPaymentMethod();
  }

  // Se inserta un pago con un método de pago. Si es correcto se actualizan las cuantías pendientes y el cambio
  // Si ya se introdujo una cantidad de un método de pago, se suma a dicho método en la tabla
  // Si es a un nuevo método de pago se crea una nueva fila para dicho método
  private _insertPayment(metodo: PaymentMethod, givenInputAmount: number, pendiente: number) {
    let secondaryGivenAmount, secondaryTakenAmount;
    const currencyPaymentMethod = this._appDataConfig.getCurrencyByType(metodo.currencyType);
    // si metodo es con segunda moneda se guarda en SECONDARYAMOUNT y los datos se convierten a divisa base
    if (metodo.currencyType == CurrencyPriorityType.secondary) {
      secondaryGivenAmount = givenInputAmount;
      const pendingPayment = this._roundPipe.transformInBaseCurrency(this.pendiente);
      const inputPaymentToSupplyPending = this.inputNumberToSecundaryCurrencySupplyingPending(pendingPayment);
      secondaryTakenAmount = this._getTakenAmount(givenInputAmount, inputPaymentToSupplyPending);
      givenInputAmount = this._convertSecondaryToBase(givenInputAmount);
      // la cantidad insertada se vuelve a pasar a base para el resto de calculos
      this.inputNumber = givenInputAmount.toString();
    }
    // se obtiene el dinero dado del cliente y el obtenido finalmente por el tpv
    const takenAmount = this._getTakenAmount(givenInputAmount, pendiente);
    // se actualiza método o se introduce nuevo según si ya existe o no
    const index = this._listOfPaymentsContainsPayment(metodo.id, currencyPaymentMethod.id);
    if ((index >= 0) && (metodo.type == PaymentMethodType.cash)) {
      this.listOfPayments[index].primaryCurrencyTakenAmount += takenAmount;
      this.listOfPayments[index].primaryCurrencyGivenAmount += givenInputAmount;
    } else {
      this.listOfPayments.unshift({
        paymentMethodId: metodo.id,
        paymentDateTime: new Date(),
        currencyId: currencyPaymentMethod.id,
        changeFactorFromBase: currencyPaymentMethod.changeFactorFromBase,
        primaryCurrencyTakenAmount: takenAmount,
        primaryCurrencyGivenAmount: givenInputAmount,
        secondaryCurrencyTakenAmount: secondaryTakenAmount,
        secondaryCurrencyGivenAmount: secondaryGivenAmount,
        method: metodo
      });
    }
  }

  // obtiene el valor monetario que guarda el TPV
  // si se da más dinero que el pendiente, el TPV solo guardará el pendiente
  // si se da menos dinero que el pendiente, el TPV guardará solo la cantidad introducida
  private _getTakenAmount(givenInputAmount: number, pendiente: number) {
    if (pendiente >= givenInputAmount) {
      return givenInputAmount;
    } else {
      return pendiente;
    }
  }

  // ej: si la base es €, 1 euro son 166.386 pesetas
  private _convertBaseToSecondary(amount: number): number {
    let amountInSecondaryCurrency;
    if (this.secondaryCurrency) {
      amountInSecondaryCurrency = this._roundPipe.transformInSecondaryCurrency(amount * this.secondaryCurrency.changeFactorFromBase);
    }
    return amountInSecondaryCurrency;
  }

  // ej: si la base es €, 1 euro son 166.386 pesetas
  private _convertSecondaryToBase(amount: number): number {
    let amountInBaseCurrency;
    if (this.secondaryCurrency) {
      amountInBaseCurrency = this._roundPipe.transformInBaseCurrency(amount / this.secondaryCurrency.changeFactorFromBase);
    }
    return amountInBaseCurrency;
  }

  // compruebo que el metodo de pago no esta en el array y si lo esta devuelvo el indice del mismo
  private _listOfPaymentsContainsPayment(paymentMethodId: string, currencyId: string): number {
    return this.listOfPayments.findIndex(it => it.paymentMethodId == paymentMethodId && it.currencyId == currencyId);
  }

  // inicializa los métodos de pago y otros datos (pendiente, si hay cliente contado...)
  // se añade método de pago que tenga divisa secundaria a parte de la base
  private _initialize() {
    // permite acciones si se admite el pago pendiente
    this.showActions = !this._customerInternalService.isUnknownCustomer(this._currentDocument.customer.id) && this.allowPending;
    // datos constantes
    switch (this._paymentPurpose) {
      case PaymentPurpose.NewDocument:
        this.titulo = 'PAGO MIXTO';
        this.pendiente = this._currentDocument.totalAmountWithTax;
        this.collectionButtonVisibility = CollectionButtonVisibilty.both;
        break;
      case PaymentPurpose.PendingPayment:
        this.titulo = 'PAGO MIXTO';
        this.pendiente = this._currentDocument.pendingAmountWithTax;
        this.collectionButtonVisibility = CollectionButtonVisibilty.collection;
        break;
      case PaymentPurpose.Refund:
        this.titulo = 'DEVOLUCIÓN';
        this.pendiente = -this._currentDocument.totalAmountWithTax;
        this.collectionButtonVisibility = CollectionButtonVisibilty.collection;
        break;
      default:
    }
    if (this.invoiceMandatory) {
      this.collectionButtonVisibility = CollectionButtonVisibilty.invoice;
    }
    this.listOfPayments = [];
    this.changeDelivered = 0;
    this.inputNumber = '0';
    // divisas
    this.currencySelected = this.baseCurrency = this._appDataConfig.baseCurrency;
    this.secondaryCurrency = this._appDataConfig.secondaryCurrency;
    this.paymentMethodTypeWithSecondaryCurrency = PaymentMethodType.cash;
    // pendiente y saber si el cliente es contado o no
    if (this._currentDocument != undefined) {
      this.isUnknownCustomer = this._currentDocument.customer == undefined ?
        true
        : this._customerInternalService.isUnknownCustomer(this._currentDocument.customer.id);
    }
    // lista de los métodos de pago teniendo en cuenta las divisas
    if (this._appDataConfig.paymentMethodList != undefined) {
      this.paymentMethodList = this._appDataConfig.paymentMethodList.filter(p => p.type !== PaymentMethodType.runaway);
    }
    // pagos con segunda divisa
    this._addTypeCurrencyPaymentMethod();
    if (this.secondaryCurrency) {
      this._addPaymentMethodSecondaryCurrency(this.paymentMethodTypeWithSecondaryCurrency);
    }
    this._setDefaultSelectedPaymentMethod();
  }


  // medio de pago seleccionado por defecto y actualiza cantidad recomendada a introducir como próximo pago
  private _setDefaultSelectedPaymentMethod() {
    if (this.paymentMethodList && this.paymentMethodList.length > 0 && this.pendiente > 0) {
      this.selectedIndex = 0;
      this.payment(this.selectedIndex);
    } else {
      this.selectedIndex = undefined;
    }
  }

  // se especifica el tipo de divisa para cada método de pago
  // si en lista divisas hay segunda divisa, se añade a los tipos de pago
  private _addTypeCurrencyPaymentMethod() {
    this.paymentMethodList.forEach(paymentMethod => {
      paymentMethod.currencyType = CurrencyPriorityType.base;
    });
    if (this.secondaryCurrency) {
      this.changeFactorFromSecondary = this._roundPipe.transformInBaseCurrency(1 / this.secondaryCurrency.changeFactorFromBase);
    }
  }

  // duplica el método de pago, uno con la divisa base y otro con la secundaria
  // NOTA: la segunda divisa de momento solo para el pago en efectivo
  private _addPaymentMethodSecondaryCurrency(paymentMethodTypeWithSecondaryCurrency: PaymentMethodType) {
    const paymentMethod: PaymentMethod = this._appDataConfig.getPaymentMethodByType(paymentMethodTypeWithSecondaryCurrency);
    const paymentMethodSecondary: PaymentMethod = Object.assign({}, paymentMethod);
    if (paymentMethodSecondary && this.paymentMethodList != undefined) {
      // tipo de divisa
      paymentMethodSecondary.currencyType = this.secondaryCurrency.priorityType;
      paymentMethod.currencyType = this._appDataConfig.baseCurrency.priorityType;
      // cambiamos la descripción para que se vea en UI el símbolo divisa
      paymentMethodSecondary.panelDescription = this.secondaryCurrency.symbol;
      paymentMethod.panelDescription = this.baseCurrency.symbol;
      // se elimina el tipo de pago original y se añaden los dos (con divisa base y con secundaria)
      this.paymentMethodList = this.paymentMethodList.filter(p => p.id !== paymentMethod.id);
      this.paymentMethodList.unshift(paymentMethodSecondary);
      this.paymentMethodList.unshift(paymentMethod);
    }
  }

  // se envia la venta con los métodos de pago y cuantías que se hayan elegido
  private requestEndSale(emitirFactura: boolean) {

    if (this._currentDocument.customer.id.substring(5) !== '00000') {
      if (emitirFactura) {

              const tipoCombustible = this._currentDocument.lines.filter( (item) => item.typeArticle.indexOf('COMBU') > 0 ).length;
              const totalProductos = this._currentDocument.lines.length;
              if ( this.pendiente !== 0) {
                this._statusBarService.publishMessage('Debe Pagar Completamente la Factura');
                return;
              }
              if (totalProductos == tipoCombustible ) {
               this._statusBarService.publishMessage('La Factura solo se genera con productos diferentes de pista o Mixtos');
               return ;
              }
      } else {
        const parm = this._appDataConfig.getConfigurationParameterByName('TYPE_ARTICLE_DEBTS', 'TPV') ;
           if (this._currentDocument.documentId == '' || this._currentDocument.documentId == undefined) {
                  if ( parm !== undefined) {
                  const tipoArticuloNoValidoDeudas =
                   this._currentDocument.lines.filter(item => item.typeArticle.indexOf(parm.meaningfulStringValue) < 0).length;
                      if ( tipoArticuloNoValidoDeudas >= 1 && this.pendiente !== 0 ) {
                            if (parm.meaningfulStringValue == 'COMBU') {
                              this.MsgValidateDebtTex = 'La deuda solo puede ser de productos de Combustibles';
                            } else {
                              this.MsgValidateDebtTex = 'La deuda solo puede ser de productos de Tienda';
                            }
                            this.MsgValidateDebt = true;
                            return;
                      }
                    }
              }
        }
    }

    if (this._requestingSendSale) {
      return;
    }
    this._requestingSendSale = true;
    this._mixtPaymentService
      .requestEndSale(this._currentDocument, this.listOfPayments, emitirFactura,
        this._paymentPurpose, this.changeDelivered, this.pendiente)
      .first().subscribe(endSaleResult => {
        this._mixtPaymentService.manageSaleEnded(endSaleResult);
        this._requestingSendSale = false;
        this._onMixtPayment.next(endSaleResult);
      });
  }
  private _setMixtHeight() {
    const calcBtnHeight = Number(jQuery('.tpv-mixt-payment .tpv-mixt-input').css('height').replace('px', ''));
    const calcBtnBottomHeight = Number(jQuery('.tpv-mixt-payment .button-bottom').css('height').replace('px', ''));
    const calcTitleHeight = Number(jQuery('.tpv-mixt-payment .auxiliar-action-title').css('height').replace('px', ''));
    const calcHeight = jQuery('.tpv-actions').height() -
      (10 + calcBtnHeight + calcTitleHeight + calcBtnBottomHeight +
        jQuery('.tpv-mixt-payment .tpv-mixt-payment-method').height() +
        jQuery('.tpv-mixt-payment .tpv-mixt-payment-amount').height());
    jQuery('.tpv-mixt-payment .divOverflow').css('height', calcHeight);
  }


}
