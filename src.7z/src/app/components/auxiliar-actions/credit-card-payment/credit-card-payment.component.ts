import { Component, OnInit, OnDestroy, HostBinding } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';

import { IActionFinalizable } from 'app/shared/iaction-finalizable';
import { Document } from 'app/shared/document/document';
import { ConfirmActionService } from 'app/services/confirm-action/confirm-action.service';
import { CreditCardPaymentService } from 'app/services/payments/credit-card-payment.service';
import { SignalRPaymentTerminalService } from 'app/services/signalr/signalr-payment-terminal.service';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { ConfigurationParameterType } from 'app/shared/configuration-parameter-type.enum';
import { ConfirmActionType } from 'app/shared/confirmAction/confirm-action-type.enum';
import { Currency } from 'app/shared/currency/currency';
import { CurrencyPriorityType } from 'app/shared/currency/currency-priority-type.enum';
import { PaymentTerminalResponse } from 'app/shared/signalr-server-responses/paymentTerminalHub/payment-terminal-reponse';
import { PaymentTerminalResponseStatuses } from 'app/shared/signalr-server-responses/paymentTerminalHub/payment-terminal-response-statuses.enum';

@Component({
  selector: 'tpv-credit-card',
  templateUrl: './credit-card-payment.component.html',
  styleUrls: ['./credit-card-payment.component.scss']
})
export class CreditCardPaymentComponent implements OnInit, OnDestroy, IActionFinalizable<boolean> {
  @HostBinding('class') class = 'tpv-credit-card';

  private _onCreditCardPayment: Subject<boolean> = new Subject();
  private _subscriptions: Subscription[] = [];
  private _stringedTerminalResponse: string = '';
  private _invoice = false;
  private _paymentTerminalResponse: boolean = false;
  /**
   * Indica que se ha lanzado la peticion de sendSale, evita la repeticion de llamadas
   */
  private _requestingSendSale: boolean = false;
  titulo: string;
  subtitulo: string;
  imageURL: string;
  textButton: string;
  currentDocument: Document;
  baseCurrency: Currency;
  paymentFailedLiteral: string;
  acceptLiteral: string;
  errorHeaderLiteral: string;
  paymentSucceedLiteral: string;
  mainTextComponentLiteral: string;
  requestingPaymentLiteral: string;
  clickOnFinishLiteral: string;

  constructor(
    private _appDataConfig: AppDataConfiguration,
    private _creditCardService: CreditCardPaymentService,
    private _SignalRPaymentTerminalService: SignalRPaymentTerminalService,
    private _confirmActionService: ConfirmActionService,
    private _statusBarService: StatusBarService) {
    this.paymentFailedLiteral = 'El terminal rechazó el cobro.';
    this.acceptLiteral = 'ACEPTAR';
    this.errorHeaderLiteral = 'ERROR';
    this.paymentSucceedLiteral = 'Cobro efectuado satisfactoriamente.';
    this.mainTextComponentLiteral = 'Por favor, realiza la venta en el terminal';
    this.requestingPaymentLiteral = 'Solicitando cobro al terminal de pago...';
    this.clickOnFinishLiteral = ' Pulse finalizar para terminar.';
    this.titulo = 'PAGO CON TARJETA';
    this.subtitulo = 'Pendiente';
    // TODO conseguir la url de la imagen desde el demonio
    this.imageURL = 'https://preproduccion.everilion.com/maquetas/tpv-repsol/v6/css/images/img_yomova.png';
    this.textButton = 'FINALIZAR';
  }

  ngOnInit() {
    // datos de la divisa
    this.baseCurrency = this._appDataConfig.currencyList.find(c => c.priorityType == CurrencyPriorityType.base);
    if (!this.baseCurrency) {
      console.log('DocumentComponent-> WARNING: No se ha podido recuperar la divisa base');
    }

    const isPaymentTerminalAutomaticPaymentEnabled =
      this._appDataConfig.getConfigurationParameterByType(ConfigurationParameterType.IsPaymentTerminalAutomaticPaymentEnabled);
    if (isPaymentTerminalAutomaticPaymentEnabled != undefined && isPaymentTerminalAutomaticPaymentEnabled.meaningfulStringValue == 'true') {
      this._statusBarService.publishMessage(this.requestingPaymentLiteral);
      this._paymentTerminalResponse = false;
      this._SignalRPaymentTerminalService.salePayment(this.currentDocument.totalAmountWithTax)
        .first().subscribe((result: PaymentTerminalResponse) => {
          if (result.status == PaymentTerminalResponseStatuses.successful) {
            this._statusBarService.publishMessage(this.paymentSucceedLiteral + this.clickOnFinishLiteral);
            console.log('Información del cobro realizado: ' + result.stringedTerminalResponse);
            this._stringedTerminalResponse = result.stringedTerminalResponse;
            this.mainTextComponentLiteral = this.paymentSucceedLiteral;
            this._paymentTerminalResponse = true;
          } else {
            console.log('No se pudo realizar la operación de cobro por la siguiente razón: ' + result.message);
            this._confirmActionService.promptActionConfirm(
              this.paymentFailedLiteral,
              this.acceptLiteral,
              undefined,
              this.errorHeaderLiteral,
              ConfirmActionType.Error)
              .first().subscribe(r =>
                this._onCreditCardPayment.next(false)
              );
          }
        }
        );
    } else {
      this._stringedTerminalResponse = '';
      this.mainTextComponentLiteral = this.mainTextComponentLiteral;
      this._paymentTerminalResponse = true;
    }
    this._subscriptions.push(this._creditCardService.onPaymentFinalized()
      .subscribe(success => {
        this._onPaymentFinalized(success);
      }));
  }

  ngOnDestroy() {
    this._subscriptions.forEach(s => s.unsubscribe());
  }
  setInitialData(document: Document, invoice: boolean) {
    this.currentDocument = document;
    this._invoice = invoice;
  }
  onFinish(): Observable<boolean> {
    return this._onCreditCardPayment.asObservable();
  }

  forceFinish(): void {
    this._onCreditCardPayment.next(undefined);
  }

  documentHasValue(document: Document): boolean {
    return this.currentDocument != undefined;
  }
  isButtonDisabled():boolean{
    return this._requestingSendSale 
    || !this._paymentTerminalResponse 
    || this.currentDocument.totalAmountWithTax == 0;
  }
  // envia venta con tarjeta de credito a servicio
  sendSale() {
    if (this._requestingSendSale){
      return;
    }
    this._requestingSendSale = true;
    console.log('SendSale documento:');
    console.log(this.currentDocument);
    this._creditCardService.sendSale(this.currentDocument, this._invoice, this._stringedTerminalResponse);
  }
  private _onPaymentFinalized(success: boolean) {
    this._paymentTerminalResponse = false;
    this._requestingSendSale = false;
    this._creditCardService.managePaymentFinalized(success);
    this._onCreditCardPayment.next(success);
  }
}
