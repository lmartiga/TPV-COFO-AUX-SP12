import { Component, OnInit } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { IActionFinalizable } from 'app/shared/iaction-finalizable';
import { ConfirmActionType } from 'app/shared/confirmAction/confirm-action-type.enum';
interface ActionButton {
  class: string;
  text: string;
  actionClick: Function;
}
@Component({
  selector: 'tpv-confirm-action',
  templateUrl: './confirm-action.component.html',
  styleUrls: ['./confirm-action.component.scss']
})
export class ConfirmActionComponent implements OnInit, IActionFinalizable<boolean> {

  private _onConfirmAction: Subject<boolean> = new Subject();
  // default icon
  materialIcon: string = 'warning';
  // default text
  textQuestion: string = '¿Está seguro?';
  // default title
  textTitle: string = 'Confirmar Acción';
  // default type
  type: ConfirmActionType = ConfirmActionType.Warning;
  // availaleButtons
  confirmActions = new Array<ActionButton>();
  constructor() { }

  /* IActionFinalizable */
  onFinish() {
    return this._onConfirmAction.asObservable();
  }
  forceFinish() {
    this._onConfirmAction.next(undefined);
  }
  /* end IActionFinalizable*/
  ngOnInit() {
  }
  confirmAction(
    textQuestion: string = '¿Está seguro?',
    textYes: string = 'Sí',
    textNo: string = 'No',
    title: string = 'Confirmar Acción',
    type: ConfirmActionType = ConfirmActionType.Warning,
  ) {
    this.textQuestion = textQuestion;
    this.textTitle = title;
    this.type = type;
    const bootstrap50 = 'col-xs-6';
    const bootstrap100 = 'col-xs-12';
    switch (type) {
      case ConfirmActionType.Alert:
        this.materialIcon = 'warning';
        this.addActionButton(textYes, bootstrap50, () => this.actionYes());
        break;
      case ConfirmActionType.Warning:
        this.materialIcon = 'warning';
        this.addActionButton(textYes, bootstrap50, () => this.actionYes());
        this.addActionButton(textNo, bootstrap50, () => this.actionNo());
        break;
      case ConfirmActionType.Question:
        this.materialIcon = 'help';
        this.addActionButton(textYes, bootstrap50, () => this.actionYes());
        this.addActionButton(textNo, bootstrap50, () => this.actionNo());
        break;
      case ConfirmActionType.Error:
      case ConfirmActionType.Information:
        this.materialIcon = 'highlight_off';
        this.addActionButton(textYes, bootstrap100, () => this.actionYes());
        break;
      case ConfirmActionType.None:
      default:
        this.materialIcon = 'highlight_off';
        break;
    }
  }

  private actionYes() {
    this._onConfirmAction.next(true);
  }

  private actionNo() {
    this._onConfirmAction.next(false);
  }

  setClassIcon() {
    return {
      'coacIcon': true,
      'iconAlert': this.type == ConfirmActionType.Alert,
      'iconError': this.type == ConfirmActionType.Error,
      'iconInformation': this.type == ConfirmActionType.Information,
      'iconWarning': this.type == ConfirmActionType.Warning,
      'iconQuestion': this.type == ConfirmActionType.Question
    };
  }

  // inserta un boton de accion para el cuadro
  private addActionButton(text: string, bootstrapClass: string, action: Function): void {
    this.confirmActions.push({
      class: `noP ${bootstrapClass}`,
      text: text,
      actionClick: action
    });
  }

}
