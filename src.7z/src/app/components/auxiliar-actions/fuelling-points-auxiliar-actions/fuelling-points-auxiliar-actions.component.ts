import { Component, OnInit, ViewChild, HostBinding, Input } from '@angular/core';
import { FuellingPointInfo } from 'app/shared/fuelling-point/fuelling-point-info';
import { IActionFinalizable } from 'app/shared/iaction-finalizable';
import { Subject } from 'rxjs/Subject';
import { FuellingPointsService } from 'app/services/fuelling-points/fuelling-points.service';
import { MdButtonToggleGroup, MdButtonToggle } from '@angular/material';
import { FuellingPointsInternalService } from 'app/services/fuelling-points/fuelling-points-internal.service';
import { Grade } from 'app/shared/fuelling-point/grade';
import { FuellingPointAvailableActionType } from 'app/shared/fuelling-point/signalR-Response/fuelling-point-available-action-type';
import { FuellingPointsSignalrUpdatesService } from 'app/services/fuelling-points/fuelling-points-signalr-updates.service';
import { IDictionaryStringKey } from 'app/shared/idictionary';
import { FuellingPointFormatConfiguration } from 'app/shared/fuelling-point/fuelling-point-format-configuration';
import { ServiceModeType } from 'app/shared/fuelling-point/service-mode-type.enum';
import { FuellingPointMainStates } from 'app/shared/fuelling-point/fuelling-point-main-states.enum';
import { FuellingLimit } from 'app/shared/fuelling-point/fuelling-limit';
import { FuellingLimitType } from 'app/shared/fuelling-point/fuelling-limit-type.enum';
import { SuplyTransaction } from 'app/shared/fuelling-point/suply-transaction';
import { OnDestroy } from '@angular/core/src/metadata/lifecycle_hooks';
import { Subscription } from 'rxjs/Subscription';
import { AppDataConfiguration } from 'app/config/app-data.config';

interface ActionButton {
  class: string;
  text: string;
  actionClick: Function;
}
@Component({
  selector: 'tpv-fuelling-points-auxiliar-actions',
  templateUrl: './fuelling-points-auxiliar-actions.component.html',
  styleUrls: ['./fuelling-points-auxiliar-actions.component.scss']
})
export class FuellingPointAuxiliarActionsComponent implements OnInit, OnDestroy, IActionFinalizable<boolean> {
  @HostBinding('class') class = 'tpv-fuelling-points-auxiliar';
  @ViewChild('groupMode') modeSelector: MdButtonToggleGroup;
  @ViewChild('groupFuelProducts') fuelProductSelector: MdButtonToggleGroup;
  @Input() fpInformation: Array<FuellingPointInfo>;

  private _onFuellingPointAuxiliarActionsComplete: Subject<boolean> = new Subject();
  private _subscriptions: Subscription[] = [];
  private _posCode: number;

  // sirve para bloquear multiples request (click repetido)
  private _requestPending = false;
  private fuellingPointActive: Array<FuellingPointInfo> = [] ;
  private fuellingPointOrigen: FuellingPointInfo;
  textFuellingActives: string;
  // cantidad monetaria para input 'otro'
  otherAmmount: number;
  // cantidad volumen para input 'otro'
  otherVolume: number;
  // receives the actions for the fuellingPoint
  availableActions: Array<FuellingPointAvailableActionType>;
  // configuracion de formatos
  formatConfig: FuellingPointFormatConfiguration;
  fuellingPointInfo: FuellingPointInfo;
  fuellingHeaderActions: Array<ActionButton>;
  fuellingBottomActions: Array<ActionButton>;
  // texto que se muestra para informar de error, o sobre bloqueo del tpv
  textInformation: string;
  canChooseFuel: boolean;
  // operaciones pendientes
  supplyTransactions: Array<SuplyTransaction>;

  constructor(
    private _fpSvc: FuellingPointsService,
    private _fpInternalSvc: FuellingPointsInternalService,
    private _fpSignalRresponse: FuellingPointsSignalrUpdatesService,
    private _appDataConfig: AppDataConfiguration
  ) { }

  set fuellingPoint(fuellingPoint: FuellingPointInfo) {
    if (fuellingPoint == undefined) {
      console.log('fuelling point recibido en fp auxiliar actions component es undefined');
      return;
    }
    this.fuellingPointInfo = fuellingPoint;
    // retrieve pump info from server
    this._requestAvailableActions();
    this._requestSupplyTransactions();
  }

  onFinish() {
    return this._onFuellingPointAuxiliarActionsComplete.asObservable();
  }

  forceFinish() {
    this._onFuellingPointAuxiliarActionsComplete.next(false);
  }

  closePumpAuxiliar(response: boolean) {
    this._onFuellingPointAuxiliarActionsComplete.next(response);
  }

  ngOnInit() {
    this.formatConfig = this._fpInternalSvc.formatConfiguration;
    this._posCode = this._fpInternalSvc.ownForecourtPOSId;
    this._subscriptions.push(this._fpSignalRresponse.onFuellingPointTransactionCountChange()
      .subscribe(response => {
        // si hay un cambio en las transacciones de este surtidor, las recuperamos
        if (this.fuellingPointInfo != undefined && response.fuellingPointId == this.fuellingPointInfo.id) {
          this._requestSupplyTransactions();
        }
      }));
  }

  ngOnDestroy() {
    this._subscriptions.forEach(s => s.unsubscribe());
  }

  /**
   * Recupera la imagen en base 64 del grado
   * @param idGrade id del grado
   */
  getImgFromGrade(idGrade: number): string {
    return this._fpInternalSvc.getImgFromGrade(idGrade);
  }

  /**
   * Maneja el evento de introducir una cantidad en el panel, ya sea autorizar o limitar
   * @param quantity cantidad introducida
   */
  btnAmountClick(quantity: number) {
    if (quantity <= 0) { return; }
    const product: Grade = this.fuelProductSelector.value;
    const limit: FuellingLimit = {
      type: FuellingLimitType.Monetary,
      value: quantity
    };
    const isAutorizeModeSelected = this.isAutorizeModeSelected();
    if (isAutorizeModeSelected == undefined) {
      return;
    }
    isAutorizeModeSelected ?
      this.requestPreparePreset(limit, product) :
      this.requestPreparePrepaidOperation(limit, product);
  }

  /**
   * Maneja el evento de introducir un volumen en el panel
   * @param quantity cantidad en volumen introducida
   */
  btnVolumeClick(quantity: number) {
    if (quantity <= 0) { return; }
    const product: Grade = this.fuelProductSelector.value;
    const limit: FuellingLimit = {
      type: FuellingLimitType.Volume,
      value: quantity
    };
    const isAutorizeModeSelected = this.isAutorizeModeSelected();
    if (isAutorizeModeSelected == undefined) {
      return;
    }
    isAutorizeModeSelected ?
      this.requestPreparePreset(limit, product) :
      this.requestPreparePrepaidOperation(limit, product);
  }

  /**
   * Obtiene un json valido para ngClass para establecer estilo de cabecera
  */
  setClassHeader(): IDictionaryStringKey<boolean> {
    return this._fpInternalSvc.getNgClassBackGroundColor(this.fuellingPointInfo);
  }

  /**
   * Obtiene json valido para ngClass para establecer estilo de la operacion en espera
   * @param operation transaccion en espera
   */
  setClassSupplyTransaction(operation: SuplyTransaction): IDictionaryStringKey<boolean> {
    return this._fpInternalSvc.getNgClassSupplyTransactionBackground(operation);
  }

  /** establece el texto del modo de servicio*/
  textServiceMode(): string {
    switch (this.fuellingPointInfo.serviceModeType) {
      case ServiceModeType.PrePaid:
        return 'Prepago';
      case ServiceModeType.PostPaid:
        return 'Pospago';
      case ServiceModeType.AttendPaid:
        return 'Atendido';
      default:
        return 'Modo no gestionable';
    }
  }

  /** establece el tecto segun el estado */
  textStatus(): string {
    if (this.fuellingPointInfo.isStopped) {
      return 'parado';
    }
    if (this.fuellingPointInfo.isInErrorState) {
      this.textInformation = 'El surtidor no se encuentra disponible debido a un error.';
      return 'error';
    }
    if (!this.fuellingPointInfo.hasFreeBuffer) {
      return 'completo';
    }
    if (!this.fuellingPointInfo.isOnline) {
      return 'offline';
    }
    if (this.fuellingPointInfo.mainState == FuellingPointMainStates.Unavailable) {
      this.textInformation = 'El surtidor no se encuentra disponible para ser gestionado por el TPV.';
      return 'no disponible';
    }
    return undefined;
  }

  /**
   * Hace que un boton MdButtonToggle pueda ser deseleccionable
   * @param param boton pulsado
   */
  onClickButtonToggle(param: MdButtonToggle) {
    if (param == param.buttonToggleGroup.selected) {
      // quita la seleccion
      param.buttonToggleGroup.selected = undefined;
    }
  }

  /**
   * Maneja el evento click en una operacion en espera
   * @param transaction operacion en espera
   */
  onClickSupplyTransaction(transaction: SuplyTransaction) {
    if (this._requestPending) {
      return;
    }
    this._requestPending = true;
    this._fpSvc.manageSupplyTransaccion(transaction)
      .first().subscribe(response => {
        this._requestPending = false;
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      });
  }

  /** 'Abre' el surtidor para la siguiente operacion en postPago*/
  private prepareNextOperationPostPay() {
    this._fpSvc.prepareForPostpaidOperation(this.fuellingPointInfo.id)
      .first().subscribe(response => {
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      });
  }

  /** Cancela la 'apertura' para la siguiente operacion en postPago (vuelve a prepago)*/
  private cancelNextPostPay() {
    this._fpSvc.cancelLockingOfFuellingPoint(this.fuellingPointInfo.id)
      .first().subscribe(response => {
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      });
  }

  /** Parada de emergencia del surtidor*/
  private stopFuellingPoint() {
    this._fpSvc.manageRequestEmergencyStop(true, this.fuellingPointInfo.id)
      .first().subscribe(response => {
        if (response) {
          this._onFuellingPointAuxiliarActionsComplete.next(response);
        }
      },
        error => this._onFuellingPointAuxiliarActionsComplete.next(false));
  }

  /** Cancelacion de parada de emergencia*/
  private resumeFuellingPoint() {
    this._fpSvc.manageRequestEmergencyStop(false, this.fuellingPointInfo.id)
      .first().subscribe(response => {
        if (response) {
          this._onFuellingPointAuxiliarActionsComplete.next(response);
        }
      },
        error => { this._onFuellingPointAuxiliarActionsComplete.next(false); });
  }

  /** Cambia el modo de servicio post/pre pago*/
  private changeMode(targetMode: ServiceModeType) {
    this.fuellingPointInfo.serviceModeType = targetMode;
    this.fuellingPointInfo.isAttend = ServiceModeType.AttendPaid == targetMode ? true : false;
    this._fpSvc.requestChangeServiceMode(targetMode, this.fuellingPointInfo.id)
      .first().subscribe(response => {
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      });
  }

/** Transferencia de ventas prepago a otro surtidor*/
  private getListTransferSalePrepay(id: number) {
    const currentFp: Array<FuellingPointInfo> = this.fpInformation;
    this.fuellingPointActive = [];
    this.textInformation = '';
    this.supplyTransactions = undefined;

    if (currentFp != undefined) {
      const currentGradeId = currentFp.find(x => x.id == id).limitGradeId;
      currentFp.forEach(fp => {
        if (fp.id == id) {
          this.fuellingPointOrigen = fp;
        } else {
            if (fp.mainState == FuellingPointMainStates.Idle || fp.mainState == FuellingPointMainStates.Starting) {
             if (fp.availableGradeList.find(x => x.id == currentGradeId)) {
              this.fuellingPointActive.push(fp);
             }
           }
        }
      });
      if (this.fuellingPointActive.length == 0 ) {
        this.textInformation = 'No se encontraron surtidores disponibles para transferir';
      } else {
        this.textFuellingActives = 'Surtidores disponibles';

        this.fuellingPointActive.forEach(element => {
          element.limitProductUnitaryPrice = this.fuellingPointOrigen.limitProductUnitaryPrice;
          element.limitProductReference = this.fuellingPointOrigen.limitProductReference;
          element.limitGradeId = this.fuellingPointOrigen.limitGradeId;
          element.limitType = this.fuellingPointOrigen.limitType;
          element.limitValue = this.fuellingPointOrigen.limitValue;
          element.idfpTransferOrigen = this.fuellingPointOrigen.id;
        });
      }

    }

  }
  /**
   * Establece las acciones para el surtidor
   * @param actions Array con acciones disponibles para el surtidor
   */
  private onAvailableActions(actions: FuellingPointAvailableActionType[]) {
    this.availableActions = actions;
    const displayPreAut = this._appDataConfig.getConfigurationParameterByName('DISPLAY_MODE_PRE-AUTHORIZED', 'GENERAL');
    const displayAtend = this._appDataConfig.getConfigurationParameterByName('DISPLAY_MODE_ATENDIDO', 'GENERAL');
    let displayValuePreAut: boolean;
    let displayValueAttend: boolean;
    if (displayPreAut == undefined ) {
      displayValuePreAut = true;
    }
    else {
      displayValuePreAut = displayPreAut.meaningfulStringValue.toUpperCase.toString() == 'TRUE' ? true : false;
    }

    if (displayAtend == undefined ) {
      displayValueAttend = true;
    }
    else {
      displayValueAttend = displayAtend.meaningfulStringValue.toUpperCase.toString() == 'TRUE' ? true : false;
    }

   /* if (actions.find(x => x == FuellingPointAvailableActionType.ChangeOperationModeToPrepaid) != undefined) {
      this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.PrePaid),
        text: 'Cambiar',
        class: ''
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.ChangeOperationModeToPostpaid) != undefined) {
      this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.PostPaid),
        text: 'Cambiar',
        class: ''
      });
    }*/
    if (this.fuellingPointInfo.serviceModeType == ServiceModeType.PrePaid) {
      if (displayValueAttend) {
        this.addActionHeader({
          actionClick: () => this.changeMode(ServiceModeType.AttendPaid),
          text: 'Atendido',
          class: ''
        });
      }
      this.addActionHeader({
          actionClick: () => this.changeMode(ServiceModeType.PostPaid),
          text: 'Pospago',
          class: ''
      });
      if (displayValuePreAut) {
        this.addActionHeader({
          actionClick: () => this.changeMode(ServiceModeType.PreAuthorized),
          text: 'Pre Autorizado',
          class: ''
        });
      }
    }
  if (this.fuellingPointInfo.serviceModeType == ServiceModeType.PostPaid) {
    this.fuellingPointInfo.isAttend = false;
    this.addActionHeader({
      actionClick: () => this.changeMode(ServiceModeType.PrePaid),
      text: 'Prepago',
      class: ''
    });
    if (displayValueAttend) {
      this.addActionHeader({
          actionClick: () => this.changeMode(ServiceModeType.AttendPaid),
          text: 'Atendido',
          class: ''
      });
    }
    if (displayValuePreAut) {
      this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.PreAuthorized),
        text: 'Pre Autorizado',
        class: ''
      });
    }
  }
  if (this.fuellingPointInfo.serviceModeType == ServiceModeType.AttendPaid) {
    this.fuellingPointInfo.isAttend = true;
    this.addActionHeader({
      actionClick: () => this.changeMode(ServiceModeType.PostPaid),
      text: 'Pospago',
      class: ''
    });
    this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.PrePaid),
        text: 'Prepago',
        class: ''
    });
    if (displayValuePreAut) {
      this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.PreAuthorized),
        text: 'Pre Autorizado',
        class: ''
      });
    }
  }
  if (this.fuellingPointInfo.serviceModeType == ServiceModeType.PreAuthorized) {
    this.addActionHeader({
      actionClick: () => this.changeMode(ServiceModeType.PostPaid),
      text: 'Pospago',
      class: ''
    });
    this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.PrePaid),
        text: 'Prepago',
        class: ''
    });
    if (displayValueAttend) {
      this.addActionHeader({
        actionClick: () => this.changeMode(ServiceModeType.AttendPaid),
        text: 'Atendido',
        class: ''
      });
    }
  }
    if (actions.find(x => x == FuellingPointAvailableActionType.ServiceModePostPayment) != undefined && this.fuellingPointInfo.serviceModeType != ServiceModeType.PreAuthorized && this.fuellingPointInfo.serviceModeType != ServiceModeType.AttendPaid) {
      this.addActionHeader({
        actionClick: () => this.prepareNextOperationPostPay(),
        text: 'Abrir',
        class: ''
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.ServiceModePrePayment) != undefined && this.fuellingPointInfo.serviceModeType != ServiceModeType.PreAuthorized && this.fuellingPointInfo.serviceModeType != ServiceModeType.AttendPaid) {
      this.addActionHeader({
        actionClick: () => this.cancelNextPostPay(),
        text: 'Volver a prepago',
        class: 'longTextButton'
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.StopPump) != undefined) {
      this.fuellingPointInfo.isAttend = false;
      this.addActionHeader({
        actionClick: () => this.stopFuellingPoint(),
        text: 'Parar',
        class: ''
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.ResumePump) != undefined) {
      this.addActionHeader({
        actionClick: () => this.resumeFuellingPoint(),
        text: 'Reanudar',
        class: ''
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.CancelPrepay) != undefined) {
      if (this._posCode == this.fuellingPointInfo.lockingPOSId) {
        this.addActionHeader({
          actionClick: () => this.getListTransferSalePrepay(this.fuellingPointInfo.id),
          text: 'TRANSFERIR',
          class: ''
        });
      }
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.UndoPreset) != undefined) {
      if (this._posCode == this.fuellingPointInfo.lockingPOSId) {
        this.textInformation = 'El surtidor está autorizado por este TPV';
      } else {
        const lockingPOSId = this._fpInternalSvc.getPOSId(this.fuellingPointInfo.lockingPOSId);
        this.textInformation = lockingPOSId == undefined ? 'Este surtidor está autorizado por un TPV desconocido'
          : `Este surtidor ha sido autorizado por el TPV ${lockingPOSId}`;
      }
      this.addActionBottom({
        actionClick: () => this.undoPreset(),
        class: '',
        text: 'Anular autorización'
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.CancelPrepay) != undefined) {
      if (this._posCode == this.fuellingPointInfo.lockingPOSId) {
        this.textInformation = 'El surtidor está autorizado por este TPV';
      } else {
        const lockingPOSId = this._fpInternalSvc.getPOSId(this.fuellingPointInfo.lockingPOSId);
        this.textInformation = lockingPOSId == undefined ? 'Este surtidor está autorizado por un TPV desconocido'
          : `Este surtidor ha sido autorizado por el TPV ${lockingPOSId}`;
      }
      this.addActionBottom({
        actionClick: () => this.cancelPrepay(),
        class: '',
        text: 'Anular autorización'
      });
    }
    if (actions.find(x => x == FuellingPointAvailableActionType.UnlockFuellingPoint) != undefined) {
      if (this._posCode == this.fuellingPointInfo.lockingPOSId) {
        this.textInformation = 'El surtidor se encuentra bloqueado por este TPV';
      } else {
        const lockingPOSId = this._fpInternalSvc.getPOSId(this.fuellingPointInfo.lockingPOSId);
        this.textInformation = lockingPOSId == undefined ? 'Este surtidor se encuentra bloqueado por un TPV desconocido'
          : `Este surtidor se encuentra bloqueado por el TPV ${lockingPOSId}`;

        // this.addActionBottom({
        //   actionClick: () => this.unlockFuellingPoint(),
        //   class: '',
        //   text: 'Desbloquear surtidor'
        // });

      }
    }
    this.canChooseFuel = actions.find(x => x == FuellingPointAvailableActionType.ChooseFuel) != undefined;

    if (this.fuellingHeaderActions != undefined) {
      this.fuellingHeaderActions.forEach(action => {
        const bootstrapClass = ` col-xs-${12 / 2}`;
        action.class += bootstrapClass;
      });
    }
  }

  /** Cancela un preset hecho en el surtidor*/
  private undoPreset() {
    this._fpSvc.manageRequestCancelPreset(this.fuellingPointInfo.id)
      .first().subscribe(response => {
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      },
        error => { this._onFuellingPointAuxiliarActionsComplete.next(false); });
  }
  /** Cancela un prepago hecho en el surtidor*/
  private cancelPrepay() {
    this._fpSvc.manageRequestCancelPrepay(this.fuellingPointInfo.id)
      .first().subscribe(response => {
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      },
        error => { this._onFuellingPointAuxiliarActionsComplete.next(false); });
  }

  setClassButtonNew(texto: string): IDictionaryStringKey<boolean> {
    if ( texto == 'Pospago') { return this.buildJsonNgClass('mat-free'); }
    else if ( texto == 'Prepago') { return this.buildJsonNgClass('mat-prepay'); }
    else if ( texto == 'Prepago' || texto == 'Volver a prepago') { return this.buildJsonNgClass('mat-prepay'); }
    else if ( texto == 'Atendido') { return this.buildJsonNgClass('mat-atend'); }
    else if (texto == 'Pre Autorizado'){return this.buildJsonNgClass('mat-preauthorized');}
    else if ( texto == 'PARAR' || texto == 'REANUDAR' || texto == 'TRANSFERIR') { return this.buildJsonNgClass('mat-stop'); }
    else { return this.buildJsonNgClass('mat-bck'); }
  }

  private buildJsonNgClass(key: string, check = true): IDictionaryStringKey<boolean> {
    const ret: IDictionaryStringKey<boolean> = {};
    ret[key] = check;
    return ret;
    }

  /** Cancela una reserva del surtidor*/
  // private unlockFuellingPoint() {
  //   this._fpSvc.cancelLockingOfFuellingPoint(this.fuellingPointInfo.id)
  //     .first().subscribe(response => {
  //       this._onFuellingPointAuxiliarActionsComplete.next(response);
  //     });
  // }

  /** indica si se ha seleccionado el modo autorizar */
  private isAutorizeModeSelected(): boolean {
    switch (this.modeSelector.value) {
      case 'authorize':
        return true;
      case 'prepay':
        return false;
      default:
        console.log('Se ha modificado el valor del selector de modo ilegalmente');
        return undefined;
    }
  }

  /**
   * Introduce una accion en la cabecera
   * @param actionHeader action a introducir
   */
  private addActionHeader(actionHeader: ActionButton) {
    if (this.fuellingHeaderActions == undefined) {
      this.fuellingHeaderActions = [];
    }
    this.fuellingHeaderActions.push(actionHeader);
  }

  /**
   * Introduce una accion en el pie
   * @param actionHeader action a introducir
   */
  private addActionBottom(actionBottom: ActionButton) {
    if (this.fuellingBottomActions == undefined) {
      this.fuellingBottomActions = [];
    }
    this.fuellingBottomActions.push(actionBottom);
  }

  /**
   * Prepara una operacion en prepago y la introduce en el ticket
   * @param limit limite del prepago
   * @param product grado seleccionado
   */
  private requestPreparePrepaidOperation(limit: FuellingLimit, product: Grade) {
    if (this._requestPending || limit.value == undefined) {
      return;
    }
    this._requestPending = true;
    this._fpSvc.preparePrepaidOperation(this.fuellingPointInfo.id, product.id, limit)
      .first()
      .subscribe(response => {
        console.log('Venta PREPAGO preparada');
        console.log(response);
        this._requestPending = false;
        this._fpSvc.managePrepaidOperationPrepared(response);
        this._onFuellingPointAuxiliarActionsComplete.next(true);
      },
        error => {
          this._requestPending = false;
          this._onFuellingPointAuxiliarActionsComplete.next(false);
        });
  }

  /**
   * Prepara una operacion Preset
   * @param limit limite del preset
   * @param product grado seleccionado
   */
  private requestPreparePreset(limit: FuellingLimit, product: Grade) {
    if (this._requestPending) {
      return;
    }
    this._requestPending = true;
    this._fpSvc.preparePresetOperation(this.fuellingPointInfo.id, product.id, limit)
      .first().subscribe(response => {
        this._requestPending = false;
        this._onFuellingPointAuxiliarActionsComplete.next(response);
      },
        error => {
          this._requestPending = false;
          this._onFuellingPointAuxiliarActionsComplete.next(false);
        });
  }

  /** Inicia una peticion para recuperar las acciones disponibles en el surtidor*/
  private _requestAvailableActions() {
    this._fpSvc.requestAvailableActions(this.fuellingPointInfo.id)
      .first().subscribe(response => {
        console.log('available actions received:');
        console.log(response);
        this.onAvailableActions(response);
      },
        error => { this._onFuellingPointAuxiliarActionsComplete.next(false); });

  }

  /** Inicia una peticion para recuperar las operaciones pendientes del surtidor*/
  private _requestSupplyTransactions() {
    this._fpSvc.requestSuplyTransactions(this.fuellingPointInfo.id)
      .first().subscribe(response => {
        if (response != undefined && response.length > 0) {
          console.log('Transacciones pendientes');
          console.log(response);
          this.supplyTransactions = response;
        }
      },
        error => this.supplyTransactions = undefined);
  }
}
