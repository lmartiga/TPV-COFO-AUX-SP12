import { Component, OnInit, ViewChild, ViewContainerRef, HostBinding } from '@angular/core';
import { LayoutBuilderService } from 'app/services/layout/layout-builder.service';
import { KeyboardInternalService } from 'app/services/keyboard/keyboard-internal.service';
import { OverlayService } from 'app/services/overlay/overlay.service';
import { MdDrawer } from '@angular/material';

@Component({
  selector: 'tpv-root',
  templateUrl: './tpv.component.html',
  styleUrls: ['./tpv.component.scss']
})
export class TPVComponent implements OnInit {
  @ViewChild('mainContainerHost', { read: ViewContainerRef }) private mainViewContainerRef: ViewContainerRef;
  @ViewChild('drawer') private _drawer: MdDrawer;
  @HostBinding('class') class = 'tpv-root';
  initialized = false;
  showKeyboard: boolean;
  private _possibleOverlayId: string;

  constructor(
    private _layoutBuilder: LayoutBuilderService,
    private _keyboardInternalSrv: KeyboardInternalService,
    private _overlay: OverlayService
  ) {
    console.log('TPVComponent created');
  }

  ngOnInit(): void {
    this._layoutBuilder.parseLayoutConfigurationAndBuildComponentTree(this.mainViewContainerRef);
    this.showKeyboard = false;

    this._keyboardInternalSrv.showKeyBoard$.subscribe(dato => {
      if (dato) {
        this.showKeyboard = true;
      } else {
        this.showKeyboard = false;
      }
    });

    this._overlay.onClick().subscribe(dato => {
      if (this._possibleOverlayId !== undefined) {
        this._overlay.close(this._possibleOverlayId);
        this._possibleOverlayId = undefined;
        this._drawer.toggle();
      }
    });
  }

  openSlidenav() {
    this._drawer.toggle();
  }
}
