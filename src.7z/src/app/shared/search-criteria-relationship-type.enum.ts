export enum SearchCriteriaRelationshipType {
    and = 0,
    or = 1
}
