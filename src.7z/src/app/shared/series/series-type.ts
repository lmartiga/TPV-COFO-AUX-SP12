export enum SeriesType {
  ticket = 1,
  invoice = 2,
  rectifyingInvoice = 3,
  other = 4,
  dispatchNote = 5,
  rectifyingTicket = 6,
  consignment = 7
}
