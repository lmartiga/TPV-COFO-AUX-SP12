export interface TinType {
  id: number;
  name: string;
}
