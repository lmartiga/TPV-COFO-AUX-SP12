export enum SearchCustomerCriteriaFieldType {
  businessName = 0,
  tin = 1
}
