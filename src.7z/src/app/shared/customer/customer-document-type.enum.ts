export enum CustomerDocumentType {
    sale = 1,
    invoice = 2,
    deliveryNote = 5
}
