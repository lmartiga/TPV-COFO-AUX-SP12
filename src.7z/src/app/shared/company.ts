export interface Company {
    id: string;
    tin: string;
    businessName: string;
    address: string;
    city: string;
    postalCode: string;
    telephone: string;
}
