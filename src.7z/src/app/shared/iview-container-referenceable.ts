import { ViewContainerRef } from '@angular/core';

export interface IViewContainerReferenceable {
  viewContainerRef: ViewContainerRef;
}
