export enum SearchOperatorCriteriaFieldType {
  tin = 0,
  code = 1,
  login = 2,
  name = 3,
  id = 4
}
