export enum SearchOperatorCriteriaMatchingType {
  anywhere = 0,
  startWith = 1,
  endWith = 2,
  exact = 3
}
