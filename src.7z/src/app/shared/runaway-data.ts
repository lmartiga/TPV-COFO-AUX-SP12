export interface RunawayData {
  plate: string;
  remarks: string;
}
