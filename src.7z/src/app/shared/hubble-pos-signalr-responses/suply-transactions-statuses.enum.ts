export enum SuplyTransactionsStatuses {
    Successful = 1,
    ValidationError = -1,
    NotConnectedError = -2,
    GenericError = -3,
}
