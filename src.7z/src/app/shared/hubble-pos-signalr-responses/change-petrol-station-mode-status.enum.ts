export enum ChangePetrolStationModeStatus {
    Successful = 1,
    ValidationError = -1,
    NotConnectedError = -2,
    OperationNotAllowedError = -3,
    GenericError = -4,
}
