export enum FinalizeSupplyTransactionStatus {
    Successful = 1,
    ValidationError = -1,
    GenericError = -2
}
