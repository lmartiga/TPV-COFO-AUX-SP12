export enum GetPSSInitialConfigurationResponseStatuses {
    successful = 1,
    configurationError = -1,
    genericError = -2
}
