import { AppCancelUpdateModeReasonType } from 'app/shared/updater/app-cancel-update-mode-reason-type.enum';

export interface CancelUpdateModeArgs {
    reasonType: AppCancelUpdateModeReasonType;
}
