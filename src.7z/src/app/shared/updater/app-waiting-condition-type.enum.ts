export enum AppWaitingConditionType {
    WaitToLocalDateTime,
    WaitToSecondsInIdle,
    WaitToUserPermission
}
