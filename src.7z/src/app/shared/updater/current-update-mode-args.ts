export interface CurrentUpdateModeArgs {
}
