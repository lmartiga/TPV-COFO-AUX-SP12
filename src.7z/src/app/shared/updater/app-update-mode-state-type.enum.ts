export enum AppUpdateModeStateType {
    InStandardMode = 1,
    WaitingForCondition = 2,
    InUpdateMode = 3,
    Unreliable = 4
}
