export enum AppCancelUpdateModeReasonType {
    UpdateCancelled,
    UpdatedSuccesfully,
    UpdateFailed
}
