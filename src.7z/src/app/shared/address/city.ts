export interface City {
  id?: number;
  name: string;
  countryId?: number;
  countryName?: string;
  postalCode?: string;
  provinceId?: number;
  provinceName?: string;
}
