export interface Province {
  id?: number;
  name: string;
  countryId?: number;
  countryName?: string;
}
