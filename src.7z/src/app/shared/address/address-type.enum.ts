export enum AddressType {
	other = 0,
	customerMain = 1,
}
