export enum AlertPurposeType {
    undefined = 0,
    showOnInit = 1,
    showOnLogged = 2,
    showOnSaleFinished = 3
}
