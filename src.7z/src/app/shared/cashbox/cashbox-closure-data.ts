export interface CashboxClosureData {
    countedAmount: number;

    extractedAmount: number;
}
