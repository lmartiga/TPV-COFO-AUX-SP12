export enum PrepareCashboxClosureResponses {
    Ready,
    NoPendingToCloseDocuments,
    NotReadyDueToPendingToInsertDocuments,
    Fail,
}
