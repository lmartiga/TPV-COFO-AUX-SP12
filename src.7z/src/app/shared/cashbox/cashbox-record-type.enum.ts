export enum CashboxRecordType {
  cashEntry = 1,
  cashOut = 2
}
