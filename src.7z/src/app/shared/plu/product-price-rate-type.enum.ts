export enum ProductPriceRateType {
    ExplicitPrice = 0,
    DiscountUponPreviusPrice = 1,
    DiscountUponCostPrice = 2,
    DiscountPerVolumeUnit = 3
}
