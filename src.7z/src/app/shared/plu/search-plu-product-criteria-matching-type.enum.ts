export enum SearchPluProductCriteriaMatchingType {
  anywhere = 0,
  startWith = 1,
  endWith = 2,
  exact = 3
}
