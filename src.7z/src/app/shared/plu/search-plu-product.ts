export interface SearchPluProduct {
  id: string;
  description: string;
  barCode: string;
}
