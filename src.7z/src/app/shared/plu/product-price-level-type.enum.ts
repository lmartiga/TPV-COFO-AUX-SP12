export enum ProductPriceLevelType {
    CustomerByCustomerDiscount = 0,
    CustomerByRate = 1,
    Shop = 2,
    Company = 3
}

