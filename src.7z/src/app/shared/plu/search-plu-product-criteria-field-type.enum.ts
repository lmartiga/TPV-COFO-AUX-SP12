export enum SearchPluProductCriteriaFieldType {
  description = 0,
  barCode = 1
}
