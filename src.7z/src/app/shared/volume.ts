export interface Volume {
    description: string;
    symbol: string;
}
