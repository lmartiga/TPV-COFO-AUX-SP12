export enum KeyboardClassKey {
    Alt= <any> 'Alt',
    AltGraph = <any> 'AltGraph',
    AltLk = <any> 'AltLk',
    Backspace = <any> 'Backspace',
    CapsLock = <any>'CapsLock',
    Enter = <any>'Enter',
    Shift = <any>'Shift',
    Tab = <any>'Tab'
}
