export interface IDimensionable {
  widthPercentage: number;
  heightPercentage: number;
  overflowY: string;
}
