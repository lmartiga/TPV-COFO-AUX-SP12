export enum GetCompanyResponseStatuses {
  successful = 1,
  genericError = -1,
  invalidIdentity = -3,
}
