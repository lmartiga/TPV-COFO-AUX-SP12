export interface SetAlertAsShownResponse {
    status: number;
    message: string;
}
