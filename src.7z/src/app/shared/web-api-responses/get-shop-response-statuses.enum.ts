export enum GetShopResponseStatuses {
  successful = 1,
  genericError = -1,
  invalidIdentity = -3,
}
