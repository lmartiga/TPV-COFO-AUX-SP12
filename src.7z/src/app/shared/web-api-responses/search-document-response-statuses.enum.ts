export enum SearchDocumentResponseStatuses {
    Successful = 1,
    GenericError = -1,
    ValidationError = -2,
    InvalidIdentity = -3,
    CommunicationError = -4
}
