export enum createCashboxRecordResponseStatuses {
  successful = 1,
  genericError = -1,
  validationError = -2,
  invalidIdentity = -3,
  noAvailableRecordTypes = -4
}
