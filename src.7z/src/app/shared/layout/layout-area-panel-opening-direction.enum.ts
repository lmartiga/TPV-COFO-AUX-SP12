export enum LayoutAreaPanelOpeningDirection {
  RightToLeft,
  LeftToRight
}
