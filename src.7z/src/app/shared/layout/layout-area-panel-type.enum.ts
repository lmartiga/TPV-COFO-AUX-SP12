export enum LayoutAreaPanelType {
  primary,
  secondary,
  business,
  auxiliary
}
