export enum LayoutAreaItemType {
  rowsContainer = 0,
  columnsContainer = 1,
  mainPanel = 2
}

