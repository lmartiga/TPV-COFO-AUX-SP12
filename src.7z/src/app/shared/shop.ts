export interface Shop {
    id: string;
    shopName: string;
    address: string;
    city: string;
    postalCode: string;
    telephone: string;
}
