export enum ActionSliderOption {
    CobroDeudas,
    CopiarDocumento,
    AnularDocumento,
    CobroFugas
}
