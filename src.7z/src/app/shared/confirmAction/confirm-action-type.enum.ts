export enum ConfirmActionType {
    None = 0,
    Alert = 1,
    Error = 2,
    Information = 3,
    Warning = 4,
    Question = 5
}
