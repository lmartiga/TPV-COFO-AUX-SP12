export enum CreatePaymentUsageType {
  pendingPayment = 1,
}
