export enum PaymentPurpose {
  NewDocument = 0,
  PendingPayment = 1,
  Refund = 2
}
