export enum FuncionalityMode {
    ON = 1,
    OFF = 0,
    OPTIONAL = 2
}
