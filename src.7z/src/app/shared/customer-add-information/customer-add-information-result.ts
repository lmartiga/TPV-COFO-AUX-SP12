export interface CustomerAddInformationResult {
    success: boolean;
    changeCustomerRequested?: boolean;
    plate?: string;
}
