export class InternalActionKeys {
    static readonly closeCashbox = 'close_cashbox';
    static readonly cashboxEntry = 'cash_entry';
    static readonly cashboxOut = 'cash_out';
    static readonly documentCancellation = 'cancel_document';
    static readonly documentCopy = 'copy_document';
    static readonly pendingPaymentCollection = 'collect_pending_payment';
    static readonly runawayCollection = 'collect_runaway';
    static readonly fuellingPointTest = 'callibrate_fuelling_point';
    static readonly runaway = 'runaway';
}
