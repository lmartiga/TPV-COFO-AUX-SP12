export interface DBSyncProgressChangedArgs {
  synchronizationProcessName: string;
  progressPercentage: number;
}
