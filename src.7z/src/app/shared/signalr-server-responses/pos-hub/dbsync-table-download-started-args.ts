export interface DBSyncTableDownloadStartedArgs {
  synchronizationProcessName: string;
  tableName: string;
}
