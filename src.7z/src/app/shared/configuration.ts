import { LayoutConfiguration } from 'app/shared/layout/layout-configuration';

export interface Configuration {
  layoutConfiguration: LayoutConfiguration;
}
