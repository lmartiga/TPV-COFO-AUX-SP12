export enum DynamicActionType {
    InternalAction = 0,
    ExternalAction = 1
}
