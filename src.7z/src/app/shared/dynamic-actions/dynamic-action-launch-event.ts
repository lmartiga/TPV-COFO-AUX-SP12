export interface DynamicActionLaunchEvent {
    id: string;
    actionIdDictionary: Map<string, number>;
}
