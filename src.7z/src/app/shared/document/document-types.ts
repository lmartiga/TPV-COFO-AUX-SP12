export enum DocumentTypes {
  document = 0,
  supply = 1,
  creditNote = 2,
  deliveryNote = 3
}
