import { IbusinessSpecificLine } from 'app/shared/ibusiness-specific-line';
import { DocumentLinePromotion } from 'app/shared/document/document-line-promotion';

export interface DocumentLine {
  productId: string;
  quantity: number;
  description: string;
  priceWithTax: number;
  priceWithoutTax?: number;
  discountPercentage: number; // dto aplicado por el usuario
  taxPercentage?: number;
  discountAmountWithTax?: number;
  discountAmountWithoutTax?: number;
  taxAmount?: number;
  totalAmountWithTax?: number;
  appliedPromotionList?: Array<DocumentLinePromotion>;
  businessSpecificLineInfo?: IbusinessSpecificLine;
  isLoyaltyRedemption?: boolean;
  isEditable?: boolean;
  typeArticle?: string;
}

