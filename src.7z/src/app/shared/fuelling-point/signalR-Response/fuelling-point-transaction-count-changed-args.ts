export interface FuellingPointTransactionCountChangedArgs {
    fuellingPointId: number;
    transactionCount: number;
}
