export enum FuellingLimitType {
    // monetary limit type
    Monetary = 0,
    // volume limit type
    Volume = 1
}
