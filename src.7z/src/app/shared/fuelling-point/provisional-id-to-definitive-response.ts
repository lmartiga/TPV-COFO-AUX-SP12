export interface ProvisionalIdToDefinitiveResponse {
    success: boolean;
    definitiveId: string;
}
