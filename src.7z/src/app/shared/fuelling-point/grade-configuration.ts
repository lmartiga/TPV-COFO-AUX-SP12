export interface GradeConfiguration {
    id: number;
    imageHtmlBase64: string;
    measurementUnit: string;
    name: string;
}
