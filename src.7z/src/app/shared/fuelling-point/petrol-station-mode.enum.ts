export enum PetrolStationMode {
    Default = 0,
    Night = 1
}
