export interface FuellingTank {
  id: string;
  caption: string;
}
