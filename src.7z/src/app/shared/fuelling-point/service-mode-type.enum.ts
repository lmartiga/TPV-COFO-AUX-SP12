export enum ServiceModeType {
    PostPaid = 0,
    PrePaid = 1,
    Other = 2,
    AttendPaid = 3,
    PreAuthorized = 4
}
