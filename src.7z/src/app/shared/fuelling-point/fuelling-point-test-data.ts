export interface FuellingPointTestData {
  deviation: number;
  observations: string;
}
