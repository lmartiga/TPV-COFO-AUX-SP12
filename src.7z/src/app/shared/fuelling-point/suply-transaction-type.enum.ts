export enum SuplyTransactionType {
    PostpaidLockedByOwnPOS,
    PostpaidLockedByOtherPOS,
    PostpaidNoLocked,

    PrepaidCompleteLockedByOwnPOS,
    PrepaidCompleteLockedByOtherPOS,
    PrepaidCompleteNotLocked,

    PrepaidParcialLockedByOwnPOS,
    PrepaidParcialLockedByOtherPOS,
    PrepaidParcialNotLocked,

    Other
}
