export interface Grade {
    id: number;
    positionNumber: number;
    unitaryPrice: number;
}
