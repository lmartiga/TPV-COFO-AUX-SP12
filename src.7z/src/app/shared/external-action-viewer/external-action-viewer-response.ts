
export interface ExternalActionViewerResponse {
    status: number;
    message: string;
    data: any;
}
