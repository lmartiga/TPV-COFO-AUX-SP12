export interface ExternalActionViewerRequest {
    pageKey: string;
    closeSlider: boolean;
    callBackFunction: string;
    data: any;
}
