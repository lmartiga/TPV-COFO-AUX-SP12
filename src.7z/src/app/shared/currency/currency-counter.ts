export interface CurrencyCounter {
    counted1c: number;
    counted2c: number;
    counted5c: number;
    counted10c: number;
    counted20c: number;
    counted50c: number;
    counted1: number;
    counted2: number;
    counted5: number;
    counted10: number;
    counted20: number;
    counted50: number;
    counted100: number;
    counted200: number;
    counted500: number;
  }
