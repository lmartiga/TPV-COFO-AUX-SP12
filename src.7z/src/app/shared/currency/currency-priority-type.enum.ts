export enum CurrencyPriorityType {
    other = 0,
    base = 1,
    secondary = 2
}
