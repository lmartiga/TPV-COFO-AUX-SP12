export enum SlideOverOpeningDirection {
  leftToRight,
  rightToLeft
}
