export interface LoyaltyAttributionSimulationDetails {
  benefitId: number;

  benefitName: string;

  benefitDescription: string;

  balanceBefore: number;

  balanceAfter: number;

  currencyId: string;
}
