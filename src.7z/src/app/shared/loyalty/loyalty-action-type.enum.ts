export enum LoyaltyActionType {
  accumulation,
  redemption
}
