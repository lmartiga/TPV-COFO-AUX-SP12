export interface LoyaltyRedemptionDetails {
  benefitId: number;

  benefitName: string;

  benefitDescription: string;

  balanceBefore: number;

  balanceAfter: number;
}
