export enum BusinessType {
  none = 0,
  hostelry = 1,
  gasStation = 2,
  retail = 3
}
