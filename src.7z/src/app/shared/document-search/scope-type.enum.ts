export enum ScopeType {
    pos = 1,
    shop = 2,
    company = 3
}
