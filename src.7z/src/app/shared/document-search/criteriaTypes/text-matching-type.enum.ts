export enum TextMatchingType {
    Anywhere = 1,
    StartWith = 2,
    EndWith = 3,
    Exact = 4
}
