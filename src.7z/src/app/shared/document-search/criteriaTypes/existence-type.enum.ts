export enum ExistenceType {
    exists = 1,
    notExists = 2
}
