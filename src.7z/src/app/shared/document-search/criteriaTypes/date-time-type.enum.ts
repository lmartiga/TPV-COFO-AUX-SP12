export enum DateTimeType {
    // Fecha-hora local
    local = 0,
    // Fecha-hora UTC
    utc = 1
}
