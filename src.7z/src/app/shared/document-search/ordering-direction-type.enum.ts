export enum OrderingDirectionType {
    ascending = 1,
    descending = 2
}
