
export enum DocumentSearchFilters {
    debt = 0,
    plate = 1,
    date = 2,
    import = 3,
    operator = 4,
    document = 5,
    customer = 6,
}
