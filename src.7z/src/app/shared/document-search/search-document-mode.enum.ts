export enum SearchDocumentMode {
    Cancel,
    Pending,
    Runaway,
    Copy
}
