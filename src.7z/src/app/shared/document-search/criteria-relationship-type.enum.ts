export enum CriteriaRelationshipType {
    and = 0,
    or = 1
}