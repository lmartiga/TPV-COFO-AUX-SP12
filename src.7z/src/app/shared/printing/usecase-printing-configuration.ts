export interface UsecasePrintingConfiguration {
  useCase: string;
  printingTemplatePlatformType: string;
  defaultNumberOfCopies: number;
  required: boolean;
}
