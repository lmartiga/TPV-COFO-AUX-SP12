export interface PrintingTemplate {
    id: string;
    stringifiedTemplate: string;
    templateSettings: Map<string, string>;
}
