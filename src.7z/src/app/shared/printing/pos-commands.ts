export interface PosCommands {
  openDrawer: string;
  papreCut: string;
  others: string[];
}
