export interface Response {
  status: number;
  data: any;
}
