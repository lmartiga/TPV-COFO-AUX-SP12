export enum AuthorizationEntityType {
  operator
}
