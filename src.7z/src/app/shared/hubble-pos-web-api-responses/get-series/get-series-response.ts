import { Series } from 'app/shared/series/series';
import {
  GetSeriesResponseStatuses
} from 'app/shared/hubble-pos-web-api-responses/get-series/get-series-response-statuses.enum';

export interface GetSeriesResponse {
  status: GetSeriesResponseStatuses;
  message: string;

  seriesList: Series[];
}
