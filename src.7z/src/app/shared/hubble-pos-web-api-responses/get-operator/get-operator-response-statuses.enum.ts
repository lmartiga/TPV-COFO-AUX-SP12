export enum GetOperatorResponseStatuses {
  successful = 1,
  genericError = -1,
  validationError = -2,
  invalidIdentityError = -3
}
