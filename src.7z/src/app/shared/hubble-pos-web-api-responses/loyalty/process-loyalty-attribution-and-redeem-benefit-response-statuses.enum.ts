export enum ProcessLoyaltyAttributionAndRedeemBenefitResponseStatuses {
  successful = 1,
  invalidIdentityError = -1,
  validationError = -2,
  genericError = -3,
  operationBlockedError = -4
}
