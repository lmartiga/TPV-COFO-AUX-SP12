export enum SimulateLoyaltyAttributionResponseStatuses {
  successful = 1,
  invalidIdentityError = -1,
  validationError = -2,
  genericError = -3,
  invalidCardError = -4,
  operationBlockedError = -5
}
