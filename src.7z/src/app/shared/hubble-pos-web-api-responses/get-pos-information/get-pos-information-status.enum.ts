export enum GetPosInformationStatus {
    successful = 1,
    securityError = -1,
    validationError = -2,
    invalidIdentity = -3,
    genericError = -4
}
