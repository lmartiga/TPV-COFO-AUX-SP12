import { MainElementDirective } from './main-element.directive';

describe('MainElementDirective', () => {
  it('should create an instance', () => {
    const directive = new MainElementDirective();
    expect(directive).toBeTruthy();
  });
});
