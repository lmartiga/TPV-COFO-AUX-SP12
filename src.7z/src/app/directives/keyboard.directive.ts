import { Directive, ElementRef, HostListener, Input, OnInit, Output, OnDestroy, EventEmitter } from '@angular/core';
import { KeyboardInternalService } from 'app/services/keyboard/keyboard-internal.service';
import { NgModel } from '@angular/forms';
import { setTimeout } from 'timers';
import { Subscription } from 'rxjs/Subscription';

@Directive({
  selector: '[tpvKeyboard]',
  providers: [NgModel]
})
export class KeyboardDirective implements OnInit, OnDestroy {
  // en el futuro será el tipo de teclado que quiero abrir
  @Input() type: string;
  @Output() enter: EventEmitter<boolean> = new EventEmitter();
  private _position: number;
  private _subscriptions: Subscription[] = [];

  constructor
    (private element: ElementRef,
    private keyboardInternalSrv: KeyboardInternalService,
    private ngModel: NgModel
    ) { }

  ngOnInit() {
  }
  ngOnDestroy() {
    this._subscriptions.forEach(s => s.unsubscribe());
    this._hideKeyboard();
  }
  // cuando recibo el evento del click
  @HostListener('click')
  onclick() {
    this._position = this.element.nativeElement.selectionStart;
    this._openKeyboard();
    // envio la posición del puntero dentro del input
    this.keyboardInternalSrv.SendPosition(this._position);
  }

  @HostListener('blur', ['$event'])
  private _hideKeyboard() {
    this.keyboardInternalSrv.CloseKeyBoard();
  }

  private _openKeyboard() {
    // muestro el teclado por pantalla
    this.keyboardInternalSrv.ShowKeyBoard();
    // envio el ng-model del input al teclado y su tipo
    this.keyboardInternalSrv.SendNgModel(this.ngModel);
    // envio el ElementRef para lanzar el enter del teclado
    this.keyboardInternalSrv.SendElementRef(this.element);
    // envio el typo del input
    this.keyboardInternalSrv.SendType(this.element.nativeElement.type);

    setTimeout(function () {
      const str = jQuery('.virtual-keyboard').css('left').split('px');
      const posHorizontal: number = Number(str[0]);

      if (posHorizontal > jQuery(window).width() - jQuery('.virtual-keyboard').width()) {
        jQuery('.virtual-keyboard').css('left', jQuery(window).width() - jQuery('.virtual-keyboard').width() + 'px');
      }

      const str1 = jQuery('.virtual-keyboard').css('top').split('px');
      const posVertical: number = Number(str1[0]);
      if (posVertical > jQuery(window).height() - jQuery('.virtual-keyboard').height() - 48) {
        jQuery('.virtual-keyboard').css('top', jQuery(window).height() - jQuery('.virtual-keyboard').height() - 48 + 'px');
      }
    }, 10);
  }

 @HostListener('keydown', ['$event'])
  onkeydown(event: KeyboardEvent) {
    this.keyboardInternalSrv.ShowEventKeyPress(event.key);
    }

}

