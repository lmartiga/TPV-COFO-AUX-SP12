import { KeyboardDirective } from './keyboard.directive';

describe('KeyboardDirective', () => {
  it('should create an instance', () => {
    const directive = new KeyboardDirective();
    expect(directive).toBeTruthy();
  });
});
