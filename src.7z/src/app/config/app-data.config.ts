/**
 * TODO Hay que hablar con Antonio para ver si la gestión de la respuesta del servicio
 * (ya que ahora todas las llamadas devuelven un status y un mensaje se tienen que gestionar desde cada
 * uno de los sitios donde se invoca el servicio http o se tienen que gestionar en un punto común. Hablé con él el otro día
 * y quedamos en que deberían gestionarse esas respuestas desde un sitio común (que entienda los statuses del demonio,
 * y abstraer al resto de servicios de esta lógica). Hay que ver de qué manera se programa esto).
 * En general hay que revisar todas las llamadas al demonio por si hay que actualizarlas.
 */
import { Injectable } from '@angular/core';
import { environment } from 'environments/environment';
import { Company } from 'app/shared/company';
import { PrintingTemplate } from 'app/shared/printing/printing-template';
import { Series } from 'app/shared/series/series';
import { SeriesType } from 'app/shared/series/series-type';
import { Shop } from 'app/shared/shop';
import { PaymentMethodType } from 'app/shared/payments/payment-method-type.enum';
import { FuncionalityMode } from 'app/shared/funcionality-mode.enum';
import { Currency } from 'app/shared/currency/currency';
import { PaymentMethod } from 'app/shared/payments/payment-method';
import { CurrencyPriorityType } from 'app/shared/currency/currency-priority-type.enum';
import { Volume } from 'app/shared/volume';
import { HttpService } from 'app/services/http/http.service';
import { GetCompanyResponse } from 'app/shared/web-api-responses/get-company-response';
import { GetShopResponse } from 'app/shared/web-api-responses/get-shop-response';
import { GetCompanyResponseStatuses } from 'app/shared/web-api-responses/get-company-response-statuses.enum';
import { GetShopResponseStatuses } from 'app/shared/web-api-responses/get-shop-response-statuses.enum';
import { GetPaymentMethodsResponse } from 'app/shared/hubble-pos-web-api-responses/get-payment-methods/get-payment-methods-response';
import { GetCurrenciesResponse } from 'app/shared/hubble-pos-web-api-responses/get-currencies/get-currencies-response';
import { GetSeriesResponse } from 'app/shared/hubble-pos-web-api-responses/get-series/get-series-response';
import {
  GetPaymentMethodsResponseStatuses
} from 'app/shared/hubble-pos-web-api-responses/get-payment-methods/get-payment-methods-response-statuses.enum';
import { GetSeriesResponseStatuses } from 'app/shared/hubble-pos-web-api-responses/get-series/get-series-response-statuses.enum';
import {
  GetCurrenciesResponseStatuses
} from 'app/shared/hubble-pos-web-api-responses/get-currencies/get-currencies-response-statuses.enum';
import { ConfigurationParameter } from 'app/shared/configuration-parameter';
import { ConfigurationParameterType } from 'app/shared/configuration-parameter-type.enum';
import { IDictionaryStringKey } from 'app/shared/idictionary';
import { GetPrintingConfigurationResponse } from 'app/shared/web-api-responses/get-printing-configuration-response';
import {
  GetPrintingConfigurationResponseStatuses
} from 'app/shared/web-api-responses/get-printing-configuration-response-statuses.enum';
import { UsecasePrintingConfiguration } from 'app/shared/printing/usecase-printing-configuration';
import { FormatHelper } from '../helpers/format-helper';
import { DecimalPrecisionConfiguration } from 'app/shared/decimal-precision-configuration';
import { PosCommands } from 'app/shared/printing/pos-commands';

/***
 ** Application specific configuration (Not changeable by user).
****/
@Injectable()
export class AppDataConfiguration {
  readonly numberOfTickets = 6;
  readonly httpServerUrl = environment.httpServerUrl;
  readonly apiUrl = environment.apiUrl;
  readonly signalRUrl = environment.signalRUrl;
  readonly numberOfDocuments = 6;
  readonly defaultPrinterName =
    // IMPRESORA NULA PARA PRUEBAS SIN IMPRESORA FÍSICA:
    // 'IgnorePrintForTesting';
    // IMPRESORA INSTALADA EN POS PARA DEMO:
    //  'NCR Printer';
    // AUTODETECCIÓN DE IMPRESORA PREDETERMINADA:
    //    EL SERVICIO DEBERÁ EJECUTARSE CON LA CUENTA DEL USUARIO DEL PC,
    //   Y SI LA IMPRESORA REQUIERE INTERACCIÓN, LA IMPRESIÓN NO TERMINARÁ
    '';
  readonly defaultPrinterPaperWidth = 80;
  readonly defaultLogoPrintingFileName = ''; // ruta por defecto del logo a imprimir
  private _userConfiguration: any = {}; // TODO: Revisar nombre, esta es la configuración recuperada del archivo tpv.config.json
  private _currencyList: Array<Currency> = [];
  private _paymentMethodList: Array<PaymentMethod> = [];
  private _seriesList: Array<Series> = [];
  private _configurationParameterList: Array<ConfigurationParameter> = [];
  private _defaultCountryId: number;
  private _defaultBankCardId: string;
  private _unknownCustomerId: string;
  private _defaultOperator: string;
  private _defaultCustomer: string;
  private _templateList: Array<PrintingTemplate> = [];
  private _printingGlobalSettings: IDictionaryStringKey<string> = {};
  private _company: Company;
  private _shop: Shop;
  private _clockRefreshFrecuency: number;
  private _networkConnectionRefreshFrecuency: number;
  private _mustRequestCustomerPlate: boolean;
  private _maxAmountForTicketWithoutInvoice: number;
  private _maxAmountForUnkownCustomer: number;
  private _decimalPrecisionConfiguration: DecimalPrecisionConfiguration;
  private _pluViewConfiguration: string;
  private _printerPosCommands: PosCommands;

  constructor(
    private _http: HttpService
  ) {
    // TODO: Todos estos valores habrá que recuperarlos del servicio
    this._unknownCustomerId = ''; // '0276300000'; // cliente contado
    this._defaultOperator = ''; // '02763eab'; // TODO: operador por defecto
    this._defaultCustomer = ''; // '02763T0059'; // TODO: cliente por defecto
    this._clockRefreshFrecuency = 45000; // TODO seguramente vendrá de configuración, de momento 45seg REVISABLE
    // TODO seguramente vendrá de configuración, de momento 5seg REVISABLE
    this._networkConnectionRefreshFrecuency = 45000;
  }

  //#region fill configuration

  async fillIdentityAsync(): Promise<boolean> {
    let success = true;

    // Get user configuration
    try {
      this._userConfiguration = await this._http.getJsonPromiseAsync(
        `${this.httpServerUrl}/tpv.config.json?d=${(new Date().getTime())}`);

      console.log('Retrieved configuration from tpv.config.json:');
      console.log(this._userConfiguration);
    } catch (e) {
      console.log(`ERROR. No ha sido posible recuperar la identidad del TPV -> ${e}`);
      success = false;
    }
    return success;
  }

  async fillConfigurationAsync(): Promise<boolean> {
    let success = true;

    // Get Company information
    try {
      const getCompanyResponse: GetCompanyResponse = await this._getCompanyInformationAsync();
      this.company = getCompanyResponse.company;
    } catch (e) {
      console.log(`ERROR: ${e}`);
      success = false;
    }

    // Get Shop information
    try {
      const getShopResponse: GetShopResponse = await this._getShopInformationAsync();
      this._shop = getShopResponse.shop;
    } catch (e) {
      console.log(`ERROR: ${e}`);
      success = false;
    }

    // Get payment methods
    try {
      const getPaymentMethodsResponse: GetPaymentMethodsResponse = await this._getPaymentMethodsAsync();
      this._paymentMethodList = getPaymentMethodsResponse.paymentMethodList;
      this._defaultBankCardId = getPaymentMethodsResponse.defaultBankCardId;
    } catch (e) {
      console.log(`ERROR: ${e}`);
      success = false;
    }

    // Get currencies
    try {
      const getCurrenciesResponse: GetCurrenciesResponse = await this._getCurrenciesAsync();
      this._currencyList = getCurrenciesResponse.currencyList;
    } catch (e) {
      console.log(`ERROR: ${e}`);
      success = false;
    }

    // Get series
    try {
      const getSeriesResponse: GetSeriesResponse = await this._getSeriesListAsync();
      this._seriesList = getSeriesResponse.seriesList;
    } catch (e) {
      console.log(`ERROR: ${e}`);
      success = false;
    }

    // Get template list and printing global settings
    try {
      const getPrintingConfigurationResponse: GetPrintingConfigurationResponse = await this._getPrintingCofigurationAsync();
      this._templateList = getPrintingConfigurationResponse.templates;
      this._printingGlobalSettings = getPrintingConfigurationResponse.globalSettings;
      this._printerPosCommands = getPrintingConfigurationResponse.posCommands;
    } catch (e) {
      console.log(`ERROR: ${e}`);
      success = false;
    }
    return success;
  }

  addOrUpdateGlobalSettings(key: string, value: string) {
    this._printingGlobalSettings[key] = value;
  }

  //#endregion fill configuration


  //#region Getters
  get virtualTerminalSerialNumber(): string {
    return this.getConfigurationParameterByName('VIRTUAL_TERMINAL_SERIAL_NUMBER', 'FLEET').meaningfulStringValue;
  }
  get mustRequestFleet(): boolean {
    if (this._mustRequestCustomerPlate == undefined) {
      const mustRequesCustomerPlateParam = this.getConfigurationParameterByName('VIRTUAL_TERMINAL_SERIAL_NUMBER', 'FLEET');
      if (mustRequesCustomerPlateParam == undefined) {
        this._mustRequestCustomerPlate = false;
      } else {
        this._mustRequestCustomerPlate = true;
      }
    }
    return this._mustRequestCustomerPlate;
  }
  get mustRequestCustomerPlate(): boolean {
    if (this._mustRequestCustomerPlate == undefined) {
      const mustRequesCustomerPlateParam = this.getConfigurationParameterByName('CUSTOMER_PLATE_MUST_BE_REQUESTED', 'FLEET');
      if (mustRequesCustomerPlateParam == undefined) {
        this._mustRequestCustomerPlate = false;
      } else {
        this._mustRequestCustomerPlate =
          (mustRequesCustomerPlateParam.meaningfulStringValue == '1' || mustRequesCustomerPlateParam.meaningfulStringValue == 'true');
      }
    }
    return this._mustRequestCustomerPlate;
  }
  get maxAmountForTicketWithoutInvoice(): number {
    if (this._maxAmountForTicketWithoutInvoice == undefined) {
      const maxAmountForTicketWithoutInvoiceParam = this.getConfigurationParameterByName('MAX_SIMPLE_INVOICE_AMOUNT', 'GENERAL');
      if (maxAmountForTicketWithoutInvoiceParam == undefined) {
        this._maxAmountForTicketWithoutInvoice = 3000;
      } else {
        this._maxAmountForTicketWithoutInvoice = + (maxAmountForTicketWithoutInvoiceParam.meaningfulStringValue);
      }
    }
    return this._maxAmountForTicketWithoutInvoice;
  }
  get maxAmountForUnkownCustomer(): number {
    if (this._maxAmountForUnkownCustomer == undefined) {
      const maxAmountForUnkownCustomerParam = this.getConfigurationParameterByName('MAX_UNKNOWN_CUSTOMER_SALE', 'GENERAL');
      if (maxAmountForUnkownCustomerParam == undefined) {
        this._maxAmountForUnkownCustomer = 100;
      } else {
        this._maxAmountForUnkownCustomer = + (maxAmountForUnkownCustomerParam.meaningfulStringValue);
      }
    }
    return this._maxAmountForUnkownCustomer;
  }
  get pluViewConfiguration(): string {
    if (this._pluViewConfiguration == undefined) {
      const pluViewConfiguration = this.getConfigurationParameterByName('PLU_VIEW_CONFIGURATION', 'GENERAL');
      this._pluViewConfiguration = pluViewConfiguration.meaningfulStringValue;
      if (pluViewConfiguration == undefined) {
        this._pluViewConfiguration = 'CATEGORIES';
      }
    }
    return this._pluViewConfiguration;
  }
  get defaultBankCardId(): string {
    return this._defaultBankCardId;
  }

  get defaultCountryId(): number {
    return this._defaultCountryId;
  }

  get defaultOperator(): string {
    return this._defaultOperator;
  }

  get defaultCustomer(): string {
    return this._defaultCustomer;
  }

  get userConfiguration(): any {
    return this._userConfiguration;
  }

  get paymentMethodList(): PaymentMethod[] {
    return this._paymentMethodList;
  }

  get unknownCustomerId(): string {
    return this._unknownCustomerId;
  }

  get defaultPosPrinterName(): string {
    const defaultPosPrinterNameParameter = this.getConfigurationParameterByType(ConfigurationParameterType.DefaultPosPrinterName);
    if (defaultPosPrinterNameParameter != undefined && defaultPosPrinterNameParameter.meaningfulStringValue != undefined) {
      return defaultPosPrinterNameParameter.meaningfulStringValue;
    } else {
      return this.defaultPrinterName;
    }
  }

  get defaultPosPaperWidth(): number {
    const defaultPosPaperWidthParameter = this.getConfigurationParameterByType(ConfigurationParameterType.DefaultPosPaperWidth);
    if (defaultPosPaperWidthParameter != undefined && defaultPosPaperWidthParameter.meaningfulStringValue != undefined) {
      const paperWidth = parseInt(defaultPosPaperWidthParameter.meaningfulStringValue, 10);
      if (!isNaN(paperWidth)) {
        return paperWidth;
      }
    }
    return this.defaultPrinterPaperWidth;
  }

  get logoPrintingFilename(): string {
    const logoPrintingFilenameParameter = this.getConfigurationParameterByType(ConfigurationParameterType.LogoPrintingFilename);
    if (logoPrintingFilenameParameter != undefined && logoPrintingFilenameParameter.meaningfulStringValue != undefined) {
      return logoPrintingFilenameParameter.meaningfulStringValue;
    } else {
      return this.defaultLogoPrintingFileName;
    }
  }

  get usecasesPrintingConfigurationList(): UsecasePrintingConfiguration[] {
    const usecasesPrintingConfigurationListParameter = this.getConfigurationParameterByType(ConfigurationParameterType.UsecasesPrintingConfiguration);
    if (usecasesPrintingConfigurationListParameter != undefined) {
      return FormatHelper.formatUsecasesPrintingConfigurationListFromObject(
        JSON.parse(usecasesPrintingConfigurationListParameter.meaningfulStringValue));
    } else {
      return undefined;
    }
  }

  get templateList(): PrintingTemplate[] {
    return this._templateList;
  }

  get printingGlobalSettings(): IDictionaryStringKey<string> {
    return this._printingGlobalSettings;
  }

  get clockRefreshFrecuency(): number {
    return this._clockRefreshFrecuency;
  }

  get networkConnectionRefreshFrecuency(): number {
    return this._networkConnectionRefreshFrecuency;
  }

  get configurationParameterList(): ConfigurationParameter[] {
    return this._configurationParameterList;
  }

  get allowPendingPayment(): boolean {
    const allowPendingPaymentParameter: ConfigurationParameter =
      this.getConfigurationParameterByType(ConfigurationParameterType.AllowPendingPaymentForKnownCustomer);
    if (allowPendingPaymentParameter != undefined) {
      if (allowPendingPaymentParameter.meaningfulStringValue == '1' ||
          allowPendingPaymentParameter.meaningfulStringValue.toLowerCase() == 'true' ) {
        return true;
      }
    }
    return false;
  }

  get isDevolutionAsCreditNote(): boolean {
    const isDevolutionAsCreditNoteParameter: ConfigurationParameter =
      this.getConfigurationParameterByType(ConfigurationParameterType.IsDevolutionAsCreditNote);
    if (isDevolutionAsCreditNoteParameter != undefined) {
      if (isDevolutionAsCreditNoteParameter.meaningfulStringValue == '1' ||
          isDevolutionAsCreditNoteParameter.meaningfulStringValue.toLowerCase() == 'true') {
            return true;
      }
    }
    return false;
  }

  get rectifyingSeriesForStandardSaleFunctionalityMode(): FuncionalityMode {
    const rectifyingSeriesForStandardSaleFunctionalityModeParameter: ConfigurationParameter =
      this.getConfigurationParameterByType(ConfigurationParameterType.RectifyingSeriesForStandardSaleFunctionalityMode);
    if (rectifyingSeriesForStandardSaleFunctionalityModeParameter != undefined) {
      if (rectifyingSeriesForStandardSaleFunctionalityModeParameter.meaningfulStringValue == '1' ||
        rectifyingSeriesForStandardSaleFunctionalityModeParameter.meaningfulStringValue.toLowerCase() == 'needed') {
          return FuncionalityMode.ON;
      }
      if (rectifyingSeriesForStandardSaleFunctionalityModeParameter.meaningfulStringValue == '2' ||
        rectifyingSeriesForStandardSaleFunctionalityModeParameter.meaningfulStringValue.toLowerCase() == 'optional') {
          return FuncionalityMode.OPTIONAL;
        }
    }
    return FuncionalityMode.OFF;
  }

  get rectifyingSeriesForInvoiceSaleFunctionalityMode(): FuncionalityMode {
    const rectifyingSeriesForInvoiceSaleFunctionalityModeParameter: ConfigurationParameter =
      this.getConfigurationParameterByType(ConfigurationParameterType.RectifyingSeriesForInvoiceFunctionalityMode);
    if (rectifyingSeriesForInvoiceSaleFunctionalityModeParameter != undefined) {
      if (rectifyingSeriesForInvoiceSaleFunctionalityModeParameter.meaningfulStringValue == '1' ||
        rectifyingSeriesForInvoiceSaleFunctionalityModeParameter.meaningfulStringValue.toLowerCase() == 'needed') {
          return FuncionalityMode.ON;
      }
      if (rectifyingSeriesForInvoiceSaleFunctionalityModeParameter.meaningfulStringValue == '2' ||
        rectifyingSeriesForInvoiceSaleFunctionalityModeParameter.meaningfulStringValue.toLowerCase() == 'optional') {
          return FuncionalityMode.OPTIONAL;
        }
    }
    return FuncionalityMode.OFF;
  }

  get rectifyingSeriesForCreditNoteFunctionalityMode(): FuncionalityMode {
    const rectifyingSeriesForCreditNoteFunctionalityModeParameter: ConfigurationParameter =
      this.getConfigurationParameterByType(ConfigurationParameterType.RectifyingSeriesForCreditNoteunctionalityMode);
    if (rectifyingSeriesForCreditNoteFunctionalityModeParameter != undefined) {
      if (rectifyingSeriesForCreditNoteFunctionalityModeParameter.meaningfulStringValue == '1' ||
        rectifyingSeriesForCreditNoteFunctionalityModeParameter.meaningfulStringValue.toLowerCase() == 'needed') {
          return FuncionalityMode.ON;
      }
      if (rectifyingSeriesForCreditNoteFunctionalityModeParameter.meaningfulStringValue == '2' ||
        rectifyingSeriesForCreditNoteFunctionalityModeParameter.meaningfulStringValue.toLowerCase() == 'optional') {
          return FuncionalityMode.OPTIONAL;
        }
    }
    return FuncionalityMode.OFF;
  }

  get currencyList(): Array<Currency> {
    return this._currencyList;
  }

  get seriesList(): Array<Series> {
    return this._seriesList;
  }

  get baseCurrency(): Currency {
    if (this._currencyList != undefined) {
      return this._currencyList.find(c => c.priorityType == CurrencyPriorityType.base);
    } else {
      return undefined;
    }
  }

  get secondaryCurrency(): Currency {
    if (this._currencyList != undefined) {
      return this._currencyList.find(c => c.priorityType == CurrencyPriorityType.secondary);
    } else {
      return undefined;
    }
  }

  get maxDaysSpanForCopyDocumentSearch(): number {
    const ret = this.userConfiguration.maxDaysSpanForCopyDocumentSearch;
    return ret == undefined ? 8 : ret;
  }

  get maxDaysSpanForCollectPendingDocumentSearch(): number {
    const ret = this.userConfiguration.maxDaysSpanForCollectPendingDocumentSearch;
    return ret == undefined ? 32 : ret;
  }

  get maxDaysSpanForRunawayDocumentSearch(): number {
    const ret = this.userConfiguration.maxDaysSpanForRunawayDocumentSearch;
    return ret == undefined ? 32 : ret;
  }

  get company(): Company {
    return this._company;
  }

  get shop(): Shop {
    return this._shop;
  }

  // todo leer de configuracion
  get volume(): Volume {
    return {
      symbol: 'l',
      description: 'Litros'
    };
  }

  // TODO: Hardcoded para demo
  get loyaltyProductId(): string {
    return this.company.id + 'LYTY';
  }

  get decimalPrecisionConfiguration(): DecimalPrecisionConfiguration {
    return this._decimalPrecisionConfiguration;
  }

  get printerPosCommands(): PosCommands {
    return this._printerPosCommands;
  }

  getCurrencyByType(currencyType: CurrencyPriorityType): Currency {
    return this.currencyList.find(c => c.priorityType == currencyType);
  }

  getPaymentMethodByType(paymentMethodType: PaymentMethodType): PaymentMethod {
    return this.paymentMethodList.find(pm => pm.type == paymentMethodType);
  }

  getSeriesByType(seriesType: SeriesType): Series {
    return this.seriesList.find(s => s.type == seriesType);
  }
  getSeriesById(idSerie: string): Series {
    return this._seriesList.find(x => x.id == idSerie);
  }

  // Obtiene un parámetro de configuración a partir de un ConfigurationParameterType dado
  getConfigurationParameterByType(configurationParameterType: ConfigurationParameterType): ConfigurationParameter {
    return this._configurationParameterList.find(cp => cp.type == configurationParameterType);
  }
  getConfigurationParameterByName(nparam: string, ngroup: string): ConfigurationParameter {
    return this._configurationParameterList.find(cp => cp.name == nparam && cp.groupName == ngroup);
  }
  //#endregion Getters

  //#region Setters

  set defaultBankCardId(defaultBankCardId: string) {
    this._defaultBankCardId = defaultBankCardId;
  }

  set defaultOperator(defaultOperator: string) {
    this._defaultOperator = defaultOperator;
  }

  set defaultCustomer(defaultCustomer: string) {
    this._defaultCustomer = defaultCustomer;
  }

  set defaultCountryId(defaultCountryId: number) {
    this._defaultCountryId = defaultCountryId;
  }

  set userConfiguration(userConfiguration: any) {
    this._userConfiguration = userConfiguration;
  }

  set configurationParameterList(configurationParameterList: ConfigurationParameter[]) {
    this._configurationParameterList = configurationParameterList;
  }

  set paymentMethodList(paymentMethodList: PaymentMethod[]) {
    this._paymentMethodList = paymentMethodList;
  }

  set currencyList(currencyList: Array<Currency>) {
    this._currencyList = currencyList;
  }

  set seriesList(seriesList: Array<Series>) {
    this._seriesList = seriesList;
  }

  set unknownCustomerId(unknownCustomerId: string) {
    this._unknownCustomerId = unknownCustomerId;
  }

  set templateList(templateList: Array<PrintingTemplate>) {
    this._templateList = templateList;
  }

  set printingGlobalSettings(printingGlobalSettings: IDictionaryStringKey<string>) {
    this._printingGlobalSettings = printingGlobalSettings;
  }

  set company(company: Company) {
    this._company = company;
  }

  set shop(shop: Shop) {
    this._shop = shop;
  }

  set clockRefreshFrecuency(time: number) {
    this._clockRefreshFrecuency = time;
  }

  set networkConnectionRefreshFrecuency(time: number) {
    this._networkConnectionRefreshFrecuency = time;
  }

  set decimalPrecisionConfiguration(decimalPrecisionConfiguration: DecimalPrecisionConfiguration) {
    this._decimalPrecisionConfiguration = decimalPrecisionConfiguration;
  }

  set printerPosCommands(printerPosCommands: PosCommands) {
    this._printerPosCommands = printerPosCommands;
  }

  //#endregion Setters

  //#region Aux methods

  /**
   *
   * @private
   * @returns {Promise<GetCompanyResponse>}
   * @memberof AppDataConfiguration
   * @throws {Error}
   */
  private async _getCompanyInformationAsync(): Promise<GetCompanyResponse> {
    const getCompanyResponse: GetCompanyResponse = await this._http.postJsonPromiseAsync(
      `${this.apiUrl}/GetCompany`, { Identity: this._userConfiguration.Identity });

    if (getCompanyResponse != undefined) {
      if (getCompanyResponse.status == GetCompanyResponseStatuses.successful) {
        console.log('Retrieved company information from service:');
        console.log(getCompanyResponse);
        return getCompanyResponse;
      } else {
        throw new Error(
          `Cannot retrieve company information from service. Service response: ${getCompanyResponse.message}`
        );
      }
    } else {
      throw new Error(`Cannot retrieve company information from service.`);
    }
  }

  /**
   *
   * @private
   * @returns {Promise<GetShopResponse>}
   * @memberof AppDataConfiguration
   * @throws {Error}
   */
  private async _getShopInformationAsync(): Promise<GetShopResponse> {
    const getShopResponse: GetShopResponse = await this._http.postJsonPromiseAsync(
      `${this.apiUrl}/GetShop`, { Identity: this._userConfiguration.Identity });

    if (getShopResponse != undefined) {
      if (getShopResponse.status == GetShopResponseStatuses.successful) {
        console.log('Retrieved shop information from service:');
        console.log(getShopResponse);
        return getShopResponse;
      } else {
        throw new Error(
          `Cannot retrieve shop information from service. Service response: ${getShopResponse.message}`
        );
      }
    } else {
      throw new Error(`Cannot retrieve shop information from service.`);
    }
  }

  /**
   *
   * @private
   * @returns {Promise<GetPaymentMethodsResponse>}
   * @memberof AppDataConfiguration
   * @throws {Error}
   */
  private async _getPaymentMethodsAsync(): Promise<GetPaymentMethodsResponse> {
    const getPaymentMethodsResponse: GetPaymentMethodsResponse = await this._http.postJsonPromiseAsync(
      `${this.apiUrl}/GetPaymentMethods`, { Identity: this._userConfiguration.Identity });

    if (getPaymentMethodsResponse != undefined) {
      if (getPaymentMethodsResponse.status == GetPaymentMethodsResponseStatuses.successful) {
        console.log('Retrieved paymentMethods from service:');
        console.log(getPaymentMethodsResponse);
        return getPaymentMethodsResponse;
      } else {
        throw new Error(`Cannot retrive payment methods from service. Service response: ${getPaymentMethodsResponse.message}`);
      }
    } else {
      throw new Error(`Cannot retrive payment methods from service.`);
    }
  }

  /**
   *
   *
   * @private
   * @returns {Promise<GetCurrenciesResponse>}
   * @memberof AppDataConfiguration
   * @throws {Error}
   */
  private async _getCurrenciesAsync(): Promise<GetCurrenciesResponse> {
    const getCurrenciesResponse: GetCurrenciesResponse = await this._http.postJsonPromiseAsync(
      `${this.apiUrl}/GetCurrencies`, { identity: this._userConfiguration.Identity });

    if (getCurrenciesResponse != undefined) {
      if (getCurrenciesResponse.status == GetCurrenciesResponseStatuses.successful) {
        console.log('Retrieved currencies from service:');
        console.log(getCurrenciesResponse);
        return getCurrenciesResponse;
      } else {
        throw new Error(`Cannot retrive currencies from service. Service response: ${getCurrenciesResponse.message}`);
      }
    } else {
      throw new Error(`Cannot retrive currencies from service.`);
    }
  }

  /**
   *
   *
   * @private
   * @returns {Promise<GetSeriesResponse>}
   * @memberof AppDataConfiguration
   * @throws {Error}
   */
  private async _getSeriesListAsync(): Promise<GetSeriesResponse> {
    const getSeriesResponse: GetSeriesResponse = await this._http.postJsonPromiseAsync(
      `${this.apiUrl}/GetSeries`, { Identity: this._userConfiguration.Identity });

    if (getSeriesResponse != undefined) {
      if (getSeriesResponse.status == GetSeriesResponseStatuses.successful) {
        console.log('Retrieved posConfiguration from service:');
        console.log(getSeriesResponse);
        return getSeriesResponse;
      } else {
        throw new Error(`Cannot retrive series from service. Service response: ${getSeriesResponse.message}`);
      }
    } else {
      throw new Error(`Cannot retrive series from service.`);
    }
  }

  /**
   *
   *
   * @private
   * @returns {Promise<GetPrintingConfigurationResponse>}
   * @memberof AppDataConfiguration
   * @throws {Error}
   */
  private async _getPrintingCofigurationAsync(): Promise<GetPrintingConfigurationResponse> {
    const getPrintingConfigurationResponse: GetPrintingConfigurationResponse = await this._http.postJsonPromiseAsync(
      `${environment.apiUrl}/GetPrintingConfiguration`, {
        Identity: this._userConfiguration.Identity,
        UsecasesPrintingConfigurationList: this.usecasesPrintingConfigurationList
      }
    );

    if (getPrintingConfigurationResponse != undefined) {
      if (getPrintingConfigurationResponse.status == GetPrintingConfigurationResponseStatuses.successful) {
        console.log('Retrieved printing configuration from service:');
        console.log(getPrintingConfigurationResponse);
        return getPrintingConfigurationResponse;
      } else {
        throw new Error(`Cannot retrive printing configuration from service. Service response: ${getPrintingConfigurationResponse.message}`);
      }
    } else {
      throw new Error('Cannot retrive printing configuration from service.');
    }
  }

  //#endregion Aux methods
}
