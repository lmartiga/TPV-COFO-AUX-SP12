import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { FormatHelper } from 'app/helpers/format-helper';
import { LogHelper } from 'app/helpers/log-helper';
import { Document } from 'app/shared/document/document';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { DocumentSeriesService } from 'app/services/document/document-series.service';
import { DocumentService } from 'app/services/document/document.service';
import { Currency } from 'app/shared/currency/currency';
import { CurrencyPriorityType } from 'app/shared/currency/currency-priority-type.enum';
import { FinalizingDocumentFlowType } from 'app/shared/document/finalizing-document-flow-type.enum';
import { PaymentMethodType } from 'app/shared/payments/payment-method-type.enum';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';

@Injectable()
export class CreditCardPaymentService {

  private _paymentFinalized: Subject<boolean> = new Subject();

  constructor(
    private _appDataConfig: AppDataConfiguration,
    private _seriesService: DocumentSeriesService,
    private _documentService: DocumentService,
    private _statusBarService: StatusBarService
  ) {
  }

  sendSale(document: Document, emitBill: boolean, terminalPrintingText: string = '') {
    if (document == undefined) {
      this._paymentFinalized.next(false);
      return;
    }
    const bankcardPM = this._appDataConfig.getPaymentMethodByType(PaymentMethodType.bankcard);
    const baseCurrency: Currency = this._appDataConfig.currencyList.find(c => c.priorityType == CurrencyPriorityType.base);
    if (baseCurrency == undefined) {
      LogHelper.logError(undefined, 'No se ha podido recuperar la divisa base de configuración');
      this._paymentFinalized.next(false);

      return;
    }
    document.paymentDetails = [{
      paymentMethodId: bankcardPM.id,
      paymentDateTime: FormatHelper.formatToUTCDateFromLocalDate(new Date()),
      changeFactorFromBase: 1,
      currencyId: baseCurrency.id,
      primaryCurrencyGivenAmount: document.totalAmountWithTax,
      primaryCurrencyTakenAmount: document.totalAmountWithTax,
      extraData: { ['AuthorizationText']: terminalPrintingText != undefined ? terminalPrintingText : '' },
    }];

    document.series = this._seriesService.getSeriesByFlow(
      emitBill ? FinalizingDocumentFlowType.EmittingBill : FinalizingDocumentFlowType.EmittingTicket,
      document.totalAmountWithTax);

    if (emitBill) {
      this._documentService.sendInvoiceDocuments(new Array<Document>(document))
      .first().subscribe(response => {
        setTimeout(() => {
          this._statusBarService.resetProgress();
        }, 3000);
        this._paymentFinalized.next(response);
      });
    } else {
      this._documentService.sendSaleDocuments(new Array<Document>(document))
      .first().subscribe(response => {
        setTimeout(() => {
          this._statusBarService.resetProgress();
        }, 3000);
        this._paymentFinalized.next(response);
      });
    }
  }

  managePaymentFinalized(success: boolean) {
    console.log('REALIZAR VENTA CREDIT CARD:');
    console.log(success);
    if (success) {
      this._statusBarService.publishMessage('Sale finished successfully');
    }
  }
  onPaymentFinalized(): Observable<boolean> {
    return this._paymentFinalized.asObservable();
  }
}
