import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';
import { FormatHelper } from 'app/helpers/format-helper';
import { DocumentSeriesService } from 'app/services/document/document-series.service';
import { DocumentService } from 'app/services/document/document.service';
import { Document } from 'app/shared/document/document';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { PaymentMethodType } from 'app/shared/payments/payment-method-type.enum';
import { FinalizingDocumentFlowType } from 'app/shared/document/finalizing-document-flow-type.enum';
import { RunawayData } from 'app/shared/runaway-data';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';
import { ConfirmActionService } from '../confirm-action/confirm-action.service';
import { ConfirmActionType } from '../../shared/confirmAction/confirm-action-type.enum';

@Injectable()
export class RunawayPaymentService {

  constructor(
    private _seriesService: DocumentSeriesService,
    private _documentService: DocumentService,
    private _appDataConfig: AppDataConfiguration,
    private _statusBarService: StatusBarService,
    private _confirmActionSvc: ConfirmActionService
  ) {
  }

  existsRunawayPaymentMethod(): boolean {
    const runawayPM = this._appDataConfig.getPaymentMethodByType(PaymentMethodType.runaway);
    if (runawayPM == undefined) {
      this._confirmActionSvc.promptActionConfirm(
        'Falta configuración para metodo de pago Fuga',
        'Aceptar', undefined, 'Error', ConfirmActionType.Error)
        .first().subscribe(); // ignoramos la salida del cuadro informativo
      this._statusBarService.publishMessage('Falta configuración para metodo de pago Fuga');
      return false;
    }
    return true;
  }

  sendRunawayPayment(document: Document, runawayData: RunawayData): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      const runawayPM = this._appDataConfig.getPaymentMethodByType(PaymentMethodType.runaway);
      document.paymentDetails = [{
        paymentMethodId: runawayPM.id,
        paymentDateTime: FormatHelper.formatToUTCDateFromLocalDate(new Date()),
        currencyId: document.currencyId,
        primaryCurrencyGivenAmount: 0,
        primaryCurrencyTakenAmount: 0,
        secondaryCurrencyTakenAmount: 0,
        secondaryCurrencyGivenAmount: 0,
        changeFactorFromBase: 1,
        extraData: {
          ['Remarks']: runawayData != undefined ? runawayData.remarks != undefined ? runawayData.remarks.toString() : '' : '',
          ['Plate']: runawayData != undefined ? runawayData.plate != undefined ? runawayData.plate.toString() : '' : ''
        }
      }];
      document.series = this._seriesService.getSeriesByFlow(FinalizingDocumentFlowType.EmittingTicket, 0);
      this._documentService.sendRunawayDocuments(new Array<Document>(document))
        .first().subscribe(response => {
          setTimeout(() => {
            this._statusBarService.resetProgress();
          }, 3000);
          observer.next(response);
        });
    });
  }
}
