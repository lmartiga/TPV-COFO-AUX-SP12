import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';

import { DocumentSeriesService } from 'app/services/document/document-series.service';
import { DocumentService } from 'app/services/document/document.service';
import { Document } from 'app/shared/document/document';
import { FinalizingDocumentFlowType } from 'app/shared/document/finalizing-document-flow-type.enum';
import { PaymentDetail } from 'app/shared/payments/payment-detail';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';
import { PaymentPurpose } from '../../shared/payments/PaymentPurpose.enum';
import { Subscriber } from '../../../../node_modules/rxjs/Subscriber';
import { CustomerInternalService } from '../customer/customer-internal.service';
import { LogHelper } from '../../helpers/log-helper';
import { AppDataConfiguration } from '../../config/app-data.config';
import { ConfirmActionService } from '../confirm-action/confirm-action.service';
import { ConfirmActionType } from 'app/shared/confirmAction/confirm-action-type.enum';
import { SignalRPrintingService } from 'app/services/signalr/signalr-printing.service';
import {
  SendCommandToPrinterResponse
} from 'app/shared/signalr-server-responses/printingModuleHub/send-command-to-printer-response';
import {
  SendCommandToPrinterResponseStatuses
} from 'app/shared/signalr-server-responses/printingModuleHub/send-command-to-printer-response-statuses.enum';

@Injectable()
export class MixtPaymentService {


  constructor(
    private _serieService: DocumentSeriesService,
    private _documentService: DocumentService,
    private _statusBarService: StatusBarService,
    private _customerInternalSvc: CustomerInternalService,
    private _appDataConfig: AppDataConfiguration,
    private _signalRPrintingServ: SignalRPrintingService,
    private confirmActionSvc: ConfirmActionService

  ) {
  }
  requestEndSale(document: Document, paymentDetailList: Array<PaymentDetail>,
    emitirFactura: boolean, paymentPurpose: PaymentPurpose,
    changeDelivered: number, pendintAmount: number): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (document == undefined || document.customer == undefined) {
        LogHelper.logError(undefined, 'El documento o el cliente es undefined');
        observer.next(false);
      }

      if (paymentDetailList == undefined) {
        paymentDetailList = [];
      }

      if (pendintAmount > 0) {
        const isUnknownCustomer = this._customerInternalSvc.isUnknownCustomer(document.customer.id);
        const allowPendingPayment = this._appDataConfig.allowPendingPayment;
        if (isUnknownCustomer || !allowPendingPayment) {
          this.confirmActionSvc.promptActionConfirm(
            'No se permite dejar importe pendiente',
            'Aceptar', undefined,
            'Error',
            ConfirmActionType.Error);
          observer.next(false);
          return;
        }
      }

      document.pendingAmountWithTax = pendintAmount;
      let sendSubscription: Observable<boolean>;
      switch (paymentPurpose) {
        case PaymentPurpose.NewDocument:
          sendSubscription = this.sendSale(document, paymentDetailList, emitirFactura, changeDelivered);
          break;
        case PaymentPurpose.PendingPayment:
          sendSubscription = this.sendPaymentDetail(document, paymentDetailList);
          break;
        case PaymentPurpose.Refund:
          sendSubscription = this.sendPaymentRefund(document, paymentDetailList);
          break;
        default:
      }
      sendSubscription.first().subscribe(sendResult => {
        observer.next(sendResult);
      });
    });
  }

  manageSaleEnded(success: boolean) {
    this._statusBarService.publishMessage(success ? 'Venta realizada correctamente' : 'No se pudo realizar la venta.');
    LogHelper.trace('Realizar venta mixta');
  }

  private sendSale(document: Document, paymentDetailList: Array<PaymentDetail>,
    emitirFactura: boolean, changeDelivered: number): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (document == undefined) {
        observer.next(false);
        return;
      }
      // unifico en un observable tanto si hay que pedir cliente o sino, para no repetir codigo
      Observable.create((innerOperations: Subscriber<boolean>) => {
        // agrego detalles de pago proporcionados
        document.paymentDetails = paymentDetailList;
        document.changeDelivered = changeDelivered;
        if (emitirFactura) {
          // si ya tiene cliente
          if (document.customer != undefined
            && !this._customerInternalSvc.isUnknownCustomer(document.customer.id)) {
            document.series = this._serieService.getSeriesByFlow(
              FinalizingDocumentFlowType.EmittingBill,
              document.totalAmountWithTax);
            innerOperations.next(true);
            return;
          }
          // solicitamos cliente
          this._customerInternalSvc.requestCustomerForInvoice()
            .first().subscribe(customerResult => {
              if (customerResult == undefined || customerResult.customer == undefined) {
                innerOperations.next(false);
                return;
              }
              if (this._customerInternalSvc.isUnknownCustomer(customerResult.customer.id)) {
                this.confirmActionSvc.promptActionConfirm(
                  'No se puede facturar a cliente contado',
                  'Aceptar', undefined,
                  'Error',
                  ConfirmActionType.Error);
                innerOperations.next(false);
                return;
              }
              document.plate = customerResult.plate;
              document.customer = customerResult.customer;
              // generar serie si es modo nuevo ticket
              document.series = this._serieService.getSeriesByFlow(
                FinalizingDocumentFlowType.EmittingBill,
                document.totalAmountWithTax);

              innerOperations.next(true);
            });
        } else {
          document.series = this._serieService.getSeriesByFlow(
            FinalizingDocumentFlowType.EmittingTicket,
            document.totalAmountWithTax);
          innerOperations.next(true);
        }
      }).first().subscribe((operations: boolean) => {
        if (!operations) {
          observer.next(false);
          return;
        }
        const sendSaleFunc = emitirFactura ? this._documentService.sendInvoiceDocuments([document])
          : this._documentService.sendSaleDocuments([document]);
        sendSaleFunc
          .first().subscribe(response => {
            setTimeout(() => {
              this._statusBarService.resetProgress();
            }, 3000);
            observer.next(response);
          });
      });
    });
  }

  private sendPaymentDetail(document: Document, paymentDetailList: Array<PaymentDetail>): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      this._documentService.sendPaymentDetail(document.documentId, paymentDetailList)
        .first().subscribe(response => {
          observer.next(response);
        });

        if (this._appDataConfig.printerPosCommands != undefined) {
          if (this._appDataConfig.printerPosCommands.openDrawer != undefined) {
            this._signalRPrintingServ.sendCommandToPrinter(
              this._appDataConfig.printerPosCommands.openDrawer, this._appDataConfig.defaultPosPrinterName)
            .first()
            .subscribe(
              (sendCommandToPrinterResponse: SendCommandToPrinterResponse) => {
                if (sendCommandToPrinterResponse.status != SendCommandToPrinterResponseStatuses.successful) {
                  this._statusBarService.publishMessage('Se ha producido un error al abrir el cajón');
                }
            });
          } else {
            console.log('Open cash drawer commad undefined: ' + this._appDataConfig.printerPosCommands.openDrawer);
          }
        } else {
          console.log('Printer pos command undefined: ' + this._appDataConfig.printerPosCommands);
        }
    });
  }

  private sendPaymentRefund(document: Document, paymentDetailList: Array<PaymentDetail>): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      document.paymentDetails = paymentDetailList;
      document.paymentDetails.forEach(paymentDetail => {
        if (paymentDetail.primaryCurrencyGivenAmount > 0) {
          paymentDetail.primaryCurrencyGivenAmount = -paymentDetail.primaryCurrencyGivenAmount;
        }
        if (paymentDetail.primaryCurrencyTakenAmount > 0) {
          paymentDetail.primaryCurrencyTakenAmount = -paymentDetail.primaryCurrencyTakenAmount;
        }
        if (paymentDetail.secondaryCurrencyGivenAmount > 0) {
          paymentDetail.secondaryCurrencyGivenAmount = -paymentDetail.secondaryCurrencyGivenAmount;
        }
        if (paymentDetail.secondaryCurrencyTakenAmount > 0) {
          paymentDetail.secondaryCurrencyTakenAmount = -paymentDetail.secondaryCurrencyTakenAmount;
        }
      });
      this._documentService.sendPaymentRefundDocuments([document])
        .first().subscribe(response => {
          setTimeout(() => {
            this._statusBarService.resetProgress();
          }, 3000);
          observer.next(response);
        });
    });

  }


}
