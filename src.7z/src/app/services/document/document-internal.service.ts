import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

import { RoundPipe } from 'app/pipes/round.pipe';
import { DocumentLine } from 'app/shared/document/document-line';
import { Document } from 'app/shared/document/document';
import { Observable } from 'rxjs/Observable';
import { FuellingPointSupplyLine } from 'app/shared/fuelling-point/fuelling-point-supply-line';
import { SuplyTransaction } from 'app/shared/fuelling-point/suply-transaction';
import { LockedSuplyTransaction } from 'app/shared/fuelling-point/locked-suply-transaction';
import { OperatorInternalService } from 'app/services/operator/operator-internal.service';
import { IbusinessSpecificLine } from 'app/shared/ibusiness-specific-line';
import { DocumentSeriesService } from 'app/services/document/document-series.service';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { GenericHelper } from 'app/helpers/generic-helper';
import { SeriesType } from 'app/shared/series/series-type';
import { FinalizingDocumentFlowType } from 'app/shared/document/finalizing-document-flow-type.enum';

@Injectable()
export class DocumentInternalService {

  private _currentDocumentList: Array<Document> = [];

  private _selectedDocumentIndex = 0;

  // linea que se obtendrá cuando el usuario pulse sobre un producto
  private _requestLineInsertion: Subject<DocumentLine> = new Subject();
  private _requestLineDeletion: Subject<number> = new Subject();

  // comunicar reset del document
  private _resetDocument: Subject<{ result: boolean, mustResetOperator: boolean }> = new Subject();

  /**  TODO: Esta configuración de decimales tiene que venir por configuración
  *   - string` which has a following format: <br>
  *      <code>{minIntegerDigits}.{minFractionDigits}-{maxFractionDigits}</code>
  *   - `minIntegerDigits` is the minimum number of integer digits to use. Defaults to `1`.
  *   - `minFractionDigits` is the minimum number of digits after fraction. Defaults to `0`.
  *   - `maxFractionDigits` is the maximum number of digits after fraction. Defaults to `3`.
  * @private
  * @memberof EditDocumentLineComponent
  */

  // todas las líneas de un document
  lines = new Array<DocumentLine>();
  // Limpiar lineas del documento
  private _cleanDucumentLines: Subject<any> = new Subject();

  constructor(
    private _roundPipe: RoundPipe,
    private _operatorInternalSvc: OperatorInternalService,
    private _documentSerieSvc: DocumentSeriesService,
    private _appDataConfig: AppDataConfiguration
  ) { }

  // Actualizar la lista de documentos
  set currentDocumentList(documentList: Array<Document>) {
    // TODO: Para la reingeniería hay que decidir si esto debería ser una asignación de referencia
    //       o se debería hacer una copia. Del mismo modo hay que decidir si la lista original la
    //       'guarda' este servicio y el documento (y el resto de componentes) la lee y/o modifica
    if (documentList == undefined) {
      this._currentDocumentList = [];
    } else {
      this._currentDocumentList = documentList;
    }
  }

  // Actualiza el índice del documento actual
  set selectedDocumentIndex(index: number) {
    this._selectedDocumentIndex = index;
  }

  // Por ahora usaremos este servicio como almacén principal para quien quiera consultar el documento
  get currentDocument(): Document {
    return this._currentDocumentList[this._selectedDocumentIndex];
  }

  documentResetRequested(): Observable<{ result: boolean, mustResetOperator: boolean }> {
    return this._resetDocument.asObservable();
  }

  lineInsertionRequested(): Observable<DocumentLine> {
    return this._requestLineInsertion.asObservable();
  }

  /**
   *
   * @returns {boolean} Returns true if any of the documents has lines. Otherwise, false.
   * @memberof DocumentInternalService
   */
  isAnyActiveDocumentWithLines(): boolean {
    return this._currentDocumentList != undefined &&
      this._currentDocumentList.find(d => d.lines != undefined && d.lines.length > 0) != undefined;
  }

  // ------------------------------------------------------------------------------------------------

  // para pasar la línea y sus datos al documento
  // primero se edita su id por un guid y se redondean decimales
  publishLineData(data: DocumentLine): number {
    if (!this.currentDocument.customer || !this.currentDocument.operator) {
      return undefined;
    }

    data.priceWithTax = this._roundPipe.transformInBaseCurrency(data.priceWithTax);
    data.discountPercentage = this._roundPipe.transformInBaseCurrency(data.discountPercentage);
    data.totalAmountWithTax = this._roundPipe.transformInBaseCurrency(data.totalAmountWithTax);
    if (data.priceWithoutTax == undefined || data.priceWithoutTax == 0) {
      // no está seteado el precio sin impuesto
      if (data.taxPercentage == undefined || data.priceWithTax == undefined) {
        throw Error('El articulo no provee informacion completa, falta precio sin impuesto y mecanismo para obtenerlo (porcentaje de impuesto y precio con impuesto)');
      }
      const taxAmount = this._roundPipe.transform(data.priceWithTax - (data.priceWithTax / (1 + (data.taxPercentage / 100))), this._appDataConfig.decimalPrecisionConfiguration.decimalPositionsForUnitPricesWithoutTax);
      data.priceWithoutTax = data.priceWithTax - taxAmount;
    }
    this._requestLineInsertion.next(data);
    if (!this.lines) {
      this.lines = [];
    }

    this.lines.push(data);
    return this.lines.length;
  }

  // informa de que hay que borrar las líneas introducidas en el documento
  deleteDocumentData(mustResetOperator: boolean = false) {
    this._resetDocument.next({ result: true, mustResetOperator });
  }

  cloneDocument(origen: Document): Document {
    if (origen == undefined) { return undefined; }
    // const clonedDocument = {...origen};
    const clonedDocument: Document = GenericHelper.deepCopy(origen);
    clonedDocument.lines.forEach(line => {
      line.businessSpecificLineInfo = undefined;
    });

    return clonedDocument;
  }

  /**
   * Indica si la transaccion ha sido incluida en alguna linea de algun documento del tpv
   * @param transaction Transaccion a buscar
   */
  hasTransaction(transaction: SuplyTransaction): boolean {
    for (const documento of this._currentDocumentList) {
      for (const linea of documento.lines) {
        const supplySpecificLine = linea.businessSpecificLineInfo as FuellingPointSupplyLine;
        if (supplySpecificLine == undefined || supplySpecificLine.supplyTransaction == undefined) {
          continue;
        }
        if (supplySpecificLine.supplyTransaction.id == transaction.id) {
          return true;
        }
      }
    }
    return false;
  }

  /**
   * Indica si existe algun documento con alguna operacion insertada
   */
  hasAnyDocumentWithLine(): boolean {
    for (const document of this._currentDocumentList) {
      if (document.lines != undefined && document.lines.length > 0) {
        return true;
      }
    }
    return false;
  }
  /**
   * Crea un documento a partir de la respuesta de la solicitud de bloqueo de una transaccion de devolucion.
   * @param transactionLineInfo informacion para generar una linea de documento referente a la devolucion de la transaccion
   * @param businessSpecificLineInfo [opcional] indica la información para linea especifica de negocio (acciones a realizar al completar o eliminar)
   */
  createDocumentForRefund(transactionLineInfo: LockedSuplyTransaction, businessSpecificLineInfo?: IbusinessSpecificLine): Document {
    const priceWithTax = transactionLineInfo.unitaryPricePreDiscount;
    const taxPercentage = transactionLineInfo.taxPercentage;
    const priceWithoutTax = this._roundPipe.transformInBaseCurrency(priceWithTax / (1 + (taxPercentage / 100)));

    // todo recuperar customer desde servicio?
    const document: Document = {
      customer: {
        id: transactionLineInfo.customerId,
        tin: undefined,
        businessName: undefined,
        addressList: []
      },
      operator: this._operatorInternalSvc.currentOperator,
      currencyId: this._appDataConfig.baseCurrency.id,
      lines: [{
        productId: transactionLineInfo.productId,
        quantity: transactionLineInfo.correspondingVolume,
        discountPercentage: transactionLineInfo.discountPercentage,
        description: transactionLineInfo.productName,
        priceWithTax: priceWithTax,
        discountAmountWithTax: transactionLineInfo.discountedAmount,
        totalAmountWithTax: transactionLineInfo.finalAmount,
        taxPercentage: taxPercentage,
        businessSpecificLineInfo: businessSpecificLineInfo,
        priceWithoutTax: priceWithoutTax,
        taxAmount: 0
      }],
      series: this._documentSerieSvc.getSeriesByFlow(transactionLineInfo.serieType == SeriesType.ticket ?
        FinalizingDocumentFlowType.EmittingDevolutionForTicket : FinalizingDocumentFlowType.EmittingDevolutionForBill,
        transactionLineInfo.finalAmount),
      totalAmountWithTax: transactionLineInfo.finalAmount,
      discountAmountWithTax: transactionLineInfo.discountedAmount,
      discountPercentage: transactionLineInfo.discountPercentage,
      referencedDocumentIdList: [transactionLineInfo.sourceDocumentId],
      referencedDocumentNumberList: [transactionLineInfo.sourceDocumentNumber]
    };
    return document;
  }

  deleteLine(index: number) {
    this._requestLineDeletion.next(index);
  }

  lineDeletionRequested(): Observable<number> {
    return this._requestLineDeletion.asObservable();
  }

  cleanDocumentLines() {
    this._cleanDucumentLines.next();
    }

    cleanDocumentLinesRequested(): Observable<any> {
    return this._cleanDucumentLines.asObservable();
    }

}
