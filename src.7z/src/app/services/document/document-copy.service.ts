import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subscriber } from 'rxjs/Subscriber';
import { LogHelper } from 'app/helpers/log-helper';
import { SignalRPrintingService } from 'app/services/signalr/signalr-printing.service';
import { Document } from 'app/shared/document/document';
import { PrintResponse } from 'app/shared/signalr-server-responses/printingModuleHub/print-response';
import { PrintResponseStatuses } from 'app/shared/signalr-server-responses/printingModuleHub/print-response-statuses.enum';
import { DocumentService } from 'app/services/document/document.service';

@Injectable()
export class DocumentCopyService {

  constructor(
    private _printService: SignalRPrintingService,
    private _documentService: DocumentService
  ) {
  }

  copySaleDocument(document: Document): Observable<boolean> {
    return this._copyDocument(document, 'SALE');
  }

  private _copyDocument(document: Document, useCase: string): Observable<boolean> {
    this._documentService.completCopyDocument(document);
    return Observable.create((observer: Subscriber<boolean>) => {
      this._printService.printDocument(document, useCase)
      .first().subscribe((printResponse: PrintResponse) => {
        if (printResponse.status == PrintResponseStatuses.successful) {
          // Si la respuesta de ambas solicitudes es positiva, reportamos ok al llamante
          observer.next(true);
        } else {
          LogHelper.trace(
            `La respuesta ha sido positiva, pero la impresión falló: ` +
            `${PrintResponseStatuses[printResponse.status]}. Mensaje: ${printResponse.message}`);
          observer.next(false);
        }
      });
    });
  }
}
