import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';

import { DocumentSearch } from 'app/shared/document-search/document-search';
import { HttpService } from 'app/services/http/http.service';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { DocumentSearchRequest } from 'app/shared/document-search/document-search-request';
import { CriteriaRelationshipType } from 'app/shared/document-search/criteria-relationship-type.enum';
import { PaymentPendingFilterType } from 'app/shared/document-search/payment-pending-filter-type.enum';
import { PaymentIdCriteria } from 'app/shared/document-search/criteriaTypes/payment-id-criteria';
import { ScopeType } from 'app/shared/document-search/scope-type.enum';
import { UsageType } from 'app/shared/document-search/usage-type.enum';
import { DocumentNumberCriteria } from 'app/shared/document-search/criteriaTypes/document-number-criteria';
import { TextMatchingType } from 'app/shared/document-search/criteriaTypes/text-matching-type.enum';
import { EmissionDateCriteria } from 'app/shared/document-search/criteriaTypes/emission-date-criteria';
import { DateTimeType } from 'app/shared/document-search/criteriaTypes/date-time-type.enum';
import { TotalAmountWithTaxCriteria } from 'app/shared/document-search/criteriaTypes/total-amount-with-tax-criteria';
import { OperatorIdCriteria } from 'app/shared/document-search/criteriaTypes/operator-id-criteria';
import { PlateCriteria } from 'app/shared/document-search/criteriaTypes/plate-criteria';
import { CriteriaType } from 'app/shared/document-search/criteria-type.enum';
import { SearchDocumentResponse } from 'app/shared/web-api-responses/search-document-response';
import { GetDocumentResponse } from 'app/shared/web-api-responses/get-document-response';
import { FormatHelper } from 'app/helpers/format-helper';
import { SearchDocumentMode } from 'app/shared/document-search/search-document-mode.enum';
import { PaymentMethodType } from 'app/shared/payments/payment-method-type.enum';
import { ExistenceType } from 'app/shared/document-search/criteriaTypes/existence-type.enum';
import { CustomerIdCriteria } from 'app/shared/document-search/criteriaTypes/customer-id-criteria';
import { OrderingFieldType } from 'app/shared/document-search/ordering-field-type.enum';
import { OrderingDirectionType } from 'app/shared/document-search/ordering-direction-type.enum';
import { RoundPipe } from 'app/pipes/round.pipe';

@Injectable()


export class DocumentSearchInternalService {

  private _usageType: UsageType;

  constructor(
    private _httpSvc: HttpService,
    private _appDataConfig: AppDataConfiguration,
    private _roundPipe: RoundPipe
  ) {
  }

  searchDocuments(paramsBusqueda: DocumentSearch): Observable<SearchDocumentResponse> {
    const criteriaList = new Array<any>();
    let usageType: UsageType;
    let paymentPendingFilter: PaymentPendingFilterType = PaymentPendingFilterType.noFilter;
    switch (paramsBusqueda.searchMode) {
      case SearchDocumentMode.Cancel:
        usageType = UsageType.Rectify;
        break;
      case SearchDocumentMode.Copy:
        usageType = UsageType.PrintCopy;
        break;
      case SearchDocumentMode.Runaway:
        const runawayPM = this._appDataConfig.getPaymentMethodByType(PaymentMethodType.runaway);
        const docPaymentCriteria: PaymentIdCriteria = {
          criteriaType: CriteriaType.paymentMethodId,
          idList: [runawayPM.id],
          existenceType: ExistenceType.exists,
        };
        criteriaList.push(docPaymentCriteria);
        usageType = UsageType.PayPending;
        paymentPendingFilter = PaymentPendingFilterType.onlyPaymentPendingDocuments;
        break;
      case SearchDocumentMode.Pending:
        usageType = UsageType.PayPending;
        paymentPendingFilter = PaymentPendingFilterType.onlyPaymentPendingDocuments;
        break;
      default:
        usageType = UsageType.Other;
    }
    this._usageType = usageType;

    const request: DocumentSearchRequest = {
      identity: this._appDataConfig.userConfiguration.Identity,
      criteriaList: criteriaList,
      criteriaRelationshipType: CriteriaRelationshipType.and,
      paymentPendingFilterType: paymentPendingFilter,
      scope: ScopeType.pos,
      usageType: usageType,
      orderingField: OrderingFieldType.emissionLocalDateTime,
      orderingDirection : OrderingDirectionType.descending

    };
    if (paramsBusqueda.document != undefined && paramsBusqueda.document.trim() != '') {
      const docNumberCriteria: DocumentNumberCriteria = {
        criteriaType: CriteriaType.documentNumber,
        number: paramsBusqueda.document,
        matchingType: TextMatchingType.Exact
      };
      criteriaList.push(docNumberCriteria);
    }
    if (paramsBusqueda.fromEmissionDate != undefined || paramsBusqueda.toEmissionDate != undefined) {
      const emissionDateCritera: EmissionDateCriteria = {
        criteriaType: CriteriaType.emissionDateTime,
        from: paramsBusqueda.fromEmissionDate,
        to: paramsBusqueda.toEmissionDate,
        type: DateTimeType.local // todo utc/local ???
      };
      criteriaList.push(emissionDateCritera);
    }
    if (paramsBusqueda.fromImport != undefined || paramsBusqueda.toImport != undefined) {
      const amountCriteria: TotalAmountWithTaxCriteria = {
        criteriaType: CriteriaType.totalAmountWithTax,
        from: paramsBusqueda.fromImport,
        to: paramsBusqueda.toImport
      };
      criteriaList.push(amountCriteria);
    }
    if (paramsBusqueda.operator != undefined && paramsBusqueda.operator.trim() != '') {
      const operatorCriteria: OperatorIdCriteria = {
        criteriaType: CriteriaType.operatorId,
        idList: [paramsBusqueda.operator]
      };
      criteriaList.push(operatorCriteria);
    }
    if (paramsBusqueda.plate != undefined && paramsBusqueda.plate.trim() != '') {
      const plateCriteria: PlateCriteria = {
        criteriaType: CriteriaType.paymentDetailPlate,
        plateNumber: paramsBusqueda.plate,
        matchingType: TextMatchingType.Anywhere
      };
      criteriaList.push(plateCriteria);
    }
    if (paramsBusqueda.customerId != undefined && paramsBusqueda.customerId.trim() != '') {
      const customerIdCriteria: CustomerIdCriteria = {
        criteriaType: CriteriaType.customerId,
        idList: [paramsBusqueda.customerId],
      };
      criteriaList.push(customerIdCriteria);
    }
    // TODO bugfix deserializacion case sensitive
    // quitar cuando se arregle en servicio
    for (let i = 0; i < criteriaList.length; i++) {
      const criteria = criteriaList[i];
      criteria.CriteriaType = criteria.criteriaType;
    }
    // Transformacion de fechas
    request.criteriaList.forEach(criteria => {
      if (criteria && criteria.CriteriaType && criteria.criteriaType == CriteriaType.emissionDateTime) {
        if (criteria.from) {
          criteria.from = FormatHelper.dateToISOString(criteria.from);
        }
        if (criteria.to) {
          criteria.to = FormatHelper.dateToISOString(criteria.to);
        }
      }

    });
    return this._httpSvc.postJsonObservable(`${this._appDataConfig.apiUrl}/SearchDocument`, request)
      .map(res => {
        const ret: SearchDocumentResponse = {
          status: res.status,
          message: res.message,
          searchMode: this._usageType,
          documentList: res.documentList.map((x: any) => {
            // conversión de fechas a string (si no, JSON las convierte a UTC)
            let emissionLocalDateTime, emissionUTCDateTime;
            if (x.emissionLocalDateTime) {
              emissionLocalDateTime = x.emissionLocalDateTime;
            }
            if (x.emissionUTCDateTime) {
              emissionUTCDateTime = x.emissionUTCDateTime;
            }
            return {
              id: x.id,
              documentNumber: x.documentNumber,
              operatorName: x.operatorName,
              emissionLocalDateTime: new Date(x.emissionLocalDateTime),
              emissionUTCDateTime: new Date(x.emissionUTCDateTime),
              customerTIN: x.customerTIN,
              customerBusinessName: x.customerBusinessName,
              totalAmountWithTax: x.totalAmountWithTax,
              pendingAmountWithTax: x.pendingAmountWithTax
            };
          })
        };
        return ret;
      });
  }
  getDocument(idDocument: string, searchMode: SearchDocumentMode): Observable<GetDocumentResponse> {
    let usageType: UsageType;
    switch (searchMode) {
      case SearchDocumentMode.Cancel:
        usageType = UsageType.Rectify;
        break;
      case SearchDocumentMode.Copy:
        usageType = UsageType.PrintCopy;
        break;
      case SearchDocumentMode.Runaway:
        usageType = UsageType.PayPending;
        break;
      case SearchDocumentMode.Pending:
        usageType = UsageType.PayPending;
        break;
      default:
        usageType = UsageType.Other;
        break;
    }
    const request = {
      Identity: this._appDataConfig.userConfiguration.Identity,
      Id: idDocument,
      UsageType: usageType
    };
    return this._httpSvc.postJsonObservable(`${this._appDataConfig.apiUrl}/GetDocument`, request)
      .map((res: any) => {
        const ret: GetDocumentResponse = {
          status: res.status,
          message: res.message,
          document: FormatHelper.formatServiceDocument(res.document, this._roundPipe)
        };
        return ret;
      });
  }
}
