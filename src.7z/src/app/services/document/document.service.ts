import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/first';
import 'rxjs/add/observable/zip';
import { RoundPipe } from 'app/pipes/round.pipe';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { HttpService } from 'app/services/http/http.service';
import { Document } from 'app/shared/document/document';
import { DocumentLine } from 'app/shared/document/document-line';
import { FormatHelper } from 'app/helpers/format-helper';
import { LogHelper } from 'app/helpers/log-helper';
import { DocumentInternalService } from 'app/services/document/document-internal.service';
import { FinalizingDocumentFlowType } from 'app/shared/document/finalizing-document-flow-type.enum';
import { DocumentSeriesService } from 'app/services/document/document-series.service';
import { ConfirmPaymentRequest } from 'app/shared/confirm-payment-request';
import { Subscriber } from 'rxjs/Subscriber';
import { PaymentDetail } from 'app/shared/payments/payment-detail';
import { OperatorInternalService } from 'app/services/operator/operator-internal.service';
import { SignalRPrintingService } from 'app/services/signalr/signalr-printing.service';
import { StatusBarService } from 'app/services/status-bar/status-bar.service';
import { PrintResponseStatuses } from 'app/shared/signalr-server-responses/printingModuleHub/print-response-statuses.enum';
import { IdocumentConfirmActions } from 'app/shared/idocument-confirm-actions';
import { CalculatePromotionsResponse } from 'app/shared/web-api-responses/calculate-promotions-response';
import { CalculatePromotionsResponseStatuses } from 'app/shared/web-api-responses/calculate-promotions-response-statuses.enum';
import { DocumentLinePromotion } from 'app/shared/document/document-line-promotion';
import { IresponseSuccessWithObject } from 'app/shared/iresponse-success-with-object';
import { PaymentPurpose } from 'app/shared/payments/PaymentPurpose.enum';
import { LoyaltyService } from 'app/services/loyalty/loyalty.service';
import { LoyaltyAttributionInformation } from 'app/shared/loyalty/loyalty-attribution-information';
import { LoyaltyActionType } from 'app/shared/loyalty/loyalty-action-type.enum';
import {
  ProcessLoyaltyAttributionAndRedeemBenefitResponse
} from 'app/shared/hubble-pos-web-api-responses/loyalty/process-loyalty-attribution-and-redeem-benefit-response';
import { CustomerSelectedResult } from 'app/shared/customer/customer-selected-result';
import { SeriesType } from 'app/shared/series/series-type';

@Injectable()
export class DocumentService {

  constructor(
    private _http: HttpService,
    private _appDataConfig: AppDataConfiguration,
    private _docInternalService: DocumentInternalService,
    private _seriesService: DocumentSeriesService,
    private _roundPipe: RoundPipe,
    private _operatorSvc: OperatorInternalService,
    private _signalRPrintingServ: SignalRPrintingService,
    private _statusBarService: StatusBarService,
    private _documentConfirmActions: IdocumentConfirmActions,
    private _loyaltyService: LoyaltyService
  ) { }

  sendRunawayDocuments(documentList: Array<Document>): Observable<boolean> {
    return this._sendDocuments(documentList, 'RUNAWAY');
  }

  sendPaymentRefundDocuments(documentList: Array<Document>): Observable<boolean> {
    if (this._appDataConfig.printerPosCommands != undefined) {
      return this._sendDocuments(documentList, 'REFUND', [this._appDataConfig.printerPosCommands.openDrawer]);
    } else {
      return this._sendDocuments(documentList, 'REFUND');
    }
  }

  sendInvoiceDocuments(documentList: Array<Document>): Observable<boolean> {
    if (this._appDataConfig.printerPosCommands != undefined) {
      return this._sendDocuments(documentList, 'INVOICE', [this._appDataConfig.printerPosCommands.openDrawer]);
    } else {
      return this._sendDocuments(documentList, 'INVOICE');
    }
  }

  sendSaleDocuments(documentList: Array<Document>, printDocument: boolean = true): Observable<boolean> {
    if (this._appDataConfig.printerPosCommands != undefined && printDocument) {
      return this._sendDocuments(documentList, 'SALE', [this._appDataConfig.printerPosCommands.openDrawer]);
    } else if (!printDocument) {
      return this._sendDocumentsNoPrint(documentList);
    } else {
      return this._sendDocuments(documentList, 'SALE');
    }
  }
  sendDeliveryNote(documentList: Array<Document>): Observable<boolean> {
    return this._sendDocuments(documentList, 'DELIVERYNOTE');
  }
  cancelDocument(ticket: Document): Observable<boolean> {
    if (this._appDataConfig.printerPosCommands != undefined) {
      return this._cancelDocument(ticket, 'REFUND', [this._appDataConfig.printerPosCommands.openDrawer]);
    } else {
      return this._cancelDocument(ticket, 'REFUND');
    }
  }

  cancelAndReinvoiceDocument(document: Document, customer: CustomerSelectedResult): Observable<boolean> {
    if (this._appDataConfig.printerPosCommands != undefined) {
      return this._cancelAndReinvoiceDocument(document, customer, 'REFUND', 'INVOICE', [this._appDataConfig.printerPosCommands.openDrawer]);
    } else {
      return this._cancelAndReinvoiceDocument(document, customer, 'REFUND', 'INVOICE');
    }
  }


  /**
   * Efectua las operaciones de preparacion de documento,
   * prueba de impresion y subida de documentos
   * @param documentList lista de documentos a enviar
   */
  private _sendDocuments(documentList: Array<Document>, useCase: string, commandsList?: string[]): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (commandsList == undefined) {
        commandsList = [];
      }
      this._completeDocument(documentList)
        .first().subscribe(completeDocumentResponse => {
          if (completeDocumentResponse.success != true) {
            this._statusBarService.publishMessage('Error estableciendo identificador de documento.');
            return observer.next(false);
          }
          this._statusBarService.publishProgress(25);
          this._statusBarService.publishMessage('Preparando impresión...');
          const completeDocuments = completeDocumentResponse.object;
          // simulo una impresión del documento para comprobar que la impresora va
          this._signalRPrintingServ.simulatePrintDocument(
            completeDocuments[0],
            useCase,
            completeDocuments[0].pendingAmountWithTax > 0 ? 2 : undefined, // numero de copias si hay importe pendiente
            commandsList)
            .first().subscribe(response => {
              if (response.status === PrintResponseStatuses.successful) {
                console.log('simulación de impresión satisfactoria. A continuación se enviará el documento al WebAPI');

                const loyaltyAttributionInfo: LoyaltyAttributionInformation = completeDocuments[0].loyaltyAttributionInfo;
                if (loyaltyAttributionInfo != undefined) {
                  let loyaltyOperationObservable: Observable<ProcessLoyaltyAttributionAndRedeemBenefitResponse>;
                  if (loyaltyAttributionInfo) {
                    if (loyaltyAttributionInfo.actionType == LoyaltyActionType.accumulation) {
                      loyaltyOperationObservable = this._loyaltyService.accumulate(loyaltyAttributionInfo.cardNumber,
                        loyaltyAttributionInfo.documentTotalAmount, // OJO. Es el total anterior del documento
                        loyaltyAttributionInfo.currencyId,
                        loyaltyAttributionInfo.localDateTime);


                    } else {
                      loyaltyOperationObservable = this._loyaltyService.redeem(loyaltyAttributionInfo.cardNumber,
                        loyaltyAttributionInfo.documentTotalAmount,
                        loyaltyAttributionInfo.currencyId,
                        loyaltyAttributionInfo.localDateTime,
                        loyaltyAttributionInfo.amountToRedeem,
                        loyaltyAttributionInfo.benefitId);
                    }
                  }

                  loyaltyOperationObservable.subscribe(loyaltyOperationResponse => {
                    console.log('Loyalty operation response->');
                    console.log(loyaltyOperationResponse);
                  });

                  // TODO: Gestionar estados de error. Ahora mismo no se gestiona
                  // Si por ejemplo no hubiese red, no hay implementado política de reintentos
                  /*if (loyaltyOperationObservable != undefined) {
                    loyaltyAcumulationObservable.subscribe(loyaltyOperationResponse => {
                      if (loyaltyOperationResponse.status === ProcessLoyaltyAttributionAndRedeemBenefitResponseStatuses.successful) {

                      } else {
                        LogHelper.logError(undefined, loyaltyOperationResponse.message);
                        this._statusBarService.publishMessage('Error en el módulo de fidelización');
                        observer.next(false);
                      }
                    });
                  }*/
                }

                this._statusBarService.publishProgress(50);
                this._statusBarService.publishMessage('Generando documento...');
                // envio el documento al WebApi
                this._executeLineSpecificActionsAndSendDocumentToService(documentList)
                  .first().subscribe(sendDocumentResponse => {
                    if (sendDocumentResponse) {
                      this._statusBarService.publishProgress(75);
                      this._statusBarService.publishMessage('Imprimiendo...');
                      // imprimo el documento
                      this._signalRPrintingServ.printDocument(
                        completeDocuments[0],
                        useCase,
                        completeDocuments[0].pendingAmountWithTax > 0 ? 2 : undefined, // numero de copias si hay importe pendiente
                        commandsList)
                        .first().subscribe(respuesta => {
                          // TODO: Diferenciar problemas de impresora de problemas en el módulo o el controlador
                          //      -cuidado con los problemas que puedan afectar a la SUNAT-
                          if (respuesta.status === PrintResponseStatuses.successful) {
                            this._statusBarService.publishProgress(100);
                            this._statusBarService.publishMessage('Impresión completada.');
                            console.log('se ha impreso el documento');
                            observer.next(true);
                          } else {
                            LogHelper.logError(undefined, respuesta.message);
                            this._statusBarService.publishMessage(
                              'Error al imprimir. El documento fue generado con éxito. Utilice el comando copia.');
                            observer.next(false);
                          }
                        });
                    } else {
                      this._statusBarService.publishMessage('Error al generar el documento.');
                      observer.next(false);
                    }
                  });
              } else {
                LogHelper.logError(undefined, response.message);
                this._statusBarService.publishMessage('Error al preparar la impresión.');
                observer.next(false);
              }
            });
        });
    });
  }

  private _sendDocumentsNoPrint(documentList: Array<Document>): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      this._completeDocument(documentList)
        .first().subscribe(completeDocumentResponse => {
          if (completeDocumentResponse.success != true) {
            this._statusBarService.publishMessage('Error estableciendo identificador de documento.');
            return observer.next(false);
          }
          // envio el documento al WebApi
          this._executeLineSpecificActionsAndSendDocumentToService(documentList)
          .first().subscribe(sendDocumentResponse => {
            if (sendDocumentResponse) {
              observer.next(true);
            } else {
              this._statusBarService.publishMessage('Error al generar el documento.');
              observer.next(false);
            }
          });
        });
    });
  }


  // envio de un pago pendiente
  sendPaymentDetail(documentId: string, paymentDetailList: Array<PaymentDetail>): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (paymentDetailList.length < 1) {
        observer.next(false);
        return;
      }
      const arrObservables: Array<Observable<any>> = [];
      const today = new Date();
      for (const payment of paymentDetailList) {
        const request = {
          identity: this._appDataConfig.userConfiguration.Identity,
          documentId: documentId,
          operatorId: this._getCurrentOperatorId(),
          createDao: {
            localDateTime: FormatHelper.dateToISOString(today),
            utcDateTime: FormatHelper.dateToISOString(
              FormatHelper.formatToUTCDateFromLocalDate(today)
            ),
            paymentMethodId: payment.paymentMethodId,
            currencyId: payment.currencyId,
            changeFactorFromBase: payment.changeFactorFromBase,
            primaryCurrencyGivenAmount: payment.primaryCurrencyGivenAmount,
            primaryCurrencyTakenAmount: payment.primaryCurrencyTakenAmount,
            secondaryCurrencyGivenAmount: payment.secondaryCurrencyGivenAmount,
            secondaryCurrencyTakenAmount: payment.secondaryCurrencyTakenAmount,
            extraData: payment.extraData,
            usageType: PaymentPurpose.PendingPayment
          }
        };
        arrObservables.push(
          this._http.postJsonObservable(`${this._appDataConfig.apiUrl}/CreateDocumentPaymentDetail`, request)
        );
      }
      // comprimo las respuestas en una sola
      Observable.zip(...arrObservables) // tomamos la primera salida unicamente
        .first().subscribe(zipResponses => {
          // verifico las respuestas, si alguna dio error devolvemos false
          for (const createResponse of zipResponses) {
            if (createResponse.status != 1) {
              observer.next(false);
              console.log(createResponse.message);
            }
          }
          observer.next(true);
        });
    });
  }

  // envia documento cancelado y la factura asociada
  private _cancelAndReinvoiceDocument(
    document: Document, customer: CustomerSelectedResult, useRefundCase: string, useInvoiceCase: string, commandsList?: string[]):
    Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      let rectifierDocument = this.generateRectifyingDocument(document);
      let invoiceDocument = this._docInternalService.cloneDocument(document);

      this._completeDocument(new Array<Document>(rectifierDocument, invoiceDocument)).first().subscribe(completeDocumentResponse => {
        rectifierDocument = completeDocumentResponse.object[0];
        invoiceDocument = completeDocumentResponse.object[1];
        invoiceDocument.series = this._seriesService.getSeriesByFlow(
          FinalizingDocumentFlowType.EmittingBill,
          invoiceDocument.totalAmountWithTax);
        invoiceDocument.customer = customer.customer;
        invoiceDocument.plate = customer.plate;
        // Se envian los dos documentos
        this._executeLineSpecificActionsAndSendDocumentToService(new Array<Document>(rectifierDocument, invoiceDocument))
          .first().subscribe(response => {
            this._statusBarService.publishProgress(50);
            this._statusBarService.publishMessage('Imprimiendo...');
            // imprimo el documento
            this._signalRPrintingServ.printDocument(rectifierDocument, useRefundCase)
              .first().subscribe(responseRectifier => {
                if (responseRectifier.status === PrintResponseStatuses.successful) {
                  this._statusBarService.publishProgress(75);
                  this._statusBarService.publishMessage('Impresión de anulación completada.');
                  console.log('se ha impreso el documento de anulacion');

                  // imprimo el documento
                  this._signalRPrintingServ.printDocument(invoiceDocument, useInvoiceCase, undefined, commandsList)
                    .first().subscribe(responseInvoice => {
                      if (responseInvoice.status === PrintResponseStatuses.successful) {
                        this._statusBarService.publishProgress(100);
                        this._statusBarService.publishMessage('Impresión completada.');
                        console.log('se ha impreso el documento');
                        observer.next(true);
                      } else {
                        LogHelper.logError(undefined, responseInvoice.message);
                        this._statusBarService.publishMessage(
                          'Error al imprimir. El documento fue generado con éxito. Utilice el comando copia.');
                        observer.next(false);
                      }
                    });

                } else {
                  LogHelper.logError(undefined, responseRectifier.message);
                  this._statusBarService.publishMessage(
                    'Error al imprimir.');
                  observer.next(false);
                }
              });
            observer.next(response);
          });
      });
    });
  }

  // solicita al servicio el cálculo de promociones para un determinado documento. Se obtendrá la lista de promociones aplicables al mismo
  calculatePromotions(input: Document): Observable<IresponseSuccessWithObject<Array<DocumentLinePromotion>>> {
    return Observable.create((observer: Subscriber<IresponseSuccessWithObject<Array<DocumentLinePromotion>>>) => {
      const request = {
        identity: this._appDataConfig.userConfiguration.Identity,
        document: FormatHelper.formatDocumentToCalculatePromotionsServiceExpectedObject(input, this._appDataConfig.userConfiguration.PosId)
      };
      this._http.postJsonObservable(`${this._appDataConfig.apiUrl}/CalculatePromotions`, request)
        .first()
        .subscribe(
          (response: CalculatePromotionsResponse) => {
            if (response.status == CalculatePromotionsResponseStatuses.successful) {
              response.availablePromotions.forEach(promotion => {
                // agrego redondeo a las promociones
                promotion.discountAmountWithTax = this._roundPipe.transformInBaseCurrency(promotion.discountAmountWithTax);
              });
              observer.next({
                success: true,
                object: response.availablePromotions
              });
            } else {
              LogHelper.logError(response.status,
                `La respuesta ha sido negativa: ${CalculatePromotionsResponseStatuses[response.status]}. Mensaje: ${response.message}`);
              observer.next({
                success: false,
                object: undefined
              });
            }
          },
          error => {
            LogHelper.logError(undefined,
              `Se produjo un error al solicitar la ejecución del servicio CalculatePromotions: ${error}`);
            observer.next({
              success: false,
              object: undefined
            });
          });
    });
  }

  /**
   * Completa el docuento que se obtiene de plataforma.
   * Calcula la lista de ivas, ya que no viene porpltaforma
   *
   * @param {Document} document
   * @memberof DocumentService
   */
  completCopyDocument(document: Document) {
    document.lines.forEach(line => {
      if (line) {
        this._calculateLineDiscountData(line);
        this._calculateLineTaxAmountData(line);
      }
    });
    // cálculos generales del documento
    this._calculateDocumentTaxList(document);
  }

  /**
   *
   * PRIVADAS
   *
   */

  // envia documento cancelado
  private _cancelDocument(ticket: Document, useCase: string, commandsList?: string[]): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      let documentoRectificador = this.generateRectifyingDocument(ticket);
      console.log(documentoRectificador);
      this._completeDocument([documentoRectificador]).first().subscribe(completeDocumentResponse => {
        documentoRectificador = completeDocumentResponse.object[0];
        this._executeLineSpecificActionsAndSendDocumentToService(new Array<Document>(documentoRectificador))
          .first().subscribe(response => {

            this._statusBarService.publishProgress(75);
            this._statusBarService.publishMessage('Imprimiendo...');
            // imprimo el documento
            this._signalRPrintingServ.printDocument(documentoRectificador, useCase, undefined, commandsList)
              .first().subscribe(respuesta => {
                if (respuesta.status === PrintResponseStatuses.successful) {
                  this._statusBarService.publishProgress(100);
                  this._statusBarService.publishMessage('Impresión completada.');
                  console.log('se ha impreso el documento');
                  observer.next(true);
                } else {
                  LogHelper.logError(undefined, respuesta.message);
                  this._statusBarService.publishMessage(
                    'Error al imprimir. El documento fue generado con éxito. Utilice el comando copia.');
                  observer.next(false);
                }
              });
            observer.next(response);
          });
      });
    });
  }

  // se solicita el identificador y se completa el documento
  private _completeDocument(documentList: Array<Document>): Observable<IresponseSuccessWithObject<Array<Document>>> {
    // Datos adicionales: fechas y calculos finales
    return Observable.create((observer: Subscriber<IresponseSuccessWithObject<Array<Document>>>) => {
      this._setAdditionalData(documentList);
      const documentListJson: any =
        FormatHelper.formatDocumentListToServiceExpectedObject(documentList, this._appDataConfig.userConfiguration.PosId);
      documentListJson.posId = this._appDataConfig.userConfiguration.PosId;

      const request = { identity: this._appDataConfig.userConfiguration.Identity, createDAOList: documentListJson };
      // consigo el mapeo de identificadores del documento
      this._http.postJsonObservable(`${this._appDataConfig.apiUrl}/GetProvisionalIdToDocumentNumberMapping`, request).subscribe(
        response => {
          if (response.status == 1) {
            // aplico el mapeo segun el identificador provisional generado en el formatHelper
            documentList = documentList.map(selectedDocument => {
              // Serializacion de tupla
              const idCodePair: {
                // id documento
                item1: string;
                // document Number
                item2: string
              } = response.provisionalToDefinitiveDocumentIdDictionary[selectedDocument.provisionalId];
              if (idCodePair !== undefined) {
                selectedDocument.documentNumber = idCodePair.item2;
                selectedDocument.documentId = idCodePair.item1;
                selectedDocument.emissionLocalDateTime = new Date();
                selectedDocument.emissionUTCDateTime = FormatHelper.formatToUTCDateFromLocalDate(selectedDocument.emissionLocalDateTime);
                return selectedDocument;
              }
              return selectedDocument;
            });
            observer.next({
              success: true,
              object: documentList
            });
          } else {
            console.error(response.message);
            observer.next({
              success: false,
              object: undefined
            });
          }
        },
        error => {
          console.log(error);
          observer.next({
            success: false,
            object: undefined
          });
        });
    });
  }

  // se envia documento a servicio
  private _executeLineSpecificActionsAndSendDocumentToService(documentList: Array<Document>): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (documentList == undefined) {
        observer.next(false);
      }

      const documentListJson: any =
        FormatHelper.formatDocumentListToServiceExpectedObject(documentList, this._appDataConfig.userConfiguration.PosId);
      documentListJson.posId = this._appDataConfig.userConfiguration.PosId;

      const request = { identity: this._appDataConfig.userConfiguration.Identity, createDAOList: documentListJson };
      this.confirmPayActionsDocuments(documentList)
        .first().subscribe(allOk => {
          if (!allOk) {
            LogHelper.logError(undefined, 'Error confirmando actiones de pago (antes de createDocument)');
            observer.next(false);
          } else {
            this._http.postJsonObservable(`${this._appDataConfig.apiUrl}/CreateDocuments`, request).subscribe(
              response => {
                // TODO: ¿Creamos un modelo de respuesta con los códigos específicos para cada una de las llamadas al demonio?
                if (response.status == 1) {
                  // transacciones huerfanas, informamos que se ha subido correctamente
                  this.confirmTransactionsDocuments(documentList)
                    .first().subscribe(responseConfirmTransactions => {
                      if (responseConfirmTransactions) {
                        observer.next(true);
                      } else {
                        LogHelper.logError(undefined, `Error confirmando transacciones`);
                        observer.next(false);
                      }
                    });
                } else {
                  LogHelper.logError(undefined, `Error al ejecutar CreateDocuments. Respuesta recibida: ${response.message}`);
                  observer.next(false);
                }
              },
              error => {
                console.log(error);
                observer.next(false);
              });
          }
        });
    });
  }
  private confirmTransactionsDocuments(documents: Array<Document>): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      const doc = documents[0];
      this._documentConfirmActions.onSendComplete(doc)
        .first().subscribe(response => {
          observer.next(response);
        });
    });
  }
  private confirmPayActionsDocuments(documents: Array<Document>, index: number = 0): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (index >= documents.length) {
        observer.next(true);
      } else {
        const document = documents[index];
        this.confirmPayActionsDocument(document)
          .first()
          .subscribe(response => {
            if (!response) {
              observer.next(false);
            } else {
              if (index + 1 < documents.length) {
                this.confirmPayActionsDocuments(documents, index + 1)
                  .first().subscribe(nextDocument => {
                    observer.next(nextDocument);
                  });
              } else {
                observer.next(true);
              }
            }
          });
      }
    });
  }

  private confirmPayActionsDocument(document: Document): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      const businessSpecificLines = document.lines.filter(line => line.businessSpecificLineInfo != undefined);
      if (businessSpecificLines == undefined || businessSpecificLines.length == 0) {
        observer.next(true);
      } else {
        const confirmData: ConfirmPaymentRequest = {
          seriesType: document.series.type,
          documentNumber: document.documentNumber, // se ha debido de establecer en el completeDocument
          documentId: document.documentId, // se ha debido de establecer en el completeDocument
          vehicleLicensePlate: document.plate
        };
        this.confirmPayActionsRecursive(businessSpecificLines, confirmData)
          .first().subscribe(response => {
            observer.next(response);
          });
      }
    });
  }
  private confirmPayActionsRecursive(
    businessSpecificLines: Array<DocumentLine>, confirmData: ConfirmPaymentRequest, index: number = 0): Observable<boolean> {
    return Observable.create((observer: Subscriber<boolean>) => {
      if (index >= businessSpecificLines.length) {
        observer.next(true);
      } else {
        const bsl = businessSpecificLines[index].businessSpecificLineInfo;
        bsl.onConfirmPay(confirmData).first().subscribe(response => {
          if (!response) {
            observer.next(false);
          } else {
            if (index + 1 < businessSpecificLines.length) {
              this.confirmPayActionsRecursive(businessSpecificLines, confirmData, index + 1)
                .first().subscribe(nextResponse => {
                  observer.next(nextResponse);
                });
            } else {
              observer.next(true);
            }

          }
        });
      }
    });
  }
  /// Clona el documento y establece las propiedades de un documento rectificador
  private generateRectifyingDocument(document: Document): Document {
    const rectifierDocument = this._docInternalService.cloneDocument(document);
    rectifierDocument.referencedDocumentIdList = [document.documentId];
    rectifierDocument.documentId = '';
    rectifierDocument.series = this._seriesService.getSeriesByFlow(
      document.series.type == SeriesType.ticket ?
        FinalizingDocumentFlowType.EmittingDevolutionForTicket : FinalizingDocumentFlowType.EmittingDevolutionForBill,
      rectifierDocument.totalAmountWithTax);
    rectifierDocument.referencedDocumentNumberList = [document.documentNumber];
    rectifierDocument.totalAmountWithTax = -document.totalAmountWithTax;
    rectifierDocument.totalTaxableAmount = -document.totalTaxableAmount;
    rectifierDocument.totalTaxAmount = -document.totalTaxAmount;
    if (rectifierDocument.lines != undefined) {
      rectifierDocument.lines.forEach(linea => {
        linea.quantity = -linea.quantity;
        linea.totalAmountWithTax = -linea.totalAmountWithTax;
        linea.discountAmountWithTax = -linea.discountAmountWithTax;
        linea.taxAmount = -linea.taxAmount;
      });
    }
    if (rectifierDocument.paymentDetails != undefined) {
      rectifierDocument.paymentDetails.forEach(pd => {
        pd.primaryCurrencyGivenAmount = -pd.primaryCurrencyGivenAmount;
        pd.primaryCurrencyTakenAmount = -pd.primaryCurrencyTakenAmount;
        pd.secondaryCurrencyGivenAmount = -pd.secondaryCurrencyGivenAmount;
        pd.secondaryCurrencyTakenAmount = -pd.secondaryCurrencyTakenAmount;
      });
    }
    return rectifierDocument;
  }

  // set additional data (discounts, tax amounts, etc.)
  private _setAdditionalData(documentList: Array<Document>) {
    if (documentList) {
      documentList.forEach((document, index) => {
        if (document) {
          // provisionalId
          if (document.provisionalId == undefined || document.provisionalId == 0) {
            document.provisionalId = index + 1;
          }
          // Se sobreescribe la fecha local. Es más reciente que la fecha en el momento de la apertura del panel de pago
          document.emissionLocalDateTime = new Date();
          // cálculos datos de lineas del documento y del documento en general
          document.lines.forEach(line => {
            if (line) {
              this._calculateLineDiscountData(line);
              this._calculateLineTaxAmountData(line);
            }
          });
          // cálculos generales del documento
          this._calculateDocumentTaxList(document);
          this._calculateTaxableAmount(document);
          this._recalculateDocumentGlobalDiscount(document);
          // TODO appliedPromotionList lista de promociones
        }
      });
    }
  }

  // descuentos de linea
  private _calculateLineDiscountData(line: DocumentLine) {
    line.discountAmountWithTax =
      (line.priceWithTax - this._roundPipe.transformInBaseCurrency(line.priceWithTax * (100 - line.discountPercentage) / 100)) * line.quantity;
    line.discountAmountWithoutTax =
      (line.priceWithoutTax - this._roundPipe.transformInBaseCurrency(line.priceWithoutTax * (100 - line.discountPercentage) / 100)) * line.quantity;
  }

  // cantidad monetaria de impuestos (si hay descuento se aplica)
  private _calculateLineTaxAmountData(line: DocumentLine) {
    let totalAmountWithTax = line.totalAmountWithTax;
    if (line.appliedPromotionList != undefined && line.appliedPromotionList.length > 0) {
      line.appliedPromotionList.forEach(promotion => {
        totalAmountWithTax = totalAmountWithTax - promotion.discountAmountWithTax;
      });
    }
    line.taxAmount = totalAmountWithTax - this._roundPipe.transform((
      (totalAmountWithTax / line.quantity) / (1 + line.taxPercentage / 100)) * line.quantity,
      this._appDataConfig.decimalPrecisionConfiguration.decimalPositionsForUnitPricesWithoutTax);
  }


  private _calculateTaxableAmount(document: Document): void {
    document.taxableAmount = 0;
    if (!document.lines) {
      return;
    }
    document.lines.forEach(line => {
      let taxableAmount = 0;
      // solo si hay impuesto
      if (line && line.taxPercentage != 0 && line.taxPercentage != undefined) {
        taxableAmount = line.priceWithoutTax * line.quantity;
        // si hay descuento linea se aplica
        if (line.discountPercentage != 0 && line.discountPercentage != undefined) {
          taxableAmount -= line.discountAmountWithoutTax;
        }
        document.taxableAmount += this._roundPipe.transformInBaseCurrency(taxableAmount);
      }
    });
  }

  // calcula una lista con datos: % impuesto + valor monetario a sumar al importe del producto por el impuesto
  // si hay descuento linea, se aplica
  private _calculateDocumentTaxList(document: Document): void {
    document.totalTaxList = {};
    document.lines.forEach((line, index) => {
      if (line) {
        let tax: number = document.totalTaxList[line.taxPercentage];
        if (tax == undefined) {
          tax = line.taxAmount;
        } else {
          tax += line.taxAmount;
        }
        document.totalTaxList[line.taxPercentage.toString()] = tax;
      }
    });
    for (const key in document.totalTaxList) {
      if (document.totalTaxList.hasOwnProperty(key)) {
        document.totalTaxList[key] = this._roundPipe.transformInBaseCurrency(document.totalTaxList[key]);
      }
    }
  }

  private _recalculateDocumentGlobalDiscount(document: Document): void {
    // TODO Aplicar descuento global a cada elemento monetario (?)
    // Por ello se debería recalcular cada ammount, impuesto, etc.
    // según su proporción en el documento porque es descuento
    // GLOBAL no de linea
  }

  private _getCurrentOperatorId(): string {
    return this._operatorSvc.currentOperator.id;
  }
}
