import { Injectable, OnDestroy } from '@angular/core';
import { FuellingPointFormatConfiguration } from 'app/shared/fuelling-point/fuelling-point-format-configuration';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { FormatConfiguration } from 'app/config/format.config';
import { FuellingPointInfo } from 'app/shared/fuelling-point/fuelling-point-info';
import { IDictionaryStringKey } from 'app/shared/idictionary';
import { FuellingPointMainStates } from 'app/shared/fuelling-point/fuelling-point-main-states.enum';
import { ServiceModeType } from 'app/shared/fuelling-point/service-mode-type.enum';
import { GradeConfiguration } from 'app/shared/fuelling-point/grade-configuration';
import { FuellingPointsSignalrUpdatesService } from 'app/services/fuelling-points/fuelling-points-signalr-updates.service';
import { SuplyTransaction } from 'app/shared/fuelling-point/suply-transaction';
import { SuplyTransactionType } from 'app/shared/fuelling-point/suply-transaction-type.enum';
import { Subscription } from 'rxjs/Subscription';
import { ForecourtIdsAndPoscodeInformation } from 'app/shared/fuelling-point/forecourt-ids-and-poscode-information';
import { DocumentInternalService } from 'app/services/document/document-internal.service';

@Injectable()
export class FuellingPointsInternalService implements OnDestroy {

  private _gradeList: Array<GradeConfiguration>;
  private _forecourtIdsInfo: ForecourtIdsAndPoscodeInformation;
  private _subscriptions: Subscription[] = [];
  constructor(
    private _appData: AppDataConfiguration,
    private _formatConfig: FormatConfiguration,
    private _fpSinalRResponse: FuellingPointsSignalrUpdatesService,
    private _docInternalSvc: DocumentInternalService
  ) {
    this._subscriptions.push(this._fpSinalRResponse.onGradeConfiguration()
      .subscribe(response => {
        this._gradeList = response;
      }));
    this._subscriptions.push(this._fpSinalRResponse.onForecourtIdsAndPoscodeInformation()
      .subscribe(response => {
        this._forecourtIdsInfo = response;
      }));
  }

  ngOnDestroy(): void {
    this._subscriptions.forEach(sub => sub.unsubscribe());
  }

  get formatConfiguration(): FuellingPointFormatConfiguration {
    return {
      currency: this._appData.baseCurrency,
      moneyPipeFormat: this._formatConfig.moneyPipeFormat,
      unitPricePipeFormat: this._formatConfig.unitPricePipeFormat,
      unitPriceSymbol: this._formatConfig.unitPriceSymbol,
      volume: this._appData.volume,
      volumePipeFormat: this._formatConfig.volumePipeFormat
    };
  }
  getPOSId(forecourtPOSId: number): string {
    return this._forecourtIdsInfo.forecourIdToPosCode[forecourtPOSId];
  }
  get ownForecourtPOSId(): number {
    return this._forecourtIdsInfo.ownForecourtPOSId;
  }
  getNgClassBackGroundColor(fuellingPointInfo: FuellingPointInfo): IDictionaryStringKey<boolean> {
    const isError = fuellingPointInfo.isInErrorState || fuellingPointInfo.mainState == FuellingPointMainStates.Unavailable;
    /**PRIORIDAD */
    if (isError) {
      return this.buildJsonNgClass('mat-error');
    }

    if (fuellingPointInfo.isAttend) {
      fuellingPointInfo.serviceModeType = ServiceModeType.AttendPaid;
    }

    switch (fuellingPointInfo.serviceModeType) {
      case ServiceModeType.PrePaid:
        return this.buildJsonNgClass('mat-prepay');
      case ServiceModeType.PostPaid:
        return this.buildJsonNgClass('mat-free');
      case ServiceModeType.AttendPaid:
        return this.buildJsonNgClass('mat-atend');
      case ServiceModeType.Other:
      default:
        return this.buildJsonNgClass('mat-mix');
    }
  }

  getNgClassIcon(fuellingPointInfo: FuellingPointInfo): IDictionaryStringKey<boolean> {
    /** estados prioritarios */
    if (fuellingPointInfo.isStopped) {
      // esta parado
      return this.buildJsonNgClass('ic-stop');
    }
    if (fuellingPointInfo.isInErrorState) {
      //  no está parado, pero esta en error
      return this.buildJsonNgClass('ic-alert');
    }
    if (!fuellingPointInfo.isOnline) {
      // esta offline
      return this.buildJsonNgClass('ic-pump-error');
    }
    if (!fuellingPointInfo.hasFreeBuffer) {
      // buffer lleno
      return this.buildJsonNgClass('ic-wait');
    }
    /* fin estados prioritarios */

    if (fuellingPointInfo.mainState == FuellingPointMainStates.Calling
      || fuellingPointInfo.mainState == FuellingPointMainStates.Starting) {
      return this.buildJsonNgClass('ic-boquerel');
    }
    if (fuellingPointInfo.mainState == FuellingPointMainStates.Fuelling) {
      return this.buildJsonNgClass('ic-boquerel-drop');
    }
    if ((fuellingPointInfo.mainState == FuellingPointMainStates.Idle)
      && (fuellingPointInfo.lockingPOSId != undefined)) {
      // reservado
      return this.buildJsonNgClass('ic-reserved');
    }
    if (fuellingPointInfo.mainState == FuellingPointMainStates.Authorized) {
      // autorizado
      return this.buildJsonNgClass('ic-thumb-up');
    }
    // default sin icono
    return this.buildJsonNgClass('visibleHidden');
  }

  getNgClassTransactionIcon(fuellingPointInfo: FuellingPointInfo): IDictionaryStringKey<boolean> {
    if (fuellingPointInfo.hasTransactions) {
      return this.buildJsonNgClass('ic-wait');
    }
    return this.buildJsonNgClass('visibleHidden');
  }
  getNgClassSupplyTransactionBackground(operation: SuplyTransaction): IDictionaryStringKey<boolean> {
    let strTransactionClass = 'transactionLocked';
    switch (operation.type) {
      case SuplyTransactionType.PostpaidLockedByOtherPOS:
      case SuplyTransactionType.PrepaidCompleteLockedByOtherPOS:
      case SuplyTransactionType.Other:
        strTransactionClass = 'transactionLocked';
        break;
      case SuplyTransactionType.PostpaidNoLocked:
      case SuplyTransactionType.PostpaidLockedByOwnPOS:
      case SuplyTransactionType.PrepaidCompleteNotLocked:
      case SuplyTransactionType.PrepaidCompleteLockedByOwnPOS:
        strTransactionClass = 'mat-free';
        break;
      case SuplyTransactionType.PrepaidParcialLockedByOtherPOS:
      case SuplyTransactionType.PrepaidParcialNotLocked:
        strTransactionClass = 'transactionLocked';
        break;
      case SuplyTransactionType.PrepaidParcialLockedByOwnPOS:
        strTransactionClass = 'mat-prepay';
        break;
      default:
        strTransactionClass = 'transactionLocked';
    }
    if (this._docInternalSvc.hasTransaction(operation)) {
      strTransactionClass = 'transactionLocked';
    }
    return this.buildJsonNgClass(strTransactionClass);
  }
  getImgFromGrade(gradeId: number): string {
    if (this._gradeList == undefined) {
      return '';
    }
    const grade = this._gradeList.find(g => g.id == gradeId);
    return grade != undefined ? grade.imageHtmlBase64 : '';
  }
  getDescriptionFromGrade(gradeId: number): string {
    if (this._gradeList == undefined) {
      return '';
    }
    const grade = this._gradeList.find(g => g.id == gradeId);
    return grade != undefined ? grade.name : '';
  }

  private buildJsonNgClass(key: string, check = true): IDictionaryStringKey<boolean> {
    const ret: IDictionaryStringKey<boolean> = {};
    ret[key] = check;
    return ret;
  }

}
