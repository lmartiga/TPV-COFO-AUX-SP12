import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppDataConfiguration } from 'app/config/app-data.config';
import { FormatHelper } from 'app/helpers/format-helper';
import { LogHelper } from 'app/helpers/log-helper';
import { ISignalRConnectionManager } from 'app/shared/isignalr-conection-manager';
import { Document } from 'app/shared/document/document';
import { CashboxClosureSummary } from 'app/shared/cashbox/cashbox-closure-summary';
import { CashboxRecordData } from 'app/shared/cashbox/cashbox-record-data';
import { CashboxRecordType } from 'app/shared/cashbox/cashbox-record-type.enum';
import { FuellingPointTestData } from 'app/shared/fuelling-point/fuelling-point-test-data';
import { SuplyTransaction } from 'app/shared/fuelling-point/suply-transaction';
import { Operator } from 'app/shared/operator/operator';
import { PrintResponse } from 'app/shared/signalr-server-responses/printingModuleHub/print-response';
import { PrintResponseStatuses } from 'app/shared/signalr-server-responses/printingModuleHub/print-response-statuses.enum';
import { SetPrintingTemplatesResponse } from 'app/shared/signalr-server-responses/printingModuleHub/set-printing-templates-response';
import {
  SetPrintingTemplatesResponseStatuses
} from 'app/shared/signalr-server-responses/printingModuleHub/set-printing-templates-response-statuses.enum';
import {
  SetPrintingGlobalSettingsResponseStatuses
} from 'app/shared/signalr-server-responses/printingModuleHub/set-printing-global-settings-response-statuses.enum';
import { SetPrintingGlobalSettingsResponse } from 'app/shared/signalr-server-responses/printingModuleHub/set-printing-global-settings-response';
import {
  SetPrintingTemplatesAndSettingsResponse
} from 'app/shared/signalr-server-responses/printingModuleHub/set-printing-templates-and-settings-response';
import {
  SetPrintingTemplatesAndSettingsResponseStatuses
} from 'app/shared/signalr-server-responses/printingModuleHub/set-printing-templates-and-settings-response-statuses.enum';
import { UsecasePrintingConfiguration } from 'app/shared/printing/usecase-printing-configuration';
import { Subscriber } from 'rxjs/Subscriber';
import { SendCommandToPrinterResponse } from 'app/shared/signalr-server-responses/printingModuleHub/send-command-to-printer-response';
import {
  SendCommandToPrinterResponseStatuses
} from 'app/shared/signalr-server-responses/printingModuleHub/send-command-to-printer-response-statuses.enum';

@Injectable()
export class SignalRPrintingService {

  private _hubProxy: SignalR.Hub.Proxy;
  private _connectionManager: ISignalRConnectionManager;

  constructor(
    private _appDataConfig: AppDataConfiguration
  ) {
    LogHelper.trace('SignalRPrintingService created');
  }

  /**
   *
   *
   * @param {ISignalRConnectionManager} connectionManager
   * @returns {ISignalRHub}
   * @memberof SignalRPrintingService
   * @throws {Error} when connectionManager is null
   */
  setConnectionManager(connectionManager: ISignalRConnectionManager): SignalRPrintingService {
    if (connectionManager == undefined) {
      const errorMessage: string = 'ERROR -> connectionManager parameter cannot be null';
      console.log(errorMessage);
      throw new Error(errorMessage);
    }
    this._connectionManager = connectionManager;
    return this;
  }

  init(): SignalRPrintingService {
    // Por ahora este servicio no se suscribe a eventos no solicitados.
    // Todas las llamadas son a petición del TPV
    if (this._connectionManager != undefined) {
      this._hubProxy = this._connectionManager.createHubProxy('printingModuleHub');
    } else {
      console.log('ERROR -> ConnectionManager cannot be null');
    }
    return this;
  }

  async startInitializationProcess(): Promise<SetPrintingTemplatesAndSettingsResponse> {
    const response: SetPrintingTemplatesAndSettingsResponse = {
      status: SetPrintingTemplatesAndSettingsResponseStatuses.successful,
      message: 'Ok',
    };

    const responseSetGlobalSettings: SetPrintingGlobalSettingsResponse =
      await this._setPrintingGlobalSettings();
    if (responseSetGlobalSettings.status === SetPrintingGlobalSettingsResponseStatuses.successful) {
      const responseSetTemplate: SetPrintingTemplatesResponse =
        await this._setPrintingTemplates();
      if (responseSetTemplate.status != SetPrintingTemplatesResponseStatuses.successful) {
        response.status = SetPrintingTemplatesAndSettingsResponseStatuses.genericError;
        response.message = 'Se produjo un error al solicitar la ejecución del servicio SignalR SetAvailableTemplates' +
          ` con la siguiente respuesta: ${responseSetTemplate.message}`;
      }
    } else {
      response.status = SetPrintingTemplatesAndSettingsResponseStatuses.genericError;
      response.message = 'Se produjo un error al solicitar la ejecución del servicio SignalR SetPrintingSettings' +
        ` con la siguiente respuesta: ${responseSetGlobalSettings.message}`;
    }
    return response;
  }

  simulatePrintDocument(document: Document, useCase: string, numberOfCopies?: number, commandsList?: string[]): Observable<PrintResponse> {
    return Observable.create((observer: Subscriber<PrintResponse>) => {
      const printingConfigurationFromUseCase: { 'usecasePrintingConfiguration': UsecasePrintingConfiguration, 'response': PrintResponse } =
        this._getPrintingConfigurationFromUseCase(useCase);
      if (printingConfigurationFromUseCase.usecasePrintingConfiguration != undefined) {
        const usecasePrintingConfiguration = printingConfigurationFromUseCase.usecasePrintingConfiguration;
        const request = {
          identity: this._appDataConfig.userConfiguration.Identity,
          operatorId: document.operator.id,
          stringifiedDocumentData: JSON.stringify({
            Document: FormatHelper.formatDocumentToPrintingModuleHubExpectedObject(
              document,
              this._appDataConfig.userConfiguration.Identity,
              this._appDataConfig.paymentMethodList,
              this._appDataConfig.currencyList,
              this._appDataConfig.baseCurrency
            )
          }),
          numberOfCopies: numberOfCopies == undefined ? usecasePrintingConfiguration.defaultNumberOfCopies : numberOfCopies,
          targetPrinterName: this._appDataConfig.defaultPosPrinterName,
          paperWidth: this._appDataConfig.defaultPosPaperWidth,
          templateName: usecasePrintingConfiguration.useCase,
          commandsList: commandsList,
        };
        this._hubProxy.invoke('SimulatePrint', request).then(
          (response: PrintResponse) => {
            observer.next(response);
          },
          error => {
            const message: string = `Se produjo un error al solicitar la ejecución del servicio SignalR SimulatePrint: ${error}`;
            LogHelper.trace(message);
            const response: PrintResponse = {
              status: PrintResponseStatuses.genericError,
              message: message
            };
            observer.next(response);
          });
      } else {
        observer.next(printingConfigurationFromUseCase.response);
      }
    });
  }

  printDocument(document: Document, useCase: string, numberOfCopies?: number, commandsList?: string[]): Observable<PrintResponse> {
    return Observable.create((observer: Subscriber<PrintResponse>) => {
      const printingConfigurationFromUseCase: { 'usecasePrintingConfiguration': UsecasePrintingConfiguration, 'response': PrintResponse } =
        this._getPrintingConfigurationFromUseCase(useCase);
      if (printingConfigurationFromUseCase.usecasePrintingConfiguration != undefined) {
        const usecasePrintingConfiguration = printingConfigurationFromUseCase.usecasePrintingConfiguration;
        document.lines = document.lines.filter( x => x.quantity > 0 && x.isEditable != false);
        const request = {
          identity: this._appDataConfig.userConfiguration.Identity,
          stringifiedDocumentData: JSON.stringify({
            Document: FormatHelper.formatDocumentToPrintingModuleHubExpectedObject(
              document,
              this._appDataConfig.userConfiguration.Identity,
              this._appDataConfig.paymentMethodList,
              this._appDataConfig.currencyList,
              this._appDataConfig.baseCurrency
            )
          }),
          numberOfCopies: numberOfCopies == undefined ? usecasePrintingConfiguration.defaultNumberOfCopies : numberOfCopies,
          targetPrinterName: this._appDataConfig.defaultPosPrinterName,
          paperWidth: this._appDataConfig.defaultPosPaperWidth,
          templateName: usecasePrintingConfiguration.useCase,
          commandsList: commandsList,
        };
        this._hubProxy.invoke('Print', request).then(
          (response: PrintResponse) => {
            observer.next(response);
          },
          error => {
            const message: string = `Se produjo un error al solicitar la ejecución del servicio SignalR Print: ${error}`;
            LogHelper.trace(message);
            const response: PrintResponse = {
              status: PrintResponseStatuses.genericError,
              message: message
            };
            observer.next(response);
          });
      } else {
        observer.next(printingConfigurationFromUseCase.response);
      }
    });
  }

  printCashboxClosure(operator: Operator, document: CashboxClosureSummary): Observable<PrintResponse> {
    return Observable.create((observer: Subscriber<PrintResponse>) => {
      const printingTemplateMapFromUseCase: { 'usecasePrintingConfiguration': UsecasePrintingConfiguration, 'response': PrintResponse } =
        this._getPrintingConfigurationFromUseCase('CLOSURE');
      if (printingTemplateMapFromUseCase.usecasePrintingConfiguration != undefined) {
        const usecasePrintingConfiguration = printingTemplateMapFromUseCase.usecasePrintingConfiguration;
        const request = {
          identity: this._appDataConfig.userConfiguration.Identity,
          operatorId: operator.id,
          // stringifiedDocumentData: JSON.stringify({ Document: document }),
          cashboxClosureDocument: document,
          company: this._appDataConfig.company,
          shop: this._appDataConfig.shop,
          numberOfCopies: usecasePrintingConfiguration.defaultNumberOfCopies,
          targetPrinterName: this._appDataConfig.defaultPosPrinterName,
          paperWidth: this._appDataConfig.defaultPosPaperWidth,
          templateName: usecasePrintingConfiguration.useCase,
        };
        this._hubProxy.invoke('PrintCashboxClosure', request).then(
          (response: PrintResponse) => {
            observer.next(response);
          },
          error => {
            const message: string = `Se produjo un error al solicitar la ejecución del servicio SignalR Print: ${error}`;
            LogHelper.trace(message);
            const response: PrintResponse = {
              status: PrintResponseStatuses.genericError,
              message: message
            };
            observer.next(response);
          });
      } else {
        observer.next(printingTemplateMapFromUseCase.response);
      }
    });
  }

  printCashboxRecord(
    operator: Operator,
    recordType: CashboxRecordType,
    cashboxRecordData: CashboxRecordData,
    currentDateTime: Date
  ): Observable<PrintResponse> {
    return Observable.create((observer: Subscriber<PrintResponse>) => {
      const printingTemplateMapFromUseCase: { 'usecasePrintingConfiguration': UsecasePrintingConfiguration, 'response': PrintResponse } =
        this._getPrintingConfigurationFromUseCase('CASHBOX_RECORD');
      if (printingTemplateMapFromUseCase.usecasePrintingConfiguration != undefined) {
        const usecasePrintingConfiguration = printingTemplateMapFromUseCase.usecasePrintingConfiguration;
        const request = {
          identity: this._appDataConfig.userConfiguration.Identity,
          operatorId: operator.id,
          stringifiedDocumentData: JSON.stringify({
            Document: FormatHelper.formatCashboxRecordToPrintingModuleHubExpectedObject(
              operator,
              recordType,
              cashboxRecordData,
              this._appDataConfig.company,
              this._appDataConfig.shop,
              currentDateTime
            )
          }),
          numberOfCopies: usecasePrintingConfiguration.defaultNumberOfCopies,
          targetPrinterName: this._appDataConfig.defaultPosPrinterName,
          paperWidth: this._appDataConfig.defaultPosPaperWidth,
          templateName: usecasePrintingConfiguration.useCase,
        };
        LogHelper.trace(`json para la impresión de '${request.templateName}': ${request.stringifiedDocumentData}`);
        this._hubProxy.invoke('Print', request).then((response: PrintResponse) => {
          observer.next(response);
        },
          error => {
            const message: string = `Se produjo un error al solicitar la ejecución del servicio SignalR Print: ${error}`;
            LogHelper.trace(message);
            const response: PrintResponse = {
              status: PrintResponseStatuses.genericError,
              message: message
            };
            observer.next(response);
          });
      } else {
        observer.next(printingTemplateMapFromUseCase.response);
      }
    });
  }

  printFuellingPointTest(operator: Operator,
    fuellingTestEntryData: FuellingPointTestData,
    defaultFuellingTankCaption: string,
    tankCaption: string,
    supplyTransaction: SuplyTransaction,
    currentDateTime: Date
  ): Observable<PrintResponse> {
    return Observable.create((observer: Subscriber<PrintResponse>) => {
      const printingTemplateMapFromUseCase: { 'usecasePrintingConfiguration': UsecasePrintingConfiguration, 'response': PrintResponse } =
        this._getPrintingConfigurationFromUseCase('FUELLINGPOINT_TEST');
      if (printingTemplateMapFromUseCase.usecasePrintingConfiguration != undefined) {
        const usecasePrintingConfiguration = printingTemplateMapFromUseCase.usecasePrintingConfiguration;
        const request = {
          identity: this._appDataConfig.userConfiguration.Identity,
          operatorId: operator.id,
          stringifiedDocumentData: JSON.stringify({
            Document: FormatHelper.formatFuellingPointTestToPrintingModuleHubExpectedObject(
              operator,
              fuellingTestEntryData,
              supplyTransaction,
              tankCaption,
              defaultFuellingTankCaption,
              currentDateTime
            )
          }),
          numberOfCopies: usecasePrintingConfiguration.defaultNumberOfCopies,
          targetPrinterName: this._appDataConfig.defaultPosPrinterName,
          paperWidth: this._appDataConfig.defaultPosPaperWidth,
          templateName: usecasePrintingConfiguration.useCase,
        };
        LogHelper.trace(`json para la impresión de '${request.templateName}': ${request.stringifiedDocumentData}`);
        this._hubProxy.invoke('Print', request).then((response: PrintResponse) => {
          observer.next(response);
        },
          error => {
            const message: string = `Se produjo un error al solicitar la ejecución del servicio SignalR Print: ${error}`;
            LogHelper.trace(message);
            const response: PrintResponse = {
              status: PrintResponseStatuses.genericError,
              message: message
            };
            observer.next(response);
          });
      } else {
        observer.next(printingTemplateMapFromUseCase.response);
      }
    });
  }

  sendCommandToPrinter(command: string, printerName: string): Observable<SendCommandToPrinterResponse> {
    return Observable.create((observer: Subscriber<SendCommandToPrinterResponse>) => {

      const request = {
        identity: this._appDataConfig.userConfiguration.Identity,
        command: command,
        printerName: printerName,
      };
      this._hubProxy.invoke('SendCommandToPrinter', request).then(
        (response: SendCommandToPrinterResponse) => {
          observer.next(response);
        },
        error => {
          const message: string = `Se produjo un error al solicitar la ejecución del servicio SignalR SendCommandToPrinter: ${error}`;
          LogHelper.trace(message);

          const response: SendCommandToPrinterResponse = {
            status: SendCommandToPrinterResponseStatuses.genericError,
            message: message
          };
          observer.next(response);
        });
    });
  }

  private async _setPrintingTemplates(): Promise<SetPrintingTemplatesResponse> {
    const request = {
      templates: this._appDataConfig.templateList
    };
    return this._hubProxy.invoke('SetAvailableTemplates', request);
  }

  private async _setPrintingGlobalSettings(): Promise<SetPrintingGlobalSettingsResponse> {
    const request = {
      printingSettings: this._appDataConfig.printingGlobalSettings
    };
    return this._hubProxy.invoke('SetPrintingSettings', request);
  }

  private _getPrintingConfigurationFromUseCase(useCase: string):
  { 'usecasePrintingConfiguration': UsecasePrintingConfiguration, 'response': PrintResponse } {
    let response: PrintResponse;
    let usecasePrintingConfiguration: UsecasePrintingConfiguration;
    const usecasesPrintingConfigurationList: UsecasePrintingConfiguration[] = this._appDataConfig.usecasesPrintingConfigurationList;
    if (usecasesPrintingConfigurationList != undefined) {
      usecasePrintingConfiguration = usecasesPrintingConfigurationList.find(p => p.useCase == useCase);
      if (usecasePrintingConfiguration != undefined) {
        response = {
          status: PrintResponseStatuses.successful,
          message: '',
        };
      } else {
        response = {
          status: PrintResponseStatuses.genericError,
          message: `Se produjo un error al solicitar el mapeo de los printing templates para el` +
            ` caso de uso: ${useCase} con el mapeo ${usecasePrintingConfiguration}`,
        };
        LogHelper.trace(response.message);
      }
    } else {
      response = {
        status: PrintResponseStatuses.genericError,
        message:
        `Se produjo un error al solicitar el mapeo de los printing templates desde parametro de configuracion ${usecasePrintingConfiguration}`,
      };
      LogHelper.trace(response.message);
    }
    return { usecasePrintingConfiguration, response };
  }

}
