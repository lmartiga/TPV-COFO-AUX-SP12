import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class OverlayService {

  private _nextUniqueId = 0;
  private _click: Subject<MouseEvent> = new Subject();

  constructor(
  ) { }

  create(
    zIndex: number,
    parentElement: HTMLElement,
    customClasses?: string[]): string {

    const overlay = document.createElement('div');
    if (customClasses != undefined) {
      customClasses.forEach(el => overlay.classList.add(el));
    } else {
      overlay.classList.add('tpv-overlay');
    }

    overlay.id = `tpv-overlay${this._nextUniqueId++}`;
    overlay.style.zIndex = zIndex.toString();
    overlay.addEventListener('click', ev => this._click.next(ev));
    if (parentElement != undefined) {
      parentElement.appendChild(overlay);
    } else {
      document.body.appendChild(overlay);
    }
    return overlay.id;
  }

  close(uniqueId: string): void {
    const element = document.getElementById(uniqueId);
    if (element != undefined) {
      element.parentNode.removeChild(element);
    }
  }

  onClick(): Observable<MouseEvent> {
    return this._click.asObservable();
  }
}
