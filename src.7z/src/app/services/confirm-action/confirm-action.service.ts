import { Injectable } from '@angular/core';
import { ConfirmActionType } from 'app/shared/confirmAction/confirm-action-type.enum';
import { Observable } from 'rxjs/Observable';
import { SlideOverService } from 'app/services/slide-over/slide-over.service';
import { ConfirmActionComponent } from 'app/components/auxiliar-actions/confirm-action/confirm-action.component';

@Injectable()
export class ConfirmActionService {

  constructor(
    private _slideOver: SlideOverService
  ) { }
  promptActionConfirm(
    textQuestion?: string,
    textYes?: string,
    textNo?: string,
    title?: string,
    type?: ConfirmActionType, ): Observable<boolean> {
    const componentRef = this._slideOver.openFromComponent(ConfirmActionComponent);
    componentRef.instance.confirmAction(textQuestion, textYes, textNo, title, type);
    return componentRef.instance.onFinish();
  }
}
