import { Injectable } from '@angular/core';
import {DocumentInternalService} from 'app/services/document/document-internal.service';
import {ExternalActionViewerResponse} from 'app/shared/external-action-viewer/external-action-viewer-response';
import {ExternalActionViewerRequest} from 'app/shared/external-action-viewer/external-action-viewer-request';
import {StatusBarService} from 'app/services/status-bar/status-bar.service';
import {KeyboardInternalService} from 'app/services/keyboard/keyboard-internal.service';

@Injectable()
export class ExternalActionViewerService {
    constructor(private documentInternalService: DocumentInternalService,
                private statusBarService: StatusBarService,
                private _keyboardInternalService: KeyboardInternalService) {}

    public InvokeCallBackFunction(externalMessageResponse: ExternalActionViewerRequest): ExternalActionViewerResponse {

        switch (externalMessageResponse.callBackFunction) {
            case 'DeleteDocumentData':
            return this._deleteDocumentData();
            case 'ShowStatusBarMessage':
            return this._showStatusBarMessage(externalMessageResponse.data.message);
            case 'GetCurrentDocument':
            return this._getCurrentDocument();
            case 'ShowKeyboard':
            return this._showKeyboard(externalMessageResponse.data.type, externalMessageResponse.data.dato, externalMessageResponse.data.posicion);
            case 'ShowCalendar':
            return this._showCalendar();
            case 'CloseKeyboard':
            return this._closeKeyboard();
            case 'KeyDown':
            return this._onKeyDown(externalMessageResponse.data.type, externalMessageResponse.data.key, externalMessageResponse.data.dato);
            default:
            return {status: 404, message: 'externalMessageResponse.callBackFunction invalid', data: {}};
        }
    }
    private _getCurrentDocument(): ExternalActionViewerResponse {
        return { status: 200, message: 'OK', data: this.documentInternalService.currentDocument };
    }

    private _deleteDocumentData(): ExternalActionViewerResponse {
        this.documentInternalService.deleteDocumentData();
        return {status: 200, message: 'OK', data: {}};
    }

    private _showStatusBarMessage(message: string): ExternalActionViewerResponse {

        if (message != undefined) {
            this.statusBarService.publishMessage(message);
            return {status: 200, message: 'OK', data: {}};
        }
        return {status: 400, message: 'El mensaje no puede ser undefined', data: {}};
    }
    private _showKeyboard(type: string, value?: string, posicion?: number): ExternalActionViewerResponse {
        if (type == 'number' || type == 'text') {
            this._keyboardInternalService.ShowTwoPoints(false);
            this._keyboardInternalService.SendType(type);
            this._keyboardInternalService.SendInputValue(value);
            this._keyboardInternalService.SendPosition(posicion);
        } else if (type == 'time') {
            this._keyboardInternalService.ShowTwoPoints(true);
            this._keyboardInternalService.SendType('number');
        }
        this._keyboardInternalService.ShowKeyBoard();
        return {status: 200, message: 'OK', data: {suscribeKeyboard: true}};
    }
    private _showCalendar(): ExternalActionViewerResponse {
        return {status: 200, message: 'OK', data: {showCalendar: true}};
    }

    private _closeKeyboard(): ExternalActionViewerResponse {
        this._keyboardInternalService.CloseKeyBoard();
        return {status: 200, message: 'OK', data: {}};
    }

    private _onKeyDown(type?: string, key?: string, value?: string): ExternalActionViewerResponse {
        this._keyboardInternalService.SendType(type);
        this._keyboardInternalService.SendInputValue(value);
        this._keyboardInternalService.ShowEventKeyPress(key);
        this._keyboardInternalService.SendPosition(value.length + 1);
        return {status: 200, message: 'OK', data: {}};
    }
}
